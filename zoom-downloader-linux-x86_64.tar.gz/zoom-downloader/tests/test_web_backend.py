"""Integration test for the web backend against a mock Zoom-like join page."""

from __future__ import annotations

import asyncio
import http.server
import threading
from pathlib import Path

from zoom_joiner.backends import BackendContext
from zoom_joiner.backends.web import WebBackend
from zoom_joiner.config import Settings
from zoom_joiner.models import Meeting, MeetingResult, Status

JOIN_HTML = """
<!doctype html>
<html><body>
  <input id="inputname" placeholder="Your Name">
  <input id="inputpasscode" type="password" placeholder="Passcode">
  <button class="preview-join-button" onclick="joinNow()">Join</button>
  <script>
    function joinNow() {
      var pc = document.getElementById('inputpasscode').value;
      if (pc !== '123456') {
        document.body.innerHTML = '<p>Invalid passcode</p>';
        return;
      }
      document.body.innerHTML =
        '<div id="footer"><span class="footer-button__text">Mute</span></div>' +
        '<span class="footer-button__text">Unmute</span>';
    }
  </script>
</body></html>
"""

WAITING_HTML = """
<!doctype html>
<html><body>
  <input id="inputname" placeholder="Your Name">
  <button class="preview-join-button"
          onclick="document.body.innerHTML = '<p>Waiting for the host</p>'">Join</button>
</body></html>
"""


class _Handler(http.server.BaseHTTPRequestHandler):
    page = JOIN_HTML

    def do_GET(self) -> None:  # noqa: N802
        body = self.page.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args: object) -> None:
        return


def _serve(page: str) -> tuple[http.server.ThreadingHTTPServer, str]:
    handler = type("Handler", (_Handler,), {"page": page})
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    host, port = server.server_address
    return server, f"http://127.0.0.1:{port}/join"


async def _run(backend: WebBackend, meeting: Meeting) -> MeetingResult:
    result = MeetingResult(meeting=meeting)
    await backend.start()
    try:
        await backend.join(meeting, result)
    finally:
        await backend.stop()
    return result


def _backend(tmp_path: Path) -> WebBackend:
    settings = Settings(timeout=6, name="Tester", parallel=1, retries=0)
    return WebBackend(BackendContext(settings=settings, report_dir=str(tmp_path), headless=True))


def test_join_with_correct_passcode(tmp_path: Path) -> None:
    server, url = _serve(JOIN_HTML)
    try:
        meeting = Meeting(name="Mock", url=url, passcode="123456", meeting_id="12345678901")
        result = asyncio.run(_run(_backend(tmp_path), meeting))
    finally:
        server.shutdown()
    assert result.status is Status.JOINED, result.message


def test_join_with_wrong_passcode(tmp_path: Path) -> None:
    server, url = _serve(JOIN_HTML)
    try:
        meeting = Meeting(name="Mock", url=url, passcode="000000", meeting_id="12345678901")
        result = asyncio.run(_run(_backend(tmp_path), meeting))
    finally:
        server.shutdown()
    assert result.status is Status.FAILED
    assert "passcode" in result.message.lower()
    assert result.screenshot


def test_waiting_room(tmp_path: Path) -> None:
    server, url = _serve(WAITING_HTML)
    try:
        meeting = Meeting(name="Mock", url=url, meeting_id="12345678901", wait_for_host=False)
        result = asyncio.run(_run(_backend(tmp_path), meeting))
    finally:
        server.shutdown()
    assert result.status is Status.WAITING
