from __future__ import annotations

import asyncio
from pathlib import Path

from zoom_joiner.config import Settings
from zoom_joiner.models import Meeting, MeetingResult, Status
from zoom_joiner.orchestrator import Orchestrator, make_results
from zoom_joiner.report import write_all


class FakeBackend:
    name = "fake"

    def __init__(self, fail_ids: set[str] | None = None) -> None:
        self.fail_ids = fail_ids or set()
        self.started = False
        self.stopped = False

    async def start(self) -> None:
        self.started = True

    async def stop(self) -> None:
        self.stopped = True

    async def join(self, meeting: Meeting, result: MeetingResult) -> None:
        await asyncio.sleep(0.01)
        if meeting.meeting_id in self.fail_ids:
            result.status = Status.FAILED
            result.message = "invalid passcode"
        else:
            result.status = Status.JOINED
            result.message = "joined"


def test_orchestrator_success() -> None:
    meetings = [
        Meeting(name="A", url="https://zoom.us/j/11111111111", meeting_id="11111111111"),
        Meeting(name="B", url="https://zoom.us/j/22222222222", meeting_id="22222222222"),
    ]
    results = make_results(meetings)
    backend = FakeBackend()
    orch = Orchestrator(backend, Settings(parallel=2), results)
    asyncio.run(orch.run())
    assert all(r.status is Status.JOINED for r in results)
    assert backend.started and backend.stopped


def test_orchestrator_retry_then_success() -> None:
    class Flaky(FakeBackend):
        def __init__(self) -> None:
            super().__init__()
            self.calls = 0

        async def join(self, meeting, result):  # type: ignore[override]
            self.calls += 1
            if self.calls == 1:
                result.status = Status.FAILED
                result.message = "transient"
            else:
                result.status = Status.JOINED
                result.message = "joined"

    meetings = [Meeting(name="A", url="u", meeting_id="1")]
    results = make_results(meetings)
    backend = Flaky()
    orch = Orchestrator(backend, Settings(retries=1), results)
    asyncio.run(orch.run())
    assert results[0].status is Status.JOINED
    assert results[0].attempts == 2


def test_report_files(tmp_path: Path) -> None:
    meetings = [Meeting(name="A", url="https://zoom.us/j/11111111111", meeting_id="11111111111")]
    results = make_results(meetings)
    results[0].status = Status.JOINED
    results[0].attempts = 1
    files = write_all(results, tmp_path / "run")
    assert files["csv"].exists()
    assert files["json"].exists()
    assert files["html"].exists()
    content = files["html"].read_text(encoding="utf-8")
    assert "11111111111" in content
    assert "joined" in content
