from __future__ import annotations

import pytest

from zoom_joiner.meeting import (
    canonical_join_url,
    extract_meeting_id,
    extract_query_value,
    is_host_link,
    is_valid,
)


@pytest.mark.parametrize(
    ("url", "expected"),
    [
        ("https://zoom.us/j/12345678901", "12345678901"),
        ("https://zoom.us/j/12345678901?pwd=abc", "12345678901"),
        ("https://zoom.us/wc/12345678901/join", "12345678901"),
        ("https://us02web.zoom.us/wc/12345678901/join?prefer=1", "12345678901"),
        ("https://zoom.us/wc/join?confno=12345678901&un=Bob", "12345678901"),
        ("https://zoom.us/s/12345678901", "12345678901"),
        ("123 4567 8901", "12345678901"),
        ("https://zoom.us/my/someuser", ""),
        ("not a link", ""),
    ],
)
def test_extract_meeting_id(url: str, expected: str) -> None:
    assert extract_meeting_id(url) == expected


def test_extract_query_value() -> None:
    assert extract_query_value("https://zoom.us/j/12345678901?pwd=abc", "pwd") == "abc"
    assert extract_query_value("zoom.us/j/1?pwd=zz", "pwd") == "zz"
    assert extract_query_value("https://zoom.us/j/1", "pwd") == ""


def test_canonical_join_url() -> None:
    url = canonical_join_url("12345678901", "Mohamed Hassan")
    assert url.startswith("https://zoom.us/wc/join?confno=12345678901")
    assert "un=Mohamed%20Hassan" in url


def test_is_valid() -> None:
    assert is_valid("https://zoom.us/j/12345678901")
    assert not is_valid("https://zoom.us/my/user")


def test_is_host_link() -> None:
    assert is_host_link("https://zoom.us/pj/12345678901?pwd=x")
    assert not is_host_link("https://zoom.us/j/12345678901")
