"""Smoke tests for the native desktop application (headless Qt)."""

from __future__ import annotations

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication  # noqa: E402

from zoom_joiner.app import MainWindow  # noqa: E402
from zoom_joiner.cli import resolve_parallel, unique_output_names  # noqa: E402
from zoom_joiner.config import Settings  # noqa: E402
from zoom_joiner.store import (  # noqa: E402
    QueueItem,
    QueueState,
    load_downloads,
    load_queue,
    save_downloads,
    save_queue,
)


@pytest.fixture(scope="module")
def qt_app():
    app = QApplication.instance() or QApplication([])
    yield app


@pytest.fixture
def isolated_store(tmp_path, monkeypatch):
    monkeypatch.setattr("zoom_joiner.store.QUEUE_FILE", tmp_path / "queue.json")
    monkeypatch.setattr("zoom_joiner.store.SETTINGS_FILE", tmp_path / "settings.json")
    monkeypatch.setattr("zoom_joiner.store.RECORDINGS_FILE", tmp_path / "recordings.json")
    return tmp_path / "recordings.json"


def test_store_roundtrip(tmp_path) -> None:
    path = tmp_path / "queue.json"
    state = QueueState(
        items=[QueueItem(name="A", url="https://zoom.us/j/12345678901", passcode="1")],
        options={"parallel": 3},
    )
    save_queue(state, path)
    loaded = load_queue(path)
    assert loaded.items[0].url == "https://zoom.us/j/12345678901"
    assert loaded.options["parallel"] == 3


def test_downloads_roundtrip(tmp_path) -> None:
    path = tmp_path / "recordings.json"
    rows = [
        {"name": "Sync", "url": "https://zoom.us/rec/share/abc", "status": "done"},
        {"name": "Other", "url": "https://zoom.us/rec/share/xyz", "status": "failed"},
    ]
    save_downloads(rows, "/tmp/out", "CODE-1", path)
    loaded, out_dir, default_passcode = load_downloads(path)
    assert out_dir == "/tmp/out"
    assert default_passcode == "CODE-1"
    assert loaded[0]["status"] == "done"
    assert loaded[1]["status"] == "failed"
    rows, out_dir, default_passcode = load_downloads(tmp_path / "nope.json")
    assert rows == [] and out_dir == "" and default_passcode == ""


def test_window_is_download_only(qt_app, isolated_store) -> None:
    window = MainWindow()
    panel = window.download_panel
    panel.links_edit.setPlainText(
        "https://us06web.zoom.us/rec/share/AbCdEf 123456 Weekly Sync\n"
        "https://us06web.zoom.us/rec/share/XyZ123"
    )
    panel.ed_passcode.setText("999999")
    panel.add_links()
    assert panel.table.rowCount() == 2
    assert panel._rows[0]["passcode"] == "123456"
    assert panel._rows[1]["passcode"] == "999999"  # global passcode fallback
    assert isolated_store.exists()  # rows persisted for auto-resume
    window.close()


def test_progress_event_updates_the_table(qt_app, isolated_store) -> None:
    window = MainWindow()
    panel = window.download_panel
    panel.links_edit.setPlainText("https://zoom.us/rec/share/abc123 123456 Test Recording")
    panel.add_links()
    row_id = panel._rows[0]["id"]
    panel._on_event(
        row_id,
        {
            "type": "progress",
            "index": 0,
            "status": "downloading",
            "message": "",
            "bytes": 1234567,
            "total": 2000000,
        },
    )
    assert panel._rows[0]["status"] == "downloading"
    details = panel.table.item(0, 4).text()
    assert "downloading" in details and "1.2 MB / 1.9 MB" in details and "61%" in details
    bar = panel.table.cellWidget(0, 3)
    assert bar is not None and bar.value() == 61
    panel._on_event(
        row_id,
        {
            "type": "progress",
            "index": 0,
            "status": "done",
            "message": "downloaded 1.2 MB",
            "bytes": 1234567,
            "total": 2000000,
            "files": ["/tmp/Test Recording.mp4"],
        },
    )
    assert panel._rows[0]["status"] == "done"
    assert "saved: Test Recording.mp4" in panel.table.item(0, 4).text()
    assert panel.table.cellWidget(0, 3).value() == 100
    window.close()


def test_unfinished_downloads_offer_resume(qt_app, isolated_store) -> None:
    save_downloads(
        [
            {"name": "A", "url": "https://zoom.us/rec/share/aaa", "status": "failed"},
            {"name": "B", "url": "https://zoom.us/rec/share/bbb", "status": "done"},
        ],
        "",
        "",
        isolated_store,
    )
    window: MainWindow = MainWindow()
    panel = window.download_panel
    assert panel.table.rowCount() == 2
    assert panel._rows[1]["status"] == "done"
    window.close()


def test_start_downloads_skips_done_and_sends_flags(qt_app, isolated_store, monkeypatch) -> None:
    calls: list[dict] = []

    def fake_start(self, items, options, out_dir=None, command="run", extra_args=None):
        calls.append(
            {
                "row_id": self.row_id,
                "items": items,
                "options": options,
                "command": command,
                "extra": extra_args,
            }
        )

    monkeypatch.setattr("zoom_joiner.app.BatchProcess.start", fake_start)

    window = MainWindow()
    panel = window.download_panel
    panel._rows = [
        {"name": "Done one", "url": "https://zoom.us/rec/share/aaa", "status": "done"},
        {
            "name": "Todo",
            "url": "https://zoom.us/rec/share/bbb",
            "status": "failed",
            "passcode": "777777",
        },
    ]
    panel.cmb_parallel.setCurrentText("4")
    panel.cmb_connections.setCurrentText("16")
    panel.chk_audio.setChecked(True)
    panel.chk_transcript.setChecked(True)
    panel.start_downloads()
    assert len(calls) == 1  # only the pending row is started, one job per row
    call = calls[0]
    assert call["command"] == "download"
    assert call["options"] == {"parallel": 1}
    assert [m["url"] for m in call["items"]] == ["https://zoom.us/rec/share/bbb"]  # done skipped
    assert call["items"][0]["passcode"] == "777777"
    assert call["extra"] == ["--connections", "16", "--audio", "--transcript"]
    assert call["row_id"] == panel._rows[1]["id"]
    window.close()


def test_scheduler_keeps_the_parallel_limit_and_pulls_the_next(
    qt_app, isolated_store, monkeypatch
) -> None:
    started: list[str] = []

    def fake_start(self, items, options, out_dir=None, command="run", extra_args=None):
        started.append(self.row_id)

    monkeypatch.setattr("zoom_joiner.app.BatchProcess.start", fake_start)
    window = MainWindow()
    panel = window.download_panel
    panel._rows = [
        {"id": f"r{i}", "name": f"N{i}", "url": f"https://zoom.us/rec/share/{i}",
         "status": "pending"}
        for i in range(3)
    ]
    panel.cmb_parallel.setCurrentText("2")
    panel.start_downloads()
    assert started == ["r0", "r1"]
    panel._on_finished("r0", 0)
    assert started == ["r0", "r1", "r2"]
    window.close()


def test_links_added_while_running_join_the_queue(qt_app, isolated_store, monkeypatch) -> None:
    started: list[str] = []
    monkeypatch.setattr(
        "zoom_joiner.app.BatchProcess.start",
        lambda self, items, options, out_dir=None, command="run", extra_args=None: started.append(
            self.row_id
        ),
    )
    window = MainWindow()
    panel = window.download_panel
    panel._rows = [
        {"id": "r0", "name": "One", "url": "https://zoom.us/rec/share/one", "status": "pending"}
    ]
    panel.cmb_parallel.setCurrentText("2")
    panel.start_downloads()
    assert started == ["r0"]
    panel.links_edit.setPlainText("https://zoom.us/rec/share/two")
    panel.add_links()
    assert len(panel._rows) == 2
    assert panel._jobs  # still running
    assert started == ["r0", panel._rows[1]["id"]]  # the new link took its turn
    window.close()


def test_pause_and_resume(qt_app, isolated_store, monkeypatch) -> None:
    started: list[str] = []
    monkeypatch.setattr(
        "zoom_joiner.app.BatchProcess.start",
        lambda self, items, options, out_dir=None, command="run", extra_args=None: started.append(
            self.row_id
        ),
    )
    window = MainWindow()
    panel = window.download_panel
    panel._rows = [
        {"id": "r0", "name": "One", "url": "https://zoom.us/rec/share/one", "status": "pending"},
        {"id": "r1", "name": "Two", "url": "https://zoom.us/rec/share/two", "status": "pending"},
    ]
    panel.cmb_parallel.setCurrentText("2")
    panel.start_downloads()
    assert panel._mode == "running" and len(panel._jobs) == 2
    panel.toggle_pause()
    assert panel._mode == "paused"
    assert not panel._jobs
    assert all(r["status"] == "pending" for r in panel._rows)
    assert panel.btn_pause.text() == "Resume"
    panel.toggle_pause()
    assert panel._mode == "running"
    assert len(panel._jobs) == 2
    assert panel.btn_pause.text() == "Pause"
    window.close()


def test_rename_and_sequence(qt_app, isolated_store) -> None:
    window = MainWindow()
    panel = window.download_panel
    panel._rows = [
        {"id": f"r{i}", "name": f"Recording {i + 1}", "url": f"https://zoom.us/rec/share/{i}",
         "status": "pending"}
        for i in range(3)
    ]
    panel._refresh_table()
    assert panel.rename_row(0, "Lineare Algebra / Woche 1") is True
    assert panel._rows[0]["name"] == "Lineare Algebra Woche 1"
    assert panel.sequence_names([0, 1, 2], "Vorlesung", 7, 9) is True
    assert [r["name"] for r in panel._rows] == ["Vorlesung 7", "Vorlesung 8", "Vorlesung 9"]
    assert panel.sequence_names([0, 1], "X", 5, 5) is False  # not enough numbers for 2 rows
    assert panel.rename_row(0, "   ") is False
    assert panel._rows[0]["name"] == "Vorlesung 7"
    window.close()


def test_start_downloads_all_done_informs(qt_app, isolated_store, monkeypatch) -> None:
    calls: list[dict] = []
    monkeypatch.setattr(
        "zoom_joiner.app.BatchProcess.start",
        lambda self, items, options, out_dir=None, command="run", extra_args=None: calls.append({}),
    )
    monkeypatch.setattr("zoom_joiner.app.BatchProcess.is_running", lambda self: False)
    informed: list[tuple] = []
    monkeypatch.setattr(
        "zoom_joiner.app.QMessageBox.information", lambda *a, **k: informed.append(a)
    )
    window = MainWindow()
    panel = window.download_panel
    panel._rows = [{"name": "A", "url": "https://zoom.us/rec/share/aaa", "status": "done"}]
    panel.start_downloads()
    assert not calls  # nothing started
    assert informed  # the user was told everything is already downloaded
    window.close()


def test_resolve_parallel_precedence() -> None:
    settings = Settings(parallel=5)
    assert resolve_parallel(None, settings) == 5  # from the file
    assert resolve_parallel(3, settings) == 3  # flag wins
    assert resolve_parallel(None, None) == 2
    assert resolve_parallel(None, Settings(parallel=0)) == 2


def test_add_links_validates_zoom_recording_links(qt_app, isolated_store) -> None:
    window = MainWindow()
    panel = window.download_panel
    panel.links_edit.setPlainText(
        "https://example.com/rec/share/AbCdEf 123456 Bogus\n"
        "https://us06web.zoom.us/rec/share/GoodOne 111111 Genuine"
    )
    panel.add_links()
    assert len(panel._rows) == 1  # only the real Zoom link survived
    assert panel._rows[0]["url"].endswith("/GoodOne")
    assert "not a Zoom recording link" in panel.log_view.toPlainText()
    window.close()


def test_links_without_a_name_get_recording_n(qt_app, isolated_store) -> None:
    window = MainWindow()
    panel = window.download_panel
    panel.links_edit.setPlainText(
        "https://us06web.zoom.us/rec/share/AbCdEf\n"
        "https://uni-rostock-de.zoom-x.de/rec/share/other DAV-R2025 Rostock"
    )
    panel.add_links()
    assert panel._rows[0]["name"] == "Recording 1"
    assert panel._rows[1]["name"] == "Rostock"
    window.close()


def test_default_passcode_survives_a_restart(qt_app, isolated_store) -> None:
    window = MainWindow()
    panel = window.download_panel
    panel.links_edit.setPlainText("https://uni-rostock-de.zoom-x.de/rec/share/AbCdEf")
    panel.ed_passcode.setText("DAV-R2025")
    panel.add_links()
    window.close()

    again = MainWindow()
    assert again.download_panel.ed_passcode.text() == "DAV-R2025"
    again.close()


def test_unique_output_names_never_reuses_a_finished_file(tmp_path) -> None:
    from types import SimpleNamespace

    (tmp_path / "Lecture 1.mp4").write_bytes(b"old")
    (tmp_path / "Lecture 1 (2).mp4.parts").mkdir()

    a = SimpleNamespace(name="Lecture 1")
    b = SimpleNamespace(name="Lecture 1")
    c = SimpleNamespace(name="Lecture 1 (2)")
    d = SimpleNamespace(name="No extension")
    chosen = unique_output_names([a, b, c, d], tmp_path)
    assert chosen == ["Lecture 1 (2)", "Lecture 1 (3)", "Lecture 1 (2) (2)", "No extension"]
    # the existing file was left alone
    assert (tmp_path / "Lecture 1.mp4").read_bytes() == b"old"


def test_unique_output_names_keeps_parts_for_resume(tmp_path) -> None:
    from types import SimpleNamespace

    (tmp_path / "Half.mp4.parts").mkdir()
    request = SimpleNamespace(name="Half")
    assert unique_output_names([request], tmp_path) == ["Half"]


def test_row_percent_handles_missing_sizes(qt_app, isolated_store) -> None:
    window = MainWindow()
    panel = window.download_panel
    assert panel._row_percent({"status": "pending"}) == 0
    assert panel._row_percent({"status": "done"}) == 100
    assert panel._row_percent({"status": "downloading", "bytes": "50", "total": "200"}) == 25
    assert panel._row_percent({"status": "downloading", "bytes": "50", "total": "0"}) == 0
    assert "25%" in panel._row_percent_text(
        {"status": "downloading", "bytes": "50", "total": "200"}
    )
    window.close()


def test_unique_output_names_leaves_unnamed_requests_alone(tmp_path) -> None:
    from types import SimpleNamespace

    request = SimpleNamespace(name="")
    assert unique_output_names([request], tmp_path) == [""]
    assert request.name == ""  # the page title/token fallback still applies


def test_bogus_progress_is_clamped_to_the_real_size(qt_app, isolated_store) -> None:
    window = MainWindow()
    panel = window.download_panel
    item = {"name": "Meeting", "passcode": "", "status": "downloading",
            "bytes": "0", "total": "2000000", "message": ""}
    panel._rows.append(item)
    row_id = panel._rows[-1].setdefault("id", "test-row")
    panel._on_event(row_id, {
        "type": "progress", "status": "downloading",
        "bytes": 13_000_000_000, "total": 2_000_000,
        "message": "downloading the video…", "files": [],
    })
    assert item["bytes"] == "2000000"
    assert panel._row_percent(item) == 99
    assert "1.9 MB" in item["message"] and "13.0 GB" not in item["message"]
    window.close()


def test_open_path_uses_the_platform_opener(monkeypatch, tmp_path) -> None:
    from zoom_joiner import app as app_module

    calls = []
    monkeypatch.setattr(app_module.subprocess, "Popen", lambda argv: calls.append(argv))
    app_module._open_path(tmp_path)
    assert calls == [["xdg-open", str(tmp_path)]]


def test_default_app_dir_is_platform_aware(monkeypatch, tmp_path) -> None:
    from zoom_joiner.store import default_app_dir

    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "AppData" / "Local"))
    windows = default_app_dir("nt")
    assert windows.parent.name == "Local"
    assert windows.name == "ZoomDownloader"
    linux = default_app_dir("posix")
    assert str(linux).endswith(".local/share/zoom-joiner")


def test_pending_and_failed_rows_do_not_show_stale_progress(qt_app, isolated_store) -> None:
    window = MainWindow()
    panel = window.download_panel
    assert panel._row_percent({"status": "pending", "bytes": "100", "total": "100"}) == 0
    assert panel._row_percent({"status": "failed", "bytes": "100", "total": "100"}) == 0
    window.close()


def test_restart_clears_the_leftover_progress(qt_app, isolated_store, tmp_path) -> None:
    from zoom_joiner.store import save_downloads

    save_downloads(
        [{"name": "A", "url": "https://example.com/rec", "passcode": "1",
          "status": "downloading", "bytes": "100", "total": "100",
          "message": "100 B / 100 B · 100% · downloading…"}],
        str(tmp_path),
        path=isolated_store,
    )
    window = MainWindow()
    row = window.download_panel._rows[0]
    assert row["status"] == "pending"
    assert "bytes" not in row and "total" not in row
    assert row["message"] == ""
    assert window.download_panel._row_percent(row) == 0
    window.close()


def test_organize_button_renames_existing_files(qt_app, isolated_store, tmp_path) -> None:
    from datetime import datetime, timezone

    epoch = datetime(1904, 1, 1, tzinfo=timezone.utc)
    moment = datetime(2025, 5, 1, tzinfo=timezone.utc)
    seconds = int((moment - epoch).total_seconds())
    payload = b"\x00\x00\x00\x00" + seconds.to_bytes(4, "big") + b"\x00" * 80
    mvhd = (len(payload) + 8).to_bytes(4, "big") + b"mvhd" + payload
    moov = (len(mvhd) + 8).to_bytes(4, "big") + b"moov" + mvhd
    data = (16).to_bytes(4, "big") + b"ftypisom\x00\x00\x00\x00" + moov

    folder = tmp_path / "recordings"
    folder.mkdir()
    (folder / "Meeting 1.mp4").write_bytes(data)

    window = MainWindow()
    panel = window.download_panel
    panel.ed_out.setText(str(folder))
    panel.btn_organize.click()

    assert (folder / "Meeting 1 2025-05-01.mp4").exists()
    assert not (folder / "Meeting 1.mp4").exists()
    assert "renamed 1" in panel.log_view.toPlainText()
    window.close()


def test_organize_button_uses_the_base_name(qt_app, isolated_store, tmp_path) -> None:
    from datetime import datetime, timezone

    epoch = datetime(1904, 1, 1, tzinfo=timezone.utc)
    moment = datetime(2025, 5, 1, tzinfo=timezone.utc)
    seconds = int((moment - epoch).total_seconds())
    payload = b"\x00\x00\x00\x00" + seconds.to_bytes(4, "big") + b"\x00" * 80
    mvhd = (len(payload) + 8).to_bytes(4, "big") + b"mvhd" + payload
    moov = (len(mvhd) + 8).to_bytes(4, "big") + b"moov" + mvhd
    data = (16).to_bytes(4, "big") + b"ftypisom\x00\x00\x00\x00" + moov

    folder = tmp_path / "recordings"
    folder.mkdir()
    (folder / "Meeting 1.mp4").write_bytes(data)

    window = MainWindow()
    panel = window.download_panel
    panel.ed_out.setText(str(folder))
    panel.ed_organize_name.setText("DAV-R")
    panel.btn_organize.click()

    assert (folder / "DAV-R 2025-05-01.mp4").exists()
    window.close()


def test_downloading_never_shows_100_percent(qt_app, isolated_store) -> None:
    window = MainWindow()
    panel = window.download_panel
    item = {"status": "downloading", "bytes": "2000000", "total": "2000000"}
    assert panel._row_percent(item) == 99
    assert "99%" in panel._row_percent_text(
        {"status": "downloading", "bytes": "2000000", "total": "2000000"})
    window.close()


def test_contact_card_shows_name_and_email(qt_app, isolated_store) -> None:
    window = MainWindow()
    panel = window.download_panel
    text = panel.contact_label.text()
    assert "Mohamed Hassan" in text
    assert "mohamedhassanmt4@gmail.com" in text
    assert 'href="mailto:mohamedhassanmt4@gmail.com"' in text
    window.close()
