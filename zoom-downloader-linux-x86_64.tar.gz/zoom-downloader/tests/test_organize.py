"""Tests for renaming downloaded recordings by their metadata date."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import pytest

from zoom_joiner.organize import (
    has_date_suffix,
    mp4_creation_date,
    organize_by_date,
)

EPOCH = datetime(1904, 1, 1, tzinfo=timezone.utc)


def mp4_bytes(date: str, version: int = 0) -> bytes:
    moment = datetime.strptime(date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    seconds = int((moment - EPOCH).total_seconds())
    if version == 1:
        payload = b"\x01\x00\x00\x00" + seconds.to_bytes(8, "big") + b"\x00" * 80
    else:
        payload = b"\x00\x00\x00\x00" + seconds.to_bytes(4, "big") + b"\x00" * 80
    mvhd = (len(payload) + 8).to_bytes(4, "big") + b"mvhd" + payload
    moov = (len(mvhd) + 8).to_bytes(4, "big") + b"moov" + mvhd
    ftyp = (16).to_bytes(4, "big") + b"ftypisom\x00\x00\x00\x00"
    return ftyp + moov


def test_reads_the_mvhd_date(tmp_path: Path) -> None:
    path = tmp_path / "clip.mp4"
    path.write_bytes(mp4_bytes("2025-08-14"))
    assert mp4_creation_date(path) == "2025-08-14"


def test_reads_a_version_1_mvhd(tmp_path: Path) -> None:
    path = tmp_path / "clip.mp4"
    path.write_bytes(mp4_bytes("2025-07-24", version=1))
    assert mp4_creation_date(path) == "2025-07-24"


def test_ignores_a_zero_or_missing_date(tmp_path: Path) -> None:
    path = tmp_path / "zero.mp4"
    path.write_bytes(mp4_bytes("2025-08-14").replace(b"mvhd", b"free"))
    assert mp4_creation_date(path) == ""


def test_date_suffix_detection() -> None:
    assert has_date_suffix(Path("Recording 1 (3) 2025-07-18.mp4"))
    assert not has_date_suffix(Path("Meeting 1.mp4"))
    assert not has_date_suffix(Path("Recording 1 (7).mp4"))


def test_organizes_only_undated_video_files(tmp_path: Path) -> None:
    (tmp_path / "Meeting 1.mp4").write_bytes(mp4_bytes("2025-05-01"))
    (tmp_path / "Recording 1 (7).mp4").write_bytes(mp4_bytes("2025-08-14", version=1))
    (tmp_path / "Done 2025-01-02.mp4").write_bytes(mp4_bytes("2025-01-02"))
    (tmp_path / "notes.txt").write_text("keep me")
    (tmp_path / "broken.mp4").write_bytes(b"not an mp4")

    report = organize_by_date(tmp_path)

    assert (tmp_path / "Meeting 1 2025-05-01.mp4").exists()
    assert (tmp_path / "Recording 1 (7) 2025-08-14.mp4").exists()
    assert (tmp_path / "Done 2025-01-02.mp4").exists()
    assert (tmp_path / "notes.txt").exists()
    assert (tmp_path / "broken.mp4").exists()
    assert len(report.renamed) == 2
    assert report.already_dated == ["Done 2025-01-02.mp4"]
    assert report.no_date == ["broken.mp4"]


def test_never_overwrites_an_existing_target(tmp_path: Path) -> None:
    (tmp_path / "Meeting 1.mp4").write_bytes(mp4_bytes("2025-05-01"))
    (tmp_path / "Meeting 1 2025-05-01.mp4").write_bytes(b"existing")

    report = organize_by_date(tmp_path)

    assert (tmp_path / "Meeting 1.mp4").exists()
    assert (tmp_path / "Meeting 1 2025-05-01.mp4").read_bytes() == b"existing"
    assert report.collisions == [("Meeting 1.mp4", "Meeting 1 2025-05-01.mp4")]


def test_second_run_is_a_no_op(tmp_path: Path) -> None:
    (tmp_path / "Meeting 1.mp4").write_bytes(mp4_bytes("2025-05-01"))
    organize_by_date(tmp_path)
    report = organize_by_date(tmp_path)
    assert report.renamed == []
    assert report.already_dated == ["Meeting 1 2025-05-01.mp4"]


def test_missing_folder_raises(tmp_path: Path) -> None:
    with pytest.raises(NotADirectoryError):
        organize_by_date(tmp_path / "nope")


def test_unifies_names_with_a_base(tmp_path: Path) -> None:
    (tmp_path / "Meeting 1.mp4").write_bytes(mp4_bytes("2025-05-01"))
    (tmp_path / "Other 2025-05-01.mp4").write_bytes(mp4_bytes("2025-05-01"))
    (tmp_path / "Recording 1 (7) 2025-08-14.mp4").write_bytes(mp4_bytes("2025-08-14"))
    (tmp_path / "pre 1 (2) 2025-04-24.mp4").write_bytes(mp4_bytes("2025-04-24"))
    (tmp_path / "notes.txt").write_text("keep me")

    report = organize_by_date(tmp_path, base_name="DAV-R")

    names = sorted(path.name for path in tmp_path.iterdir())
    assert names == [
        "DAV-R 2025-04-24.mp4",
        "DAV-R 2025-05-01 (2).mp4",
        "DAV-R 2025-05-01.mp4",
        "DAV-R 2025-08-14.mp4",
        "notes.txt",
    ]
    assert len(report.renamed) == 4


def test_unified_names_are_idempotent(tmp_path: Path) -> None:
    (tmp_path / "Meeting 1.mp4").write_bytes(mp4_bytes("2025-05-01"))
    (tmp_path / "Other 2025-05-01.mp4").write_bytes(mp4_bytes("2025-05-01"))
    organize_by_date(tmp_path, base_name="DAV-R")

    report = organize_by_date(tmp_path, base_name="DAV-R")

    assert report.renamed == []
    assert sorted(report.already_dated) == [
        "DAV-R 2025-05-01 (2).mp4",
        "DAV-R 2025-05-01.mp4",
    ]


def test_base_name_falls_back_to_the_date_in_the_name(tmp_path: Path) -> None:
    (tmp_path / "Meeting 1 2025-01-02.mp4").write_bytes(b"no metadata")
    report = organize_by_date(tmp_path, base_name="DAV-R")
    assert (tmp_path / "DAV-R 2025-01-02.mp4").exists()
    assert report.renamed == [("Meeting 1 2025-01-02.mp4", "DAV-R 2025-01-02.mp4")]
