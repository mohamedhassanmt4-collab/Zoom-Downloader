"""Tests for the fast downloader (parallel connections, resume, fallbacks)."""

from __future__ import annotations

import http.server
import threading
import time
import unittest.mock
from pathlib import Path

import pytest

from zoom_joiner.fastdl import download, human_size

PAYLOAD = bytes(range(256)) * 400  # ~100 KB


class _Handler(http.server.BaseHTTPRequestHandler):
    """Serves a file with range support; optionally throttled to simulate a slow link."""

    delay: float = 0.0
    payload: bytes = PAYLOAD
    hits: list[str] = []

    def do_GET(self) -> None:  # noqa: N802
        if self.hits is not None:
            self.hits.append(self.headers.get("Range", ""))
        rng = self.headers.get("Range")
        start, end = 0, len(self.payload) - 1
        if rng and rng.startswith("bytes="):
            spec = rng.split("=", 1)[1]
            first, _, last = spec.partition("-")
            start = int(first) if first else 0
            end = int(last) if last else end
            end = min(end, len(self.payload) - 1)
            self.send_response(206)
            self.send_header("Content-Range", f"bytes {start}-{end}/{len(self.payload)}")
        else:
            self.send_response(200)
        chunk = self.payload[start : end + 1]
        self.send_header("Content-Type", "video/mp4")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(len(chunk)))
        self.end_headers()
        step = 16 * 1024
        for offset in range(0, len(chunk), step):
            self.wfile.write(chunk[offset : offset + step])
            if self.delay:
                time.sleep(self.delay)

    def log_message(self, *args: object) -> None:
        return


@pytest.fixture
def server():
    handler = type(
        "Handler",
        (_Handler,),
        {"delay": 0.0, "payload": PAYLOAD, "hits": [0]},
    )
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    host, port = httpd.server_address
    yield f"http://127.0.0.1:{port}", handler
    httpd.shutdown()


def test_download_is_byte_identical(server, tmp_path: Path) -> None:
    base, _ = server
    target = tmp_path / "out.mp4"
    assert download(f"{base}/rec/download/file.mp4", target, connections=4) is not None
    assert target.read_bytes() == PAYLOAD


def test_download_reports_progress(server, tmp_path: Path) -> None:
    base, _ = server
    seen: list[int] = []
    target = tmp_path / "progress.mp4"
    download(f"{base}/file.mp4", target, connections=4, progress=seen.append)
    assert seen, "the progress callback was never called"
    assert seen[-1] == len(PAYLOAD)


def test_parallel_is_used_on_a_slow_link(tmp_path: Path) -> None:
    """With latency the parallel path must be faster than a single connection."""
    payload = bytes(range(256)) * 6000  # ~1.5 MB
    handler = type(
        "SlowHandler",
        (_Handler,),
        {"delay": 0.02, "payload": payload, "hits": []},
    )
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    host, port = httpd.server_address
    url = f"http://127.0.0.1:{port}/file.mp4"
    try:
        start = time.monotonic()
        target = tmp_path / "slow.mp4"
        assert download(url, target, connections=8) is not None
        parallel_time = time.monotonic() - start
        assert target.read_bytes() == payload
    finally:
        httpd.shutdown()

    assert parallel_time < 6.0, "the parallel download took too long"


def test_resume_reuses_existing_parts(tmp_path: Path) -> None:
    """A second call must not re-download everything when the parts exist."""
    payload = bytes(range(256)) * 4000
    handler = type("Handler", (_Handler,), {"delay": 0.0, "payload": payload, "hits": []})
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    host, port = httpd.server_address
    url = f"http://127.0.0.1:{port}/file.mp4"
    try:
        target = tmp_path / "resume.mp4"
        # force the parallel path with a tiny threshold
        import zoom_joiner.fastdl as fastdl

        original = fastdl.PARALLEL_MIN_SIZE
        fastdl.PARALLEL_MIN_SIZE = 1024
        try:
            assert download(url, target, connections=4) is not None
        finally:
            fastdl.PARALLEL_MIN_SIZE = original
    finally:
        httpd.shutdown()

    assert target.read_bytes() == payload


def test_human_size() -> None:
    assert human_size(0) == "0.0 B"
    assert human_size(1024) == "1.0 KB"
    assert human_size(5 * 1024 * 1024) == "5.0 MB"



def test_single_stream_resumes_a_previous_piece(server, tmp_path: Path) -> None:
    """Small files take the single-stream path — resume must work there too."""
    from zoom_joiner import fastdl as fastdl_module

    base, handler = server
    target = tmp_path / "resume.mp4"
    part_dir = target.with_suffix(target.suffix + ".parts")
    part_dir.mkdir()
    half = len(PAYLOAD) // 2
    (part_dir / "part-000").write_bytes(PAYLOAD[:half])
    handler.hits.clear()

    result = fastdl_module.download(f"{base}/media.mp4", target)
    assert result is not None
    assert target.read_bytes() == PAYLOAD
    assert not part_dir.exists()
    # the server saw the probe and the continuation at the saved offset,
    # never a fresh restart from byte 0
    assert any(h.endswith(f"{len(PAYLOAD) - 1}") and h.startswith(f"bytes={half}") for h in handler.hits)


def test_parallel_parts_are_reused_not_redownloaded(tmp_path: Path) -> None:
    """On a slow link 3 of 4 stored parts are kept, only the missing one is fetched."""
    import http.server as http_server

    from zoom_joiner import fastdl as fastdl_module

    handler = type(
        "SlowHandler",
        (_Handler,),
        {"delay": 0.02, "payload": PAYLOAD, "hits": []},
    )
    httpd = http_server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{httpd.server_address[1]}"
    target = tmp_path / "par.mp4"
    part_dir = target.with_suffix(target.suffix + ".parts")
    part_dir.mkdir()
    # pretend three of four parts are already on disk with correct bytes
    quarter = len(PAYLOAD) // 4
    for index in range(3):
        start = index * quarter
        (part_dir / f"part-{index:03d}").write_bytes(PAYLOAD[start : (index + 1) * quarter])
    handler.hits.clear()
    with unittest.mock.patch.object(fastdl_module, "PARALLEL_MIN_SIZE", 8):
        assert fastdl_module.download(f"{base}/media.mp4", target, connections=4) is not None
    assert target.read_bytes() == PAYLOAD
    # only the last part was fetched; the first three came from disk
    continued = [h for h in handler.hits if h.startswith(f"bytes={3 * quarter}")]
    assert continued
    assert not any(
        f"bytes={index * quarter}-{(index + 1) * quarter - 1}" in [h for h in handler.hits]
        for index in range(3)
    )
    httpd.shutdown()
