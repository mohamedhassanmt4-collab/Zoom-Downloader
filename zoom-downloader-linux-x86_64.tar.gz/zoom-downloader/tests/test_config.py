from __future__ import annotations

from pathlib import Path

from zoom_joiner.config import load_config


def test_load_yaml(tmp_path: Path) -> None:
    cfg = tmp_path / "m.yaml"
    cfg.write_text(
        """
defaults:
  backend: web
  parallel: 4
  passkey: "111111"
meetings:
  - name: "A"
    url: "https://zoom.us/j/12345678901"
  - url: "https://zoom.us/j/98765432101"
    passcode: "222222"
""",
        encoding="utf-8",
    )
    job = load_config(cfg)
    assert job.settings.parallel == 4
    assert len(job.meetings) == 2
    assert job.meetings[0].passcode == "111111"  # global fallback applied
    assert job.meetings[1].passcode == "222222"


def test_load_csv(tmp_path: Path) -> None:
    cfg = tmp_path / "m.csv"
    cfg.write_text(
        "name,url,passcode\nStandup,https://zoom.us/j/12345678901,999\n", encoding="utf-8"
    )
    job = load_config(cfg)
    assert job.meetings[0].name == "Standup"
    assert job.meetings[0].passcode == "999"


def test_load_txt(tmp_path: Path) -> None:
    cfg = tmp_path / "m.txt"
    cfg.write_text(
        "# comment\nhttps://zoom.us/j/12345678901 123456 Team Sync\nhttps://zoom.us/j/98765432101\n",
        encoding="utf-8",
    )
    job = load_config(cfg)
    assert len(job.meetings) == 2
    assert job.meetings[0].name == "Team Sync"
    assert job.meetings[0].passcode == "123456"
    assert job.meetings[1].passcode == ""


def test_load_json(tmp_path: Path) -> None:
    cfg = tmp_path / "m.json"
    cfg.write_text(
        '{"defaults": {"parallel": 2}, "meetings": [{"url": "https://zoom.us/j/12345678901"}]}',
        encoding="utf-8",
    )
    job = load_config(cfg)
    assert job.settings.parallel == 2
    assert job.meetings[0].url.endswith("12345678901")


def test_unsupported_format(tmp_path: Path) -> None:
    cfg = tmp_path / "m.xml"
    cfg.write_text("<a/>", encoding="utf-8")
    try:
        load_config(cfg)
    except ValueError as exc:
        assert "unsupported" in str(exc)
    else:  # pragma: no cover
        raise AssertionError("expected ValueError")
