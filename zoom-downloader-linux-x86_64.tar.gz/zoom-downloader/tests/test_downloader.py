"""Integration tests for the recording downloader (fast path + fallbacks)."""

from __future__ import annotations

import asyncio
import http.server
import threading
from pathlib import Path

import pytest

from zoom_joiner.downloader import DownloadRequest, RecordingDownloader, _safe_name
from zoom_joiner.fastdl import download as fast_download

VIDEO_BYTES = bytes(range(256)) * 900  # ~230 KB of deterministic data

PASSCODE_HTML = """
<!doctype html>
<html><body>
  <h1>Weekly Team Sync</h1>
  <input type="password" id="passcode" placeholder="Enter the passcode">
  <button onclick="access()">Access</button>
  <script>
    function access() {
      if (document.getElementById('passcode').value !== '123456') {
        document.body.innerHTML = '<p>Invalid passcode</p>'; return;
      }
      // the player streams the file straight from the CDN, like Zoom does
      document.body.innerHTML =
        '<h1>Weekly Team Sync</h1>' +
        '<video src="/rec/download/recording.mp4" autoplay></video>';
    }
  </script>
</body></html>
"""

DELAYED_PASSCODE_HTML = """
<!doctype html>
<html><body>
  <h1>Locked Recording</h1>
  <div id="gate"></div>
  <script>
    setTimeout(() => {
      document.getElementById('gate').innerHTML =
        '<p>Enter the passcode for access</p>' +
        '<input type="password" placeholder="Passcode">' +
        '<button>Confirm</button>';
    }, 1500);
  </script>
</body></html>
"""

OPEN_HTML = """
<!doctype html>
<html><body>
  <h1>Direct Recording</h1>
  <video controls><source src="/media.mp4" type="video/mp4"></video>
</body></html>
"""

DATED_HTML = """
<!doctype html>
<html><body>
  <h1>Dated Recording</h1>
  <span class="start-time-str">May 1, 2025 07:19 PM Cairo</span>
  <video controls><source src="/media.mp4" type="video/mp4"></video>
</body></html>
"""


class _Handler(http.server.BaseHTTPRequestHandler):
    pages: dict[str, str] = {}

    def _serve_video(self, path: str) -> None:
        rng = self.headers.get("Range")
        start, end = 0, len(VIDEO_BYTES) - 1
        if rng and rng.startswith("bytes="):
            spec = rng.split("=", 1)[1]
            first, _, last = spec.partition("-")
            start = int(first) if first else 0
            end = int(last) if last else end
            end = min(end, len(VIDEO_BYTES) - 1)
        chunk = VIDEO_BYTES[start : end + 1]
        if rng:
            self.send_response(206)
            self.send_header("Content-Range", f"bytes {start}-{end}/{len(VIDEO_BYTES)}")
        else:
            self.send_response(200)
        self.send_header("Content-Type", "video/mp4")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(len(chunk)))
        self.end_headers()
        self.wfile.write(chunk)

    def do_GET(self) -> None:  # noqa: N802
        path = self.path.split("?")[0]
        if path.endswith((".mp4", ".m4a")):
            self._serve_video(path)
            return
        page = self.pages.get(path, "<html><body>not found</body></html>")
        if callable(page):
            page = page()
        body = page.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args: object) -> None:
        return


@pytest.fixture
def mock_server():
    handler = type(
        "Handler",
        (_Handler,),
        {"pages": {"/rec": PASSCODE_HTML, "/open": OPEN_HTML, "/rec-late": DELAYED_PASSCODE_HTML,
                   "/dated": DATED_HTML}},
    )
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    host, port = server.server_address
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


def _run_downloader(request: DownloadRequest) -> object:
    downloader = RecordingDownloader(headless=True, parallel=1)

    async def run():
        await downloader.start()
        try:
            return await downloader.download(request)
        finally:
            await downloader.stop()

    return asyncio.run(run())


def test_fast_download_is_byte_identical(mock_server, tmp_path: Path) -> None:
    target = tmp_path / "out.mp4"
    result = fast_download(f"{mock_server}/media.mp4", target, connections=8)
    assert result is not None
    assert target.read_bytes() == VIDEO_BYTES


def test_fast_download_resumes_from_parts(mock_server, tmp_path: Path) -> None:
    target = tmp_path / "resumed.mp4"
    assert fast_download(f"{mock_server}/media.mp4", target, connections=4) is not None
    assert target.read_bytes() == VIDEO_BYTES


def test_download_with_passcode_uses_the_fast_path(mock_server, tmp_path: Path) -> None:
    request = DownloadRequest(
        url=f"{mock_server}/rec?pwd=123456",
        name="Weekly Sync",
        passcode="123456",
        out_dir=str(tmp_path),
    )
    result = _run_downloader(request)
    assert result.status == "done", result.message
    assert result.files
    saved = Path(result.files[0])
    assert saved.exists()
    # the fast path downloads the real bytes, not a browser copy
    assert saved.read_bytes() == VIDEO_BYTES
    assert saved.name.startswith("Weekly Sync")


def test_download_with_wrong_passcode(mock_server, tmp_path: Path) -> None:
    request = DownloadRequest(
        url=f"{mock_server}/rec", name="Bad", passcode="000000", out_dir=str(tmp_path)
    )
    result = _run_downloader(request)
    assert result.status == "failed"
    assert "passcode" in result.message.lower()


def test_passcode_page_without_code_fails_fast(mock_server, tmp_path: Path) -> None:
    import time

    request = DownloadRequest(
        url=f"{mock_server}/rec-late", name="Locked", out_dir=str(tmp_path)
    )
    started = time.monotonic()
    result = _run_downloader(request)
    elapsed = time.monotonic() - started
    assert result.status == "needs-passcode"
    assert "passcode" in result.message.lower()
    assert elapsed < 30  # no 3×180s of waiting for a page that cannot play


def test_download_direct_media(mock_server, tmp_path: Path) -> None:
    request = DownloadRequest(url=f"{mock_server}/open", name="Direct", out_dir=str(tmp_path))
    result = _run_downloader(request)
    assert result.files, result.message
    assert Path(result.files[0]).exists()


def test_safe_name() -> None:
    assert _safe_name("Team Sync / Week #1") == "Team Sync Week #1"
    assert _safe_name('A:B*C?D"E<F>G|H\\I') == "A B C D E F G H I"
    assert _safe_name("  محاضرة ١ ") == "محاضرة ١"  # Arabic names are kept
    assert _safe_name("", "fallback") == "fallback"


def _local_server(pages: dict) -> tuple[http.server.ThreadingHTTPServer, str]:
    handler = type("Handler", (_Handler,), {"pages": pages})
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    host, port = srv.server_address
    return srv, f"http://127.0.0.1:{port}"


AUDIO_ONLY_HTML = """
<!doctype html><html><body>
  <h1>Phone Recording</h1>
  <video src="/media.m4a" autoplay></video>
</body></html>
"""

BLANK_PLAYER_HTML = """
<!doctype html><html><body><h1>Recordings Player Page</h1></body></html>
"""


def test_audio_only_recording_downloads_the_m4a(tmp_path: Path) -> None:
    """The reported bug: audio-only recordings used to fail with
    'no download button found' — the m4a must be fetched like the mp4."""
    srv, base = _local_server({"/audio": AUDIO_ONLY_HTML})
    try:
        request = DownloadRequest(
            url=f"{base}/audio", name="Phone Call", out_dir=str(tmp_path), timeout=10.0
        )
        result = _run_downloader(request)
        assert result.status == "done", result.message
        assert result.files and Path(result.files[0]).suffix == ".m4a"
        assert Path(result.files[0]).read_bytes() == VIDEO_BYTES
    finally:
        srv.shutdown()


def test_failed_attempt_is_retried_automatically(tmp_path: Path) -> None:
    """First page never exposes the file, the second one works — auto retry."""
    state = {"hits": 0}

    def flaky_page() -> str:
        state["hits"] += 1
        return BLANK_PLAYER_HTML if state["hits"] == 1 else OPEN_HTML

    pages = {"/flaky": flaky_page}  # the handler allows callables
    srv, base = _local_server(pages)
    try:
        request = DownloadRequest(
            url=f"{base}/flaky", name="Retry", out_dir=str(tmp_path), retries=1, timeout=2.0
        )
        result = _run_downloader(request)
        assert result.status == "done", result.message
        assert state["hits"] == 2  # exactly one retry
        saved = Path(result.files[0])
        assert saved.read_bytes() == VIDEO_BYTES
    finally:
        srv.shutdown()


def test_humanize_network_errors() -> None:
    from zoom_joiner.downloader import host_resolver_rules, humanize_playwright_error

    text = humanize_playwright_error(
        'Page.goto: net::ERR_NAME_NOT_RESOLVED at https://uni-rostock-de.zoom-x.de/x'
    )
    assert "DNS" in text and "internet" in text
    assert "internet" in humanize_playwright_error("net::ERR_INTERNET_DISCONNECTED")
    assert "proxy/VPN" in humanize_playwright_error("net::ERR_CERT_AUTHORITY_INVALID")
    assert "too long" in humanize_playwright_error("Page.goto: Timeout 60000ms exceeded")
    assert host_resolver_rules({"a.de": "1.2.3.4", "b.de": "5.6.7.8"}) == (
        "MAP a.de 1.2.3.4, MAP b.de 5.6.7.8"
    )


def test_dns_failure_fails_fast_with_a_clear_message(tmp_path: Path) -> None:
    import time

    started = time.monotonic()
    request = DownloadRequest(
        url="https://no-such-host.invalid/rec/share/x", name="Bad", out_dir=str(tmp_path)
    )
    result = _run_downloader(request)
    elapsed = time.monotonic() - started
    assert result.status in {"failed", "network"}
    lowered = result.message.lower()
    assert "resolv" in lowered or "dns" in lowered or "internet" in lowered
    assert elapsed < 30  # no 3×60s of pointless retries


def test_generic_page_titles_are_ignored() -> None:
    from zoom_joiner.downloader import meaningful_title

    assert meaningful_title("Recordings Player Page") == ""
    assert meaningful_title("  zoom  ") == ""
    assert meaningful_title("Lineare Algebra – Woche 1") == "Lineare Algebra – Woche 1"


def test_two_records_with_the_same_name_never_overwrite(mock_server, tmp_path: Path) -> None:
    from zoom_joiner.cli import unique_output_names

    first = DownloadRequest(url=f"{mock_server}/open", name="Same", out_dir=str(tmp_path))
    second = DownloadRequest(url=f"{mock_server}/open", name="Same", out_dir=str(tmp_path))
    assert unique_output_names([first, second], tmp_path) == ["Same", "Same (2)"]
    one = _run_downloader(first)
    two = _run_downloader(second)
    assert one.status == "done" and two.status == "done"
    names = sorted(Path(path).name for path in one.files + two.files)
    assert names == ["Same (2).mp4", "Same.mp4"]
    for path in one.files + two.files:
        assert Path(path).read_bytes() == VIDEO_BYTES


def test_fastdl_reports_the_promised_size(mock_server, tmp_path: Path) -> None:
    totals: list[int] = []
    assert (
        fast_download(f"{mock_server}/media.mp4", tmp_path / "t.mp4", connections=4,
                      on_total=totals.append)
        is not None
    )
    assert totals == [len(VIDEO_BYTES)]


def test_downloader_exposes_the_real_recording_size(mock_server, tmp_path: Path) -> None:
    downloader = RecordingDownloader(headless=True, parallel=1)
    totals: list[int] = []

    async def run():
        await downloader.start()
        try:
            return await downloader.download(
                DownloadRequest(url=f"{mock_server}/open", name="Sized", out_dir=str(tmp_path)),
                on_total=totals.append,
            )
        finally:
            await downloader.stop()

    result = asyncio.run(run())
    assert result.status == "done"
    assert result.expected_bytes == len(VIDEO_BYTES)
    assert totals and totals[-1] == len(VIDEO_BYTES)


def test_cli_stream_reports_the_real_size(mock_server, tmp_path: Path) -> None:
    import json
    import subprocess
    import sys

    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "zoom_joiner",
            "download",
            "--url",
            f"{mock_server}/open",
            "--out",
            str(tmp_path),
            "--stream",
            "--connections",
            "4",
            "--timeout",
            "60",
        ],
        capture_output=True,
        text=True,
        timeout=120,
        check=False,
    )
    assert proc.returncode == 0, proc.stderr[-600:]
    events = [json.loads(line) for line in proc.stdout.splitlines() if line.strip()]
    progress = [event for event in events if event.get("type") == "progress"]
    assert any(int(event.get("total", 0)) == len(VIDEO_BYTES) for event in progress)
    final = [event for event in events if event.get("type") == "done"][0]
    assert final["results"][0]["total"] == len(VIDEO_BYTES)
    assert final["results"][0]["bytes"] == len(VIDEO_BYTES)


def test_done_size_comes_from_the_file_not_the_counter(tmp_path: Path) -> None:
    from zoom_joiner.downloader import _size_on_disk

    video = tmp_path / "a.mp4"
    video.write_bytes(b"x" * 700)
    transcript = tmp_path / "a.vtt"
    transcript.write_bytes(b"y" * 30)
    assert _size_on_disk([str(video), str(transcript)]) == 730
    assert _size_on_disk([]) == 0
    assert _size_on_disk(["/does/not/exist.mp4"]) == 0


def test_progress_never_exceeds_the_promised_size(tmp_path: Path) -> None:
    from zoom_joiner.downloader import DownloadResult

    downloader = RecordingDownloader(headless=True)
    target = tmp_path / "file.mp4"
    expected = {str(target): 1000}
    seen: list[int] = []
    result = DownloadResult(request=DownloadRequest(url="https://example.com/x"))
    hook = downloader._progress_hook(result, expected, target, seen.append)
    hook(250)
    hook(10**12)  # a corrupted counter must not leak into the UI
    assert seen == [250, 1000]
    assert result.total_bytes == 1000


def test_cli_parallel_same_names_stay_isolated(mock_server, tmp_path: Path) -> None:
    import json
    import subprocess
    import sys

    config = tmp_path / "queue.yaml"
    config.write_text(
        "defaults:\n  parallel: 2\nmeetings:\n"
        f'  - name: "Same"\n    url: "{mock_server}/open"\n'
        f'  - name: "Same"\n    url: "{mock_server}/open"\n'
    )
    proc = subprocess.run(
        [sys.executable, "-m", "zoom_joiner", "download", "-f", str(config),
         "--out", str(tmp_path), "--stream", "--connections", "4", "--timeout", "60"],
        capture_output=True, text=True, timeout=120, check=False,
    )
    assert proc.returncode == 0, proc.stderr[-600:]
    events = [json.loads(line) for line in proc.stdout.splitlines() if line.strip()]
    final = [event for event in events if event.get("type") == "done"][0]
    results = final["results"]
    assert [r["status"] for r in results] == ["done", "done"]
    files = sorted(Path(path).name for r in results for path in r["files"])
    assert files == ["Same (2).mp4", "Same.mp4"]
    for result in results:
        size = sum(Path(path).stat().st_size for path in result["files"])
        assert result["bytes"] == size == len(VIDEO_BYTES)
        assert result["total"] == len(VIDEO_BYTES)
    for event in events:
        if event.get("type") == "progress" and event.get("total"):
            assert int(event["bytes"]) <= int(event["total"])


def test_recording_date_is_parsed_from_zoom_text() -> None:
    from zoom_joiner.downloader import parse_recording_date

    assert parse_recording_date("May 1, 2025 07:19 PM Cairo") == "2025-05-01"
    assert parse_recording_date("Sept 30, 2024 09:00 AM") == "2024-09-30"
    assert parse_recording_date("1 May 2025, 19:19") == "2025-05-01"
    assert parse_recording_date("2025-05-01T19:19:00") == "2025-05-01"
    assert parse_recording_date("") == ""
    assert parse_recording_date("not a date") == ""


def test_downloaded_file_name_gets_the_recording_date(mock_server, tmp_path: Path) -> None:
    result = _run_downloader(
        DownloadRequest(url=f"{mock_server}/dated", name="Dated", out_dir=str(tmp_path))
    )
    assert result.status == "done"
    assert [Path(path).name for path in result.files] == ["Dated 2025-05-01.mp4"]
    assert Path(result.files[0]).read_bytes() == VIDEO_BYTES
    assert result.total_bytes == len(VIDEO_BYTES)
