# zoom-joiner — Windows installer
# ---------------------------------------------------------------------------
# Installs "Zoom Downloader" for the current user:
#   powershell -ExecutionPolicy Bypass -File .\setup.ps1
#
#   .\setup.ps1 -Uninstall     remove the app (keeps the recordings queue)
#   .\setup.ps1 -SkipBrowser   skip the Chromium download (offline install)
#
#Requires -Version 5.1
[CmdletBinding()]
param(
    [switch]$Uninstall,
    [switch]$SkipBrowser
)

$ErrorActionPreference = "Stop"

$AppTitle = "Zoom Downloader"
$Developer = "Mohamed Hassan"
$InstallDir = Join-Path $env:LOCALAPPDATA "Programs\ZoomDownloader"
$VenvDir = Join-Path $InstallDir "venv"
$PythonExe = Join-Path $VenvDir "Scripts\python.exe"
$PythonwExe = Join-Path $VenvDir "Scripts\pythonw.exe"
$DataDir = Join-Path $env:LOCALAPPDATA "ZoomDownloader"
$ShortcutPath = Join-Path ([Environment]::GetFolderPath("Programs")) "$AppTitle.lnk"
$SourceDir = $PSScriptRoot

function Say($message) { Write-Host "==> $message" -ForegroundColor Cyan }
function Fail($message) { Write-Host "XX  $message" -ForegroundColor Red; exit 1 }

if ($Uninstall) {
    Say "removing $AppTitle"
    Remove-Item -LiteralPath $ShortcutPath -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "    your saved queue and settings were kept in $DataDir"
    Write-Host "    done."
    exit 0
}

if (-not (Test-Path (Join-Path $SourceDir "pyproject.toml"))) {
    Fail "run setup.ps1 from the folder that contains pyproject.toml"
}

Say "checking Python (3.10 or newer is required)"
$PyExe = $null
$PyArgs = @()
foreach ($name in @("py", "python")) {
    $command = Get-Command $name -ErrorAction SilentlyContinue
    if (-not $command) { continue }
    $extra = @()
    if ($name -eq "py") { $extra = @("-3") }
    & $command.Source @extra -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" 2>$null
    if ($LASTEXITCODE -eq 0) {
        $PyExe = $command.Source
        $PyArgs = $extra
        break
    }
}
if (-not $PyExe) {
    Fail "Python 3.10+ was not found. Install it from python.org and tick 'Add python.exe to PATH'."
}

Say "installing $AppTitle for the current user"
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
if (Test-Path $VenvDir) { Remove-Item -LiteralPath $VenvDir -Recurse -Force }

$venvArgs = @()
$venvArgs += $PyArgs
$venvArgs += @("-m", "venv", $VenvDir)
& $PyExe @venvArgs
if ($LASTEXITCODE -ne 0) { Fail "could not create the virtual environment" }

Say "installing the package"
& $PythonExe -m pip install --upgrade --quiet --retries 5 --timeout 60 pip setuptools wheel
$package = "{0}[gui]" -f $SourceDir
& $PythonExe -m pip install --quiet --retries 5 --timeout 60 $package
if ($LASTEXITCODE -ne 0) { Fail "pip could not install the package" }

if (-not $SkipBrowser) {
    Say "downloading the Chromium engine used to open the recording pages"
    & $PythonExe -m playwright install chromium
    if ($LASTEXITCODE -ne 0) { Fail "could not download Chromium" }
}

Say "creating the launchers"
$icon = Join-Path $InstallDir "icon.ico"
Copy-Item -LiteralPath (Join-Path $SourceDir "src\zoom_joiner\assets\icons\icon.ico") -Destination $icon -Force
$cliLauncher = Join-Path $InstallDir "zoom-downloader.cmd"
@"
@echo off
"$PythonExe" -m zoom_joiner %*
"@ | Set-Content -Encoding Default -Path $cliLauncher

$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($ShortcutPath)
$shortcut.TargetPath = $PythonwExe
$shortcut.Arguments = "-m zoom_joiner app"
$shortcut.WorkingDirectory = $InstallDir
$shortcut.IconLocation = $icon
$shortcut.Description = "Download your Zoom cloud recordings — fast, simple, in parallel."
$shortcut.Save()

Say "verifying the installation"
& $PythonExe -m zoom_joiner --version
if ($LASTEXITCODE -ne 0) { Fail "the launcher does not work" }

Write-Host ""
Write-Host "$AppTitle is installed." -ForegroundColor Green
Write-Host "Developed by $Developer"
Write-Host ""
Write-Host "  Start menu : $AppTitle"
Write-Host "  Command line: $cliLauncher"
Write-Host "  Data folder : $DataDir"
Write-Host ""
Write-Host "Uninstall:  powershell -ExecutionPolicy Bypass -File .\setup.ps1 -Uninstall"
Write-Host ""
