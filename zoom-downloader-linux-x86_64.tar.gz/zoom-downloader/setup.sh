#!/usr/bin/env bash
#
# zoom-joiner — setup installer
# ---------------------------------------------------------------------------
# Installs the zoom-joiner desktop application (native window) and the CLI.
#
#   ./setup.sh              install for the current user      (~/.local)
#   ./setup.sh --system     install for every user on the box (needs sudo)
#   ./setup.sh --uninstall  remove the installation
#
set -euo pipefail

APP_NAME="zoom-joiner"
VERSION="1.4.3"

MODE="user"
DO_UNINSTALL=0
SKIP_BROWSER=0
ASSUME_YES=0

# ------------------------------------------------------------------ helpers ---
say()  { printf '\033[36m==>\033[0m %s\n' "$*"; }
info() { printf '    %s\n' "$*"; }
warn() { printf '\033[33m!!\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[31mXX\033[0m %s\n' "$*" >&2; exit 1; }

usage() {
  cat <<EOF
${APP_NAME} ${VERSION} — setup

  usage: ./setup.sh [options]

  options:
    --system        install for all users (asks for sudo)
    --user          install for the current user only (default)
    --uninstall     remove ${APP_NAME}
    --skip-browser  do not download the Chromium engine (offline install)
    -y, --yes       do not ask questions
    -h, --help      show this help
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --system) MODE="system" ;;
    --user) MODE="user" ;;
    --uninstall) DO_UNINSTALL=1 ;;
    --skip-browser) SKIP_BROWSER=1 ;;
    -y|--yes) ASSUME_YES=1 ;;
    -h|--help) usage; exit 0 ;;
    *) die "unknown option: $1 (try --help)" ;;
  esac
  shift
done

# ------------------------------------------------------------- locate source ---
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "${SCRIPT_DIR}/pyproject.toml" ]]; then
  SRC_DIR="${SCRIPT_DIR}"
elif [[ -f "${SCRIPT_DIR}/../pyproject.toml" ]]; then
  SRC_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
else
  die "cannot find the project sources (pyproject.toml) next to ${SCRIPT_DIR}"
fi

# ------------------------------------------------------------- target paths ----
if [[ "${MODE}" == "system" ]]; then
  INSTALL_DIR="/opt/${APP_NAME}"
  BIN_DIR="/usr/local/bin"
  DESKTOP_DIR="/usr/share/applications"
  NEED_SUDO=1
else
  INSTALL_DIR="${HOME}/.local/share/${APP_NAME}"
  BIN_DIR="${HOME}/.local/bin"
  DESKTOP_DIR="${HOME}/.local/share/applications"
  NEED_SUDO=0
fi

VENV_DIR="${INSTALL_DIR}/venv"
LAUNCH_CLI="${BIN_DIR}/${APP_NAME}"
LAUNCH_GUI="${BIN_DIR}/${APP_NAME}-gui"
DESKTOP_FILE="${DESKTOP_DIR}/${APP_NAME}.desktop"

as_root() {
  if [[ "${EUID}" -eq 0 ]]; then
    "$@"
  elif command -v sudo >/dev/null 2>&1; then
    sudo "$@"
  else
    die "this step needs root — re-run with sudo"
  fi
}

# ---------------------------------------------------------------- uninstall ---
if [[ "${DO_UNINSTALL}" -eq 1 ]]; then
  say "removing ${APP_NAME}"
  if [[ "${MODE}" == "system" ]]; then
    as_root rm -f "${DESKTOP_FILE}" "${LAUNCH_CLI}" "${LAUNCH_GUI}"
    as_root rm -rf "${VENV_DIR}"
  else
    rm -f "${DESKTOP_FILE}" "${LAUNCH_CLI}" "${LAUNCH_GUI}"
    rm -rf "${VENV_DIR}"
  fi
  if [[ -f "${INSTALL_DIR}/queue.json" || -f "${INSTALL_DIR}/settings.json" ]]; then
    info "your saved queue and settings were kept in ${INSTALL_DIR}"
  fi
  info "done."
  exit 0
fi

# ------------------------------------------------------------------- checks ---
say "checking the system"

command -v python3 >/dev/null 2>&1 || die "python3 is required — install it first (apt install python3)"

PY_OK="$(python3 -c 'import sys; print(1 if sys.version_info >= (3, 10) else 0)')"
[[ "${PY_OK}" == "1" ]] || die "python 3.10+ is required (found: $(python3 -V 2>&1))"
info "python: $(python3 -V 2>&1)"

if ! python3 -m venv --help >/dev/null 2>&1; then
  warn "the python venv module is missing — trying to install it"
  if command -v apt-get >/dev/null 2>&1; then
    as_root apt-get update -qq && as_root apt-get install -y -qq python3-venv
  elif command -v dnf >/dev/null 2>&1; then
    as_root dnf install -y python3-virtualenv
  else
    die "install python3-venv manually and run this script again"
  fi
fi

if ! command -v curl >/dev/null 2>&1 && ! command -v wget >/dev/null 2>&1; then
  warn "curl/wget are missing — the Chromium download may fail"
fi

# -------------------------------------------------------------- installation ---
say "installing ${APP_NAME} ${VERSION} (${MODE} mode)"

if [[ "${NEED_SUDO}" -eq 1 && "${EUID}" -ne 0 ]]; then
  say "administrative rights are required for a system-wide install"
  as_root true
  as_root mkdir -p "${INSTALL_DIR}" "${BIN_DIR}" "${DESKTOP_DIR}"
  as_root chown -R "$(id -u):$(id -g)" "${INSTALL_DIR}" 2>/dev/null || true
else
  mkdir -p "${INSTALL_DIR}" "${BIN_DIR}" "${DESKTOP_DIR}"
fi

say "creating the virtual environment"
rm -rf "${VENV_DIR}"
python3 -m venv "${VENV_DIR}"
"${VENV_DIR}/bin/python" -m pip install --upgrade --quiet --retries 5 --timeout 60 pip setuptools wheel
info "installing the application and its dependencies (this takes a minute)"
if ! "${VENV_DIR}/bin/python" -m pip install --quiet --retries 5 --timeout 60 "${SRC_DIR}[gui]"; then
  die "the download failed — check your internet connection and run this script again"
fi
"${VENV_DIR}/bin/python" -c "import zoom_joiner" >/dev/null 2>&1 \
  || die "the installation did not complete correctly — please run this script again"

if [[ "${SKIP_BROWSER}" -eq 0 ]]; then
  say "downloading the Chromium engine used to join the meetings"
  if ! "${VENV_DIR}/bin/python" -m playwright install chromium || \
     ! "${VENV_DIR}/bin/python" -m playwright install chromium; then
    warn "the Chromium download failed — you can retry later with:"
    warn "  ${VENV_DIR}/bin/python -m playwright install chromium"
  fi
  if [[ "${EUID}" -eq 0 ]]; then
    "${VENV_DIR}/bin/python" -m playwright install-deps chromium >/dev/null 2>&1 || true
  fi
fi

say "creating the launchers"
# The launchers call the console script directly: this is immune to the
# "python -m" namespace-package shadowing that breaks a launch when the
# current folder happens to contain a directory with the same name.
cat > "${LAUNCH_CLI}" <<EOF
#!/bin/sh
exec "${VENV_DIR}/bin/${APP_NAME}" "\$@"
EOF
cat > "${LAUNCH_GUI}" <<EOF
#!/bin/sh
exec "${VENV_DIR}/bin/${APP_NAME}" app "\$@"
EOF
chmod +x "${LAUNCH_CLI}" "${LAUNCH_GUI}"

# the application icon (shipped inside the package)
ICON_SRC="$("${VENV_DIR}/bin/python" - <<'PYEOF'
import pathlib
import zoom_joiner

print(pathlib.Path(zoom_joiner.__file__).parent / "assets" / "icons" / "zoom-joiner.png")
PYEOF
)"
ICON_PATH=""
if [[ -f "${ICON_SRC}" ]]; then
  ICON_PATH="${ICON_SRC}"
  THEME_DIR="${INSTALL_DIR}/../icons/hicolor/512x512/apps"
  mkdir -p "${THEME_DIR}" 2>/dev/null || true
  cp -f "${ICON_SRC}" "${THEME_DIR}/zoom-joiner.png" 2>/dev/null || true
fi

cat > "${DESKTOP_FILE}" <<EOF
[Desktop Entry]
Type=Application
Name=Zoom Downloader
GenericName=Zoom recording downloader
Comment=Download your Zoom cloud recordings — fast, simple, in parallel.
Exec=${LAUNCH_GUI}
Icon=${ICON_PATH:-${APP_NAME}}
Terminal=false
Categories=Network;RemoteAccess;Utility;
StartupNotify=true
EOF
chmod 644 "${DESKTOP_FILE}"
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "${DESKTOP_DIR}" >/dev/null 2>&1 || true

# ------------------------------------------------------------------- verify ---
say "verifying the installation"
if ! "${LAUNCH_CLI}" --version >/dev/null 2>&1; then
  die "the launcher does not work — try: ${VENV_DIR}/bin/${APP_NAME} --version"
fi
if ! "${LAUNCH_CLI}" doctor; then
  warn "some optional components are missing (see the table above)"
fi
if [[ -z "${DISPLAY:-}" && -z "${WAYLAND_DISPLAY:-}" ]]; then
  warn "no graphical session detected — open the application from your desktop session"
fi

cat <<EOF

Zoom Downloader ${VERSION} is installed.
Developed by Mohamed Hassan

  Desktop app : ${LAUNCH_GUI}
  Command line: ${LAUNCH_CLI}
  Menu entry  : "Zoom Downloader" in your applications menu

How to use it
  1. open "Zoom Downloader" from the applications menu
  2. paste the recording share link and its passcode
  3. press "Download all recordings"

If a run is interrupted, the unfinished recordings stay in the queue and the
application offers to continue them the next time you open it.

Uninstall:  ${LAUNCH_CLI} --help   (or run: ./setup.sh --uninstall)

EOF
