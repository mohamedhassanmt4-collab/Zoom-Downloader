#!/usr/bin/env bash
# One-shot installer for zoom-joiner on Debian/Ubuntu (and derivatives).
set -euo pipefail

PROJECT_DIR="${1:-$HOME/zoom-joiner}"

echo "==> installing zoom-joiner in ${PROJECT_DIR}"
mkdir -p "${PROJECT_DIR}"
cd "${PROJECT_DIR}"

if [[ ! -d .git ]]; then
  echo "!! expected the project sources in ${PROJECT_DIR} (git clone or copy them first)"
  exit 1
fi

sudo apt-get update
sudo apt-get install -y python3 python3-venv python3-pip xdotool

python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -e .
playwright install chromium
playwright install-deps chromium || true

cat <<'EOF'

Installation complete.

  source ~/.zoom-joiner-venv/bin/activate   # or: source ~/zoom-joiner/.venv/bin/activate
  zoom-joiner doctor
  zoom-joiner init -f ~/zoom-joiner/config/meetings.yaml

EOF
