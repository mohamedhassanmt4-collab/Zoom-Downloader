#!/usr/bin/env python3
"""Render the SVG app icon into PNG sizes (uses Qt, no extra dependencies).

    python tools/render_icons.py
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from PySide6.QtCore import QSize, Qt  # noqa: E402
from PySide6.QtGui import QImage, QPainter  # noqa: E402
from PySide6.QtSvg import QSvgRenderer  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

SIZES = (16, 24, 32, 48, 64, 128, 256, 512)


def render(svg_path: Path, out_dir: Path) -> list[Path]:
    app = QApplication.instance() or QApplication([])
    renderer = QSvgRenderer(str(svg_path))
    out_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    for size in SIZES:
        image = QImage(QSize(size, size), QImage.Format.Format_ARGB32)
        image.fill(Qt.GlobalColor.transparent)
        painter = QPainter(image)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        renderer.render(painter)
        painter.end()
        target = out_dir / f"icon-{size}.png"
        image.save(str(target), "PNG")
        written.append(target)
    # a copy without the size suffix, used by the desktop entry
    main = out_dir / "zoom-joiner.png"
    main.write_bytes((out_dir / "icon-512.png").read_bytes())
    written.append(main)
    del app
    return written


if __name__ == "__main__":
    files = render(ROOT / "src/zoom_joiner/assets/icon.svg", ROOT / "src/zoom_joiner/assets/icons")
    for f in files:
        print("->", f.relative_to(ROOT))
