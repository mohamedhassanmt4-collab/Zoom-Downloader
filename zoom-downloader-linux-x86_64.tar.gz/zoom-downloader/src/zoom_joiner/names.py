"""File-name helpers shared by the desktop app and the command line.

The name a recording will be saved as must be identical everywhere: the list
in the GUI shows it, the CLI picks it, and collision handling compares it.
"""

from __future__ import annotations

import re

_INVALID = re.compile(r'[\\/:*?"<>|\x00-\x1f]+')
_WHITESPACE = re.compile(r"\s+")


def safe_filename(text: str, fallback: str = "recording") -> str:
    """Turn any label into a portable file base name (no extension).

    Only characters that are invalid in a file name are removed; letters from
    any language (Arabic included) are kept.
    """
    cleaned = _INVALID.sub(" ", text or "")
    cleaned = _WHITESPACE.sub(" ", cleaned).strip(" .")
    return cleaned[:80].strip(" .") or fallback
