"""Zoom link parsing and normalisation."""

from __future__ import annotations

import re
from urllib.parse import parse_qs, quote, urlparse

_DIGITS = re.compile(r"\d{9,11}")

_PATTERNS = (
    re.compile(r"zoom\.us/j/(?P<id>\d{9,11})", re.I),
    re.compile(r"zoom\.us/pj/(?P<id>\d{9,11})", re.I),
    re.compile(r"zoom\.us/wc/(?P<id>\d{9,11})/join", re.I),
    re.compile(r"zoom\.us/wc/join\?(?:[^#]*&)?confno=(?P<id>\d{9,11})", re.I),
    re.compile(r"zoom\.us/s/(?P<id>\d{9,11})", re.I),
    re.compile(r"zoom\.us/my/(?P<user>[^/?#]+)", re.I),
)

# "Meeting ID: 123 4567 8901" style, and bare ids
_BARE_ID = re.compile(r"^\s*(\d[\d\s-]{8,20}\d)\s*$")


def extract_meeting_id(url: str) -> str:
    """Return the numeric meeting id contained in *url* (empty string if none)."""
    if not url:
        return ""
    text = url.strip()
    for pattern in _PATTERNS:
        m = pattern.search(text)
        if m and m.groupdict().get("id"):
            return m.group("id")
    bare = _BARE_ID.match(text)
    if bare:
        return re.sub(r"\D", "", bare.group(1))
    digits = _DIGITS.search(text)
    if digits:
        return digits.group(0)
    return ""


def extract_query_value(url: str, key: str) -> str:
    """Pull a query-string parameter out of a url, tolerant of missing scheme."""
    try:
        parsed = urlparse(url if "//" in url else "https://" + url)
    except ValueError:
        return ""
    values = parse_qs(parsed.query).get(key, [])
    return values[0] if values else ""


def is_valid(url: str) -> bool:
    return bool(extract_meeting_id(url))


def canonical_join_url(meeting_id: str, name: str = "", passcode: str = "") -> str:
    """Build the web-client guest join URL for a numeric meeting id.

    ``https://zoom.us/wc/join?confno=<id>&un=<name>`` is the endpoint the Zoom
    web client accepts for guest entry and it works without an account.
    """
    if not meeting_id:
        return ""
    url = f"https://zoom.us/wc/join?confno={meeting_id}"
    if name:
        url += "&un=" + quote(name, safe="")
    if passcode:
        url += f"&pwd={quote(passcode, safe='')}"
    return url


def is_host_link(url: str) -> bool:
    """True for ``/pj/`` links where the passcode makes you the host."""
    return bool(re.search(r"zoom\.us/pj/\d{9,11}", url or "", re.I))


def display_title(meeting_id: str, fallback: str = "") -> str:
    if meeting_id:
        pretty = meeting_id
        if len(meeting_id) == 11 or len(meeting_id) == 10:
            pretty = f"{meeting_id[:3]} {meeting_id[3:6]} {meeting_id[6:]}"
        return pretty
    return fallback
