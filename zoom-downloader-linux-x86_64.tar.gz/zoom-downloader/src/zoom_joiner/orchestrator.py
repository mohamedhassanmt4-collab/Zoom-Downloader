"""Concurrency orchestrator: runs many joins at once with retries and live status."""

from __future__ import annotations

import asyncio
import logging
import threading
from collections.abc import Callable
from datetime import datetime

from .config import Settings
from .models import Meeting, MeetingResult, Status

log = logging.getLogger("zoom_joiner")

ProgressHook = Callable[[MeetingResult], None]


class Orchestrator:
    """Runs a list of meetings against a backend with a bounded worker pool."""

    def __init__(
        self,
        backend,
        settings: Settings,
        results: list[MeetingResult],
        on_update: ProgressHook | None = None,
        cancel_event: threading.Event | None = None,
    ) -> None:
        self.backend = backend
        self.settings = settings
        self.results = results
        self.on_update = on_update
        self.cancel_event = cancel_event or threading.Event()
        self._sem = asyncio.Semaphore(max(1, settings.parallel))

    def cancel(self) -> None:
        """Ask the batch to stop as soon as possible."""
        self.cancel_event.set()

    @property
    def cancelled(self) -> bool:
        return self.cancel_event.is_set()

    async def run(self) -> list[MeetingResult]:
        await self.backend.start()
        try:
            await asyncio.gather(*(self._worker(r) for r in self.results))
        finally:
            await self.backend.stop()
        return self.results

    async def _worker(self, result: MeetingResult) -> None:
        async with self._sem:
            if self.cancelled:
                result.status = Status.SKIPPED
                result.message = "skipped (the batch was stopped)"
                self._notify(result)
                return
            attempts = self.settings.retries + 1
            for attempt in range(1, attempts + 1):
                if self.cancelled:
                    result.status = Status.SKIPPED
                    result.message = "skipped (the batch was stopped)"
                    break
                result.attempts = attempt
                result.started_at = datetime.now()
                try:
                    await self.backend.join(result.meeting, result)
                except Exception as exc:  # noqa: BLE001 - never kill the whole batch
                    log.exception("unexpected failure on %s", result.meeting.display_name())
                    result.status = Status.FAILED
                    result.message = f"internal error: {exc}"
                result.finished_at = datetime.now()
                if result.status.is_success or result.status is Status.SKIPPED:
                    break
                if attempt < attempts:
                    await asyncio.sleep(min(2**attempt, 8))
            self._notify(result)

    def _notify(self, result: MeetingResult) -> None:
        if self.on_update:
            try:
                self.on_update(result)
            except Exception:  # noqa: BLE001 - UI must never break the run
                log.exception("progress hook failed")


def make_results(meetings: list[Meeting]) -> list[MeetingResult]:
    return [MeetingResult(meeting=m) for m in meetings]
