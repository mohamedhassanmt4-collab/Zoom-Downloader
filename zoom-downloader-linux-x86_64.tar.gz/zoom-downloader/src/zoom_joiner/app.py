"""Native desktop application (PySide6 / Qt) — downloads finished Zoom recordings.

A share link + passcode turns into the mp4 on disk. The heavy work runs in a
*separate process* (``zoom_joiner download --stream``), so a crash in the
browser engine can never take the window down. The recording list is persisted
after every state change: if a download is interrupted (window closed, machine
rebooted, network dropped) the unfinished items are restored on the next launch.
"""

from __future__ import annotations

import contextlib
import json
import os
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path
from urllib.parse import urlparse

from PySide6.QtCore import QObject, QProcess, Qt, Signal
from PySide6.QtGui import QColor, QFont, QIcon, QPalette
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFrame,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .names import safe_filename
from .organize import organize_by_date
from .store import APP_DIR, load_downloads, save_downloads

APP_NAME = "zoom-joiner"
APP_TITLE = "Zoom Downloader"
APP_TAGLINE = "Download your Zoom cloud recordings — fast, simple, in parallel."
DEVELOPER = "Mohamed Hassan"
APP_VERSION = "1.5.2"


STYLESHEET = """
QWidget { color:#e7ecf3; font-size:13px; }
QMainWindow, QDialog { background:#0e1117; }

QProgressBar#mini {
    background:#1d2430; border:none; border-radius:4px; margin:10px 8px;
}
QProgressBar#mini::chunk { background:#3b82f6; border-radius:4px; }

/* ---------- surfaces ---------- */
QFrame#card { background:#151a23; border:1px solid #232a36; border-radius:12px; }
QGroupBox {
    background:#151a23; border:1px solid #232a36; border-radius:12px;
    margin-top:20px; padding:10px 16px 16px 16px; font-weight:600;
}
QGroupBox::title {
    subcontrol-origin: margin; subcontrol-position: top left;
    left:14px; top:2px; padding:2px 10px; color:#c8d1de;
    background:transparent;
}
QLabel#title { font-size:21px; font-weight:700; color:#f2f5fa; }
QLabel#subtitle { color:#8d97a8; font-size:12px; }
QLabel#credit { color:#5c6678; font-size:11px; }
QLabel#hint { color:#7c879a; font-size:12px; }
QLabel#step { color:#e7ecf3; font-size:13px; font-weight:600; }
QLabel#chip {
    background:#1b2029; border:1px solid #2b3340; border-radius:13px;
    padding:5px 13px; color:#c3cbd8; font-size:12px;
}
QLabel#empty { color:#68738a; font-size:14px; }

/* ---------- inputs ---------- */
QLineEdit, QPlainTextEdit, QSpinBox, QComboBox {
    background:#10141b; border:1px solid #2b3340; border-radius:8px;
    padding:7px 10px; min-height:18px; selection-background-color:#3b82f6;
}
QLineEdit:focus, QPlainTextEdit:focus, QComboBox:focus { border-color:#3b82f6; }
QLineEdit:disabled, QComboBox:disabled { color:#5c6472; background:#141821; }
QComboBox::drop-down { border:none; width:22px; }
QComboBox::down-arrow { image:none; border-left:4px solid transparent;
                         border-right:4px solid transparent; border-top:5px solid #8d97a8;
                         width:0; height:0; margin-right:8px; }

/* ---------- buttons ---------- */
QPushButton {
    background:#1b2029; border:1px solid #2b3340; border-radius:8px;
    padding:9px 16px; color:#dbe2ec; min-height:18px;
}
QPushButton:hover { background:#222a35; border-color:#39424f; }
QPushButton:pressed { background:#1a1f27; }
QPushButton:disabled { color:#59616f; background:#161b23; border-color:#232a36; }
QPushButton#primary { background:#3b82f6; border:1px solid #3b82f6; color:#fff; font-weight:600; }
QPushButton#primary:hover { background:#2f6fe0; border-color:#2f6fe0; }
QPushButton#primary:disabled { background:#26313f; border-color:#26313f; color:#6b7688; }
QPushButton#danger { background:#2a1a1d; border:1px solid #59262b; color:#f87171; }
QPushButton#danger:hover { background:#351d21; }
QPushButton#danger:disabled { background:#161b23; border-color:#232a36; color:#59616f; }
QPushButton#ghost { background:transparent; border:1px solid #2b3340; color:#9aa5b5; }
QPushButton#ghost:hover { background:#1b2029; color:#e7ecf3; }

/* ---------- table ---------- */
QTableWidget {
    background:#10141b; alternate-background-color:#141a23; border:1px solid #232a36;
    border-radius:10px; gridline-color:#1c222c; outline:0;
}
QTableWidget::item { padding:6px 8px; border:0; }
QTableWidget::item:selected { background:#1e2a3d; color:#fff; }
QHeaderView::section {
    background:#171c25; color:#8d97a8; border:0; border-bottom:1px solid #232a36;
    padding:9px 8px; font-size:11px; font-weight:600; letter-spacing:.6px;
}
QTableCornerButton::section { background:#171c25; border:0; }

/* ---------- misc ---------- */
QProgressBar { background:#10141b; border:1px solid #232a36; border-radius:6px; height:8px; }
QProgressBar::chunk { background:#3b82f6; border-radius:5px; }
QPlainTextEdit#log {
    background:#0a0d12; border:1px solid #232a36; border-radius:10px;
    font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace; font-size:12px;
    color:#9fb0c8; padding:8px;
}
QCheckBox { color:#c3cbd8; spacing:8px; padding:2px 0; }
QCheckBox::indicator { width:15px; height:15px; border:1px solid #39424f; border-radius:4px; background:#10141b; }
QCheckBox::indicator:checked { background:#3b82f6; border-color:#3b82f6; }
QScrollArea { background:transparent; border:0; }
QScrollBar:vertical { background:transparent; width:11px; margin:2px; }
QScrollBar::handle:vertical { background:#2b3340; border-radius:5px; min-height:32px; }
QScrollBar::handle:vertical:hover { background:#39424f; }
QScrollBar::add-line, QScrollBar::sub-line { height:0; width:0; }
QScrollBar::add-page, QScrollBar::sub-page { background:transparent; }
QTabWidget::pane { border:0; }
QTabBar::tab {
    background:transparent; color:#8d97a8; padding:10px 20px; margin-right:6px;
    border:1px solid transparent; border-bottom:2px solid transparent; border-radius:8px;
}
QTabBar::tab:hover { color:#dbe2ec; background:#151a23; }
QTabBar::tab:selected { color:#fff; background:#1b2029; border-color:#2b3340; border-bottom:2px solid #3b82f6; }
QToolTip { background:#1b2029; color:#e7ecf3; border:1px solid #2b3340; padding:6px; }
"""


# --------------------------------------------------------------------------------------
# small helpers
# --------------------------------------------------------------------------------------
def dark_palette() -> QPalette:
    """A dark palette so every widget that the stylesheet does not touch is dark too."""
    pal = QPalette()
    pal.setColor(QPalette.ColorRole.Window, QColor("#0e1117"))
    pal.setColor(QPalette.ColorRole.WindowText, QColor("#e7ecf3"))
    pal.setColor(QPalette.ColorRole.Base, QColor("#10141b"))
    pal.setColor(QPalette.ColorRole.AlternateBase, QColor("#141a23"))
    pal.setColor(QPalette.ColorRole.Text, QColor("#e7ecf3"))
    pal.setColor(QPalette.ColorRole.Button, QColor("#1b2029"))
    pal.setColor(QPalette.ColorRole.ButtonText, QColor("#dbe2ec"))
    pal.setColor(QPalette.ColorRole.BrightText, QColor("#ff6b6b"))
    pal.setColor(QPalette.ColorRole.Highlight, QColor("#3b82f6"))
    pal.setColor(QPalette.ColorRole.HighlightedText, QColor("#ffffff"))
    pal.setColor(QPalette.ColorRole.ToolTipBase, QColor("#1b2029"))
    pal.setColor(QPalette.ColorRole.ToolTipText, QColor("#e7ecf3"))
    pal.setColor(QPalette.ColorRole.PlaceholderText, QColor("#5d687a"))
    pal.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text, QColor("#59616f"))
    pal.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, QColor("#59616f"))
    pal.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.WindowText, QColor("#59616f"))
    return pal


ASSETS_DIR = Path(__file__).resolve().parent / "assets"


def app_icon() -> QIcon:
    """The application icon (SVG first, PNG as a fallback)."""
    svg = ASSETS_DIR / "icon.svg"
    if svg.exists():
        icon = QIcon(str(svg))
        if not icon.isNull():
            return icon
    png = ASSETS_DIR / "icons" / "icon-256.png"
    return QIcon(str(png)) if png.exists() else QIcon()


def scrollable(widget: QWidget) -> QScrollArea:
    """Put a panel inside a scroll area so nothing gets crushed on small screens."""
    area = QScrollArea()
    area.setWidgetResizable(True)
    area.setFrameShape(QFrame.Shape.NoFrame)
    area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    area.setStyleSheet("background:transparent;")
    area.setWidget(widget)
    return area


def _to_yaml(payload: dict) -> str:
    """Tiny YAML writer (keeps the GUI process free of a PyYAML dependency)."""

    def scalar(value: object) -> str:
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, (int, float)):
            return str(value)
        text = str(value).replace("\\", "\\\\").replace('"', '\\"')
        return f'"{text}"'

    lines: list[str] = []
    defaults = payload.get("defaults") or {}
    if defaults:
        lines.append("defaults:")
        for key, value in defaults.items():
            lines.append(f"  {key}: {scalar(value)}")
        lines.append("")
    lines.append("meetings:")
    for item in payload.get("meetings") or []:
        first = True
        for key, value in item.items():
            prefix = "  - " if first else "    "
            lines.append(f"{prefix}{key}: {scalar(value)}")
            first = False
    return "\n".join(lines) + "\n"


def form_row(label: str, widget: QWidget, label_width: int = 132) -> QWidget:
    """A label + field row with a fixed label column (never overlaps)."""
    row = QWidget()
    row_layout = QHBoxLayout(row)
    row_layout.setContentsMargins(0, 0, 0, 0)
    row_layout.setSpacing(10)
    caption = QLabel(label)
    caption.setFixedWidth(label_width)
    caption.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
    caption.setObjectName("hint")
    row_layout.addWidget(caption)
    row_layout.addWidget(widget, 1)
    return row


def card(title: str, subtitle: str = "") -> tuple[QGroupBox, QVBoxLayout]:
    """A titled card with a consistent inner layout."""
    box = QGroupBox(title)
    box_layout = QVBoxLayout(box)
    box_layout.setContentsMargins(0, 4, 0, 0)
    box_layout.setSpacing(12)
    if subtitle:
        caption = QLabel(subtitle)
        caption.setObjectName("hint")
        caption.setWordWrap(True)
        box_layout.addWidget(caption)
    return box, box_layout


def empty_state(title: str, subtitle: str) -> QWidget:
    """Friendly placeholder shown when a list is still empty."""
    holder = QWidget()
    layout = QVBoxLayout(holder)
    layout.setContentsMargins(24, 40, 24, 40)
    layout.setSpacing(8)
    layout.addStretch(1)
    head = QLabel(title)
    head.setAlignment(Qt.AlignmentFlag.AlignCenter)
    head.setObjectName("empty")
    body = QLabel(subtitle)
    body.setAlignment(Qt.AlignmentFlag.AlignCenter)
    body.setObjectName("hint")
    body.setWordWrap(True)
    layout.addWidget(head)
    layout.addWidget(body)
    layout.addStretch(1)
    return holder


# --------------------------------------------------------------------------------------
# worker
# --------------------------------------------------------------------------------------
class BatchProcess(QObject):
    """Runs ``zoom_joiner … --stream`` in a child process and relays the events."""

    event = Signal(dict)
    log = Signal(str)
    finished = Signal(int)

    def __init__(self) -> None:
        super().__init__()
        self.proc = QProcess(self)
        self.proc.setProcessChannelMode(QProcess.ProcessChannelMode.SeparateChannels)
        self.proc.readyReadStandardOutput.connect(self._read_stdout)
        self.proc.readyReadStandardError.connect(self._read_stderr)
        self.proc.finished.connect(self._on_finished)
        self._buffer = ""
        self.row_id = ""
        self._config_path: Path | None = None
        self._log_file: object | None = None

    # -- public ------------------------------------------------------------------
    def start(
        self,
        items: list[dict[str, str]],
        options: dict[str, object],
        out_dir: Path | None = None,
        command: str = "run",
        extra_args: list[str] | None = None,
    ) -> None:
        out_dir = out_dir or Path.cwd() / "reports"
        out_dir.mkdir(parents=True, exist_ok=True)
        fd, path = tempfile.mkstemp(prefix="zoom-joiner-", suffix=".yaml")
        os.close(fd)
        self._config_path = Path(path)
        payload = {"defaults": options, "meetings": items}
        self._config_path.write_text(_to_yaml(payload), encoding="utf-8")

        args = [
            "-m",
            "zoom_joiner",
            command,
            "-f",
            str(self._config_path),
            "--stream",
            "--out",
            str(out_dir),
        ]
        if command == "run":
            args.append("--quiet")
        args += list(extra_args or [])
        with contextlib.suppress(OSError):
            APP_DIR.mkdir(parents=True, exist_ok=True)
            if self._log_file:
                self._log_file.close()
            self._log_file = (APP_DIR / "last-run.log").open("w", encoding="utf-8")
            self._log_file.write(f"# zoom-joiner {APP_VERSION} — {' '.join(args)}\n")
            self._log_file.flush()
        self.proc.start(sys.executable, args)

    def stop(self) -> None:
        if self.proc.state() != QProcess.ProcessState.NotRunning:
            self.proc.terminate()

    def is_running(self) -> bool:
        return self.proc.state() != QProcess.ProcessState.NotRunning

    # -- internals ---------------------------------------------------------------
    def _read_stdout(self) -> None:
        chunk = bytes(self.proc.readAllStandardOutput()).decode("utf-8", "replace")
        self._buffer += chunk
        while "\n" in self._buffer:
            line, self._buffer = self._buffer.split("\n", 1)
            line = line.strip()
            if not line:
                continue
            if self._log_file:
                with contextlib.suppress(OSError):
                    self._log_file.write(line + "\n")
            try:
                self.event.emit(json.loads(line))
            except json.JSONDecodeError:
                self.log.emit(line)

    def _read_stderr(self) -> None:
        text = bytes(self.proc.readAllStandardError()).decode("utf-8", "replace").strip()
        for line in text.splitlines():
            if self._log_file:
                with contextlib.suppress(OSError):
                    self._log_file.write(line + "\n")
            self.log.emit(line)

    def _on_finished(self, code: int, _status) -> None:
        if self._config_path and self._config_path.exists():
            self._config_path.unlink(missing_ok=True)
        if self._log_file:
            with contextlib.suppress(OSError):
                self._log_file.close()
            self._log_file = None
        self.finished.emit(code)


# --------------------------------------------------------------------------------------
# main window
# --------------------------------------------------------------------------------------
class MainWindow(QWidget):
    """Application shell — everything here is about downloading recordings."""

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"{APP_TITLE} — by {DEVELOPER}")
        self.resize(1320, 860)
        self.setMinimumSize(1080, 700)

        self._build_ui()

    # -- UI ----------------------------------------------------------------------
    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        root.setSpacing(14)
        root.addLayout(self._build_header())

        self.download_panel = DownloadPanel()
        self.download_panel.status_changed.connect(self._on_download_status)
        root.addWidget(self.download_panel, 1)

    def _build_header(self) -> QHBoxLayout:
        row = QHBoxLayout()
        row.setSpacing(12)

        logo = QLabel("↓")
        logo.setFixedSize(40, 40)
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo.setStyleSheet(
            "background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #4f8ef7,stop:1 #2456d6);"
            "color:#fff; border-radius:11px; font-size:21px; font-weight:700;"
        )
        titles = QVBoxLayout()
        titles.setSpacing(1)
        title = QLabel(APP_TITLE)
        title.setObjectName("title")
        subtitle = QLabel(APP_TAGLINE)
        subtitle.setObjectName("subtitle")
        credit = QLabel(f"Developed by {DEVELOPER}")
        credit.setObjectName("credit")
        titles.addWidget(title)
        titles.addWidget(subtitle)
        titles.addWidget(credit)

        self.status_label = QLabel("idle")
        self.status_label.setObjectName("chip")

        btn_help = QPushButton("How to use")
        btn_help.setObjectName("ghost")
        btn_help.setToolTip("Step-by-step instructions for this screen")
        btn_help.clicked.connect(self._show_help)

        row.addWidget(logo)
        row.addLayout(titles)
        row.addStretch(1)
        row.addWidget(self.status_label)
        row.addWidget(btn_help)
        return row

    def _on_download_status(self, text: str) -> None:
        self.status_label.setText(text)

    # -- helpers -----------------------------------------------------------------
    def _show_help(self) -> None:
        text = (
            "<b>Downloading a recording</b><br><br>"
            "1. Open the e-mail or the chat where Zoom shared the recording and copy the "
            "<b>share link</b> (it looks like https://us06web.zoom.us/rec/share/… - the link may "
            "also arrive in the meeting chat).<br>"
            "2. Copy the <b>passcode</b> — if the link already contains <code>?pwd=…</code> "
            "you can leave the field empty.<br>"
            "3. Paste the link in the box on the left, press <b>Add to the list</b>.<br>"
            "4. Choose the folder where the files should be saved.<br>"
            "5. Press <b>Download all recordings</b>.<br><br>"
            "The program grabs the video straight from Zoom's CDN with parallel connections — "
            "same quality, much faster. You can also tick <b>audio only</b> and/or the "
            "<b>transcript</b>.<br><br>"
            "<b>The list works like a queue.</b> Add more links at any time — they join the "
            "running queue and take their turn automatically. <b>Pause</b> stops new downloads "
            "and keeps the parts already written; <b>Resume</b> continues, even after a reboot.<br><br>"
            "<b>Names:</b> the “Recording” name is used for the saved file. Right-click a row "
            "(or double-click it) to rename it, or select several rows and choose "
            "<b>Name as a sequence</b> to number them (e.g. Lecture 1…12). Two files can never "
            "overwrite each other — a duplicate name is saved as “Name (2)”.<br><br>"
            "If the owner restricted the recording, Zoom asks you to sign in first — open the "
            "link once in your browser, sign in, then retry here."
        )
        box = QMessageBox(self)
        box.setWindowTitle(f"How to use {APP_TITLE}")
        box.setIcon(QMessageBox.Icon.Information)
        box.setTextFormat(Qt.TextFormat.RichText)
        box.setText(text)
        box.exec()

    def closeEvent(self, event) -> None:  # noqa: N802
        self.download_panel.shutdown()
        super().closeEvent(event)


# --------------------------------------------------------------------------------------
def _combo(values: list[str], current: str) -> QComboBox:
    box = QComboBox()
    box.addItems(values)
    idx = box.findText(current)
    if idx >= 0:
        box.setCurrentIndex(idx)
    return box


class DownloadPanel(QWidget):
    """Everything about downloading finished Zoom recordings (share link + passcode)."""

    status_changed = Signal(str)

    def __init__(self) -> None:
        super().__init__()
        self._rows: list[dict[str, str]] = []
        self._out_dir = str(Path.home() / "Downloads" / "zoom-recordings")
        self._jobs: dict[str, BatchProcess] = {}
        self._mode = "idle"  # idle | running | paused

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)
        layout.addWidget(self._build_toolbar())

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)
        splitter.addWidget(scrollable(self._build_left()))
        splitter.addWidget(self._build_right())
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([430, 880])
        layout.addWidget(splitter, 1)
        self._restore()

    # -- persistence -------------------------------------------------------------
    def _restore(self) -> None:
        rows, out_dir, default_passcode = load_downloads()
        if out_dir:
            self._out_dir = out_dir
            self.ed_out.setText(out_dir)
        if default_passcode and not self.ed_passcode.text().strip():
            self.ed_passcode.setText(default_passcode)
        self._rows = rows
        for row in self._rows:
            row.setdefault("id", uuid.uuid4().hex[:12])
        resumed = 0
        for row in rows:
            if row.get("status") in {"opening", "downloading"}:
                row["status"] = "pending"
                row["message"] = ""
                row.pop("bytes", None)
                row.pop("total", None)
            if row.get("status") != "done":
                resumed += 1
        self._refresh_table()
        if resumed:
            self.log(
                f"Restored {len(rows)} recording(s) from the last session — {resumed} "
                "did not finish yet; press “Download all recordings” to continue."
            )
        elif rows:
            self.log(f"Restored {len(rows)} recording(s) from the last session")
        self._update_buttons()

    def persist(self) -> None:
        save_downloads(self._rows, self._out_dir, self.ed_passcode.text().strip())

    def shutdown(self) -> None:
        if self._jobs:
            self._pause_active()
            self.log("Stopping — the finished files stay on disk and resume next time")
        self._mode = "idle"
        self.persist()

    # -- UI ----------------------------------------------------------------------
    def _build_toolbar(self) -> QWidget:
        holder = QFrame()
        holder.setObjectName("card")
        row = QHBoxLayout(holder)
        row.setContentsMargins(16, 12, 16, 12)
        row.setSpacing(10)

        self.btn_start = QPushButton("Download all recordings")
        self.btn_start.setObjectName("primary")
        self.btn_start.setMinimumHeight(38)
        self.btn_start.setToolTip("Download every recording in the list")
        self.btn_start.clicked.connect(self.start_downloads)

        self.btn_pause = QPushButton("Pause")
        self.btn_pause.setObjectName("danger")
        self.btn_pause.setMinimumHeight(38)
        self.btn_pause.setEnabled(False)
        self.btn_pause.setToolTip("Pause or resume the queue — partial files are kept")
        self.btn_pause.clicked.connect(self.toggle_pause)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(8)

        self.status_label = QLabel("idle")
        self.status_label.setObjectName("chip")

        row.addWidget(self.btn_start)
        row.addWidget(self.btn_pause)
        row.addSpacing(8)
        row.addWidget(self.progress, 1)
        row.addWidget(self.status_label)
        return holder

    def _build_left(self) -> QWidget:
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 12, 0)
        layout.setSpacing(14)

        box, box_layout = card(
            "1 · Paste the recording links",
            "One recording per line. Format:  share link  passcode  name  (name is optional).",
        )
        self.links_edit = QPlainTextEdit()
        self.links_edit.setPlaceholderText(
            "https://us06web.zoom.us/rec/share/AbCdEf... 123456 Weekly Team Sync\n"
            "https://us06web.zoom.us/rec/share/XyZ123... 654321 Client Review"
        )
        self.links_edit.setMinimumHeight(120)
        self.links_edit.setFont(QFont("ui-monospace", 10))
        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)
        btn_add = QPushButton("Add to the list")
        btn_add.setObjectName("primary")
        btn_add.clicked.connect(self.add_links)
        btn_clip = QPushButton("Paste from clipboard")
        btn_clip.clicked.connect(self.paste_clipboard)
        btn_row.addWidget(btn_add)
        btn_row.addWidget(btn_clip)
        btn_row.addStretch(1)
        box_layout.addWidget(self.links_edit)
        box_layout.addLayout(btn_row)
        layout.addWidget(box)

        opts, opts_layout = card("2 · Options", "Where the files go and what to download.")
        self.ed_passcode = QLineEdit()
        self.ed_passcode.setPlaceholderText("used when a link has no passcode")
        self.ed_out = QLineEdit(self._out_dir)
        self.cmb_parallel = _combo([str(n) for n in range(1, 7)], "2")
        self.cmb_parallel.setToolTip("How many recordings to download at the same time")
        self.cmb_parallel.currentTextChanged.connect(self._parallel_changed)
        self.cmb_connections = _combo(["2", "4", "8", "16"], "8")
        self.cmb_connections.setToolTip(
            "Connections used for each file — more is faster, the quality is identical"
        )

        opts_layout.addWidget(form_row("Default passcode", self.ed_passcode))
        opts_layout.addWidget(form_row("Save to", self.ed_out))
        opts_layout.addWidget(form_row("Parallel downloads", self.cmb_parallel))
        opts_layout.addWidget(form_row("Connections per file", self.cmb_connections))

        self.chk_video = QCheckBox("Video file (mp4)")
        self.chk_video.setChecked(True)
        self.chk_audio = QCheckBox("Audio only (m4a)")
        self.chk_transcript = QCheckBox("Transcript (vtt)")
        opts_layout.addWidget(self.chk_video)
        opts_layout.addWidget(self.chk_audio)
        opts_layout.addWidget(self.chk_transcript)
        layout.addWidget(opts)

        organize, organize_layout = card(
            "Organize an existing folder",
            "Type a base name to unify every file as “Name YYYY-MM-DD.mp4” "
            "(numbered when two recordings share a date), or leave it empty to "
            "only add missing dates. The date is read from the video metadata, "
            "so files downloaded earlier work too. Uses the “Save to” folder above.",
        )
        self.ed_organize_name = QLineEdit()
        self.ed_organize_name.setPlaceholderText("e.g. DAV-R — optional")
        organize_layout.addWidget(form_row("Base name", self.ed_organize_name))
        self.btn_organize = QPushButton("Rename files by date")
        self.btn_organize.setObjectName("ghost")
        self.btn_organize.setMinimumHeight(34)
        self.btn_organize.setToolTip(
            "Read the date from each MP4/M4A and add it to the file name; "
            "existing names are never overwritten"
        )
        self.btn_organize.clicked.connect(self.organize_files)
        organize_layout.addWidget(self.btn_organize)
        layout.addWidget(organize)

        contact, contact_layout = card("Feedback & suggestions", "")
        self.contact_label = QLabel(
            "Made by <b>Mohamed Hassan</b><br>"
            '<a href="mailto:mohamedhassanmt4@gmail.com">'
            "mohamedhassanmt4@gmail.com</a>"
        )
        self.contact_label.setObjectName("hint")
        self.contact_label.setOpenExternalLinks(True)
        self.contact_label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextBrowserInteraction
        )
        contact_layout.addWidget(self.contact_label)
        layout.addWidget(contact)

        tip, tip_layout = card("Where do I find the link?", "")
        tip_text = QLabel(
            "Zoom sends the recording link by e-mail or in the chat of the meeting. "
            "It starts with <b>https://…/rec/share/</b> and usually ends with "
            "<code>?pwd=123456</code> — that code is the passcode."
        )
        tip_text.setWordWrap(True)
        tip_text.setObjectName("hint")
        tip_layout.addWidget(tip_text)
        layout.addWidget(tip)
        layout.addStretch(1)
        return panel

    def _build_right(self) -> QWidget:
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)

        list_box, list_layout = card(
            "3 · Recording list",
            "The name is the file name. Right-click a row to rename it or to number "
            "several rows in one go; double-click to rename.",
        )
        self.table_stack = QStackedWidget()
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(
            ["Recording", "Passcode", "Status", "Progress", "Size / details"]
        )
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setMinimumHeight(240)
        self.table.setShowGrid(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._table_menu)
        self.table.cellDoubleClicked.connect(self._cell_double_clicked)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)
        self.table.setColumnWidth(3, 110)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        header.setHighlightSections(False)
        self.table_empty = empty_state(
            "No recordings yet",
            "Paste the share links on the left, press “Add to the list”, then "
            "“Download all recordings”.",
        )
        self.table_stack.addWidget(self.table_empty)
        self.table_stack.addWidget(self.table)
        list_layout.addWidget(self.table_stack, 1)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)
        btn_remove = QPushButton("Remove selected")
        btn_remove.clicked.connect(self.remove_selected)
        btn_browse = QPushButton("Change folder…")
        btn_browse.clicked.connect(self.browse_out)
        btn_open = QPushButton("Open folder")
        btn_open.clicked.connect(self.open_folder)
        btn_row.addWidget(btn_remove)
        btn_row.addWidget(btn_browse)
        btn_row.addWidget(btn_open)
        btn_row.addStretch(1)
        list_layout.addLayout(btn_row)
        layout.addWidget(list_box, 3)

        log_box, log_layout = card("Activity log", "")
        self.log_view = QPlainTextEdit()
        self.log_view.setObjectName("log")
        self.log_view.setReadOnly(True)
        self.log_view.setMaximumBlockCount(3000)
        self.log_view.setMinimumHeight(120)
        log_layout.addWidget(self.log_view)
        layout.addWidget(log_box, 1)
        return panel

    # -- data ---------------------------------------------------------------------
    @staticmethod
    def _valid_recording_link(url: str) -> bool:
        """A recording link looks like https://<something>.zoom…/rec/share/…"""
        parsed = urlparse(url)
        host = parsed.netloc.lower()
        return (
            parsed.scheme in {"http", "https"}
            and "zoom" in host
            and "/rec/" in parsed.path.lower()
        )

    def add_links(self) -> None:
        from .webui import parse_links

        text = self.links_edit.toPlainText()
        default_passcode = self.ed_passcode.text().strip()
        rows: list[dict[str, str]] = []
        rejected: list[str] = []
        for line in text.splitlines():
            line_c = line.strip()
            if not line_c or line_c.startswith("#"):
                continue
            meeting = parse_links(line_c, default_passcode, "Recording")
            if not meeting:
                continue
            m = meeting[0]
            if not self._valid_recording_link(m.url):
                rejected.append(m.url[:60])
                continue
            rows.append(
                {
                    "id": uuid.uuid4().hex[:12],
                    "name": m.name,
                    "url": m.url,
                    "passcode": m.passcode,
                    "status": "pending",
                    "message": "",
                }
            )
        if not rows and not rejected:
            self.log("Nothing to add — no links found in the text box")
            return
        existing = {row["url"] for row in self._rows}
        added = 0
        for row in rows:
            if row["url"] in existing:
                continue
            self._rows.append(row)
            added += 1
        self.links_edit.clear()
        self._refresh_table()
        self.persist()
        if added:
            self.log(f"Added {added} recording(s)")
            if self._mode == "running":
                self.log("The new link(s) joined the running queue")
                self._dispatch()
        for url in rejected:
            self.log(f"⚠ skipped (not a Zoom recording link): {url}")

    def paste_clipboard(self) -> None:
        text = QApplication.clipboard().text()
        if not text.strip():
            self.log("The clipboard is empty")
            return
        self.links_edit.setPlainText(text)
        self.add_links()

    def remove_selected(self) -> None:
        rows = sorted({i.row() for i in self.table.selectedIndexes()}, reverse=True)
        removed_ids: set[str] = set()
        for row in rows:
            if 0 <= row < len(self._rows):
                removed_ids.add(self._rows[row].get("id", ""))
        for row_id in removed_ids:
            job = self._jobs.pop(row_id, None)
            if job is not None:
                for signal in (job.event, job.log, job.finished):
                    with contextlib.suppress(RuntimeError, TypeError):
                        signal.disconnect()
                job.stop()
                job.deleteLater()
        for row in rows:
            if 0 <= row < len(self._rows):
                self._rows.pop(row)
        self._refresh_table()
        self.persist()
        self.log(f"Removed {len(rows)} recording(s)")
        if self._mode == "running":
            self._dispatch()

    def _parallel_changed(self, _value: str = "") -> None:
        if getattr(self, "_mode", "idle") == "running":
            self._dispatch()

    def _selected_rows(self) -> list[int]:
        return sorted({index.row() for index in self.table.selectedIndexes()})

    def _cell_double_clicked(self, row: int, _column: int) -> None:
        if 0 <= row < len(self._rows):
            self._ask_rename(row)

    def _table_menu(self, position) -> None:
        row = self.table.rowAt(position.y())
        if row >= 0 and row not in self._selected_rows():
            self.table.selectRow(row)
        selected = self._selected_rows()
        menu = QMenu(self)
        act_rename = menu.addAction("Rename…")
        act_sequence = menu.addAction("Name as a sequence…")
        act_retry = menu.addAction("Retry selected")
        menu.addSeparator()
        act_remove = menu.addAction("Remove selected")
        act_rename.setEnabled(len(selected) == 1)
        for action in (act_sequence, act_retry, act_remove):
            action.setEnabled(bool(selected))
        chosen = menu.exec(self.table.viewport().mapToGlobal(position))
        if chosen == act_rename:
            self._ask_rename(selected[0])
        elif chosen == act_sequence:
            self._ask_sequence(selected)
        elif chosen == act_retry:
            self.retry_selected()
        elif chosen == act_remove:
            self.remove_selected()

    def rename_row(self, index: int, name: str) -> bool:
        """Set the name the recording will be saved as (no extension)."""
        if not (0 <= index < len(self._rows)) or not name.strip():
            return False
        cleaned = safe_filename(name)
        if not cleaned:
            return False
        self._rows[index]["name"] = cleaned
        self._rows[index].pop("save_as", None)
        self._refresh_table()
        self.persist()
        self.log(f"Renamed to “{cleaned}”")
        return True

    def sequence_names(self, indexes: list[int], prefix: str, start: int, end: int) -> bool:
        """Name the selected rows prefix + consecutive numbers (start…end)."""
        indexes = [i for i in indexes if 0 <= i < len(self._rows)]
        count = len(indexes)
        if count == 0:
            return False
        if end < start:
            self.log("The sequence end is before its start")
            return False
        if end - start + 1 < count:
            self.log(
                f"The range {start}–{end} has fewer numbers than the {count} selected rows"
            )
            return False
        prefix = prefix.strip()
        for index, number in zip(indexes, range(start, start + count), strict=False):
            self._rows[index]["name"] = safe_filename(f"{prefix} {number}".strip())
            self._rows[index].pop("save_as", None)
        self._refresh_table()
        self.persist()
        first = self._rows[indexes[0]]["name"]
        last = self._rows[indexes[-1]]["name"]
        self.log(f"Named {count} recording(s): “{first}” … “{last}”")
        return True

    def retry_selected(self) -> None:
        selected = self._selected_rows()
        queued = 0
        for index in selected:
            row = self._rows[index]
            if row.get("status") in {"opening", "downloading", "done"}:
                continue
            row["status"] = "pending"
            row["message"] = ""
            queued += 1
        if not queued:
            return
        self.persist()
        self._refresh_table()
        self.log(f"Queued {queued} recording(s) again")
        if self._mode in {"running", "idle"}:
            self._mode = "running"
            self._dispatch()

    def _ask_rename(self, row: int) -> None:
        if not (0 <= row < len(self._rows)):
            return
        current = self._rows[row]["name"]
        name, accepted = QInputDialog.getText(
            self,
            "Rename recording",
            "File name (without extension):",
            QLineEdit.EchoMode.Normal,
            current,
        )
        if accepted and not self.rename_row(row, name):
            QMessageBox.warning(self, "Rename", "The name cannot be empty.")

    def _ask_sequence(self, indexes: list[int]) -> None:
        indexes = [i for i in indexes if 0 <= i < len(self._rows)]
        if not indexes:
            return
        dialog = QDialog(self)
        dialog.setWindowTitle("Name as a sequence")
        layout = QVBoxLayout(dialog)
        layout.setSpacing(10)
        prefix = QLineEdit()
        prefix.setPlaceholderText("e.g. Lecture — leave empty to use numbers only")
        start_box = QSpinBox()
        start_box.setRange(0, 99999)
        start_box.setValue(1)
        end_box = QSpinBox()
        end_box.setRange(0, 99999)
        end_box.setValue(len(indexes))
        layout.addWidget(
            QLabel(f"{len(indexes)} selected row(s) will be renamed in table order.")
        )
        layout.addWidget(form_row("Prefix", prefix))
        layout.addWidget(form_row("From number", start_box))
        layout.addWidget(form_row("To number", end_box))
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.sequence_names(indexes, prefix.text(), start_box.value(), end_box.value())

    def _row_percent(self, item: dict[str, str]) -> int:
        status = item.get("status", "")
        if status == "done":
            return 100
        if status not in {"downloading", "opening"}:
            return 0
        try:
            total = int(item.get("total") or 0)
            done = int(item.get("bytes") or 0)
        except (TypeError, ValueError):
            return 0
        if total <= 0:
            return 0
        # the row says “done” only after the file is merged and saved —
        # 100% is reserved for that moment, so a finished transfer that is
        # still being written never pretends to be complete
        return max(0, min(99, int(done / total * 100)))

    def _row_percent_text(self, item: dict[str, str]) -> str:
        percent = self._row_percent(item)
        total = int(item.get("total") or 0)
        if total <= 0:
            return f"{percent}%"
        return f"{percent}% of {self._format_bytes(total)}"

    def _refresh_table(self) -> None:
        self.table.setRowCount(len(self._rows))
        for row, item in enumerate(self._rows):
            name_item = QTableWidgetItem(item["name"])
            reserved = item.get("save_as")
            if reserved and reserved != item["name"]:
                name_item.setToolTip(f"saves as: {reserved}")
            self.table.setItem(row, 0, name_item)
            self.table.setItem(row, 1, QTableWidgetItem(item.get("passcode", "")))
            self.table.setItem(row, 2, QTableWidgetItem(item.get("status", "pending")))
            self.table.setItem(row, 4, QTableWidgetItem(item.get("message", "")))
            bar = QProgressBar()
            bar.setObjectName("mini")
            bar.setRange(0, 100)
            bar.setValue(self._row_percent(item))
            bar.setTextVisible(False)
            bar.setToolTip(self._row_percent_text(item))
            self.table.setCellWidget(row, 3, bar)
            # the cells truncate on narrow windows — hover shows the full text
            for column in (0, 1, 2, 4):
                cell = self.table.item(row, column)
                if cell:
                    cell.setToolTip(cell.text())
            color = QColor(
                {
                    "done": "#34d399",
                    "partial": "#fbbf24",
                    "failed": "#f87171",
                    "timeout": "#f87171",
                    "waiting": "#fbbf24",
                    "network": "#fbbf24",
                    "needs-passcode": "#fbbf24",
                    "opening": "#60a5fa",
                }.get(item.get("status", "pending"), "#8d97a8")
            )
            cell = self.table.item(row, 2)
            if cell:
                cell.setForeground(color)
        self.table_stack.setCurrentIndex(1 if self._rows else 0)

    # -- running -----------------------------------------------------------------
    def _row(self, row_id: str) -> dict[str, str] | None:
        for row in self._rows:
            if row.get("id") == row_id:
                return row
        return None

    def start_downloads(self) -> None:
        """Start (or restart) every row that is not finished yet."""
        if self._mode == "paused":
            self.toggle_pause()
            return
        if self._mode == "running":
            self.log("A download is already running")
            return
        if not self._rows:
            QMessageBox.information(
                self, "Nothing to do", "Add at least one recording link to the list first."
            )
            return
        rows = [r for r in self._rows if r.get("status") != "done"]
        skipped = len(self._rows) - len(rows)
        if not rows:
            QMessageBox.information(
                self, "Nothing to do", "Everything in the list is already downloaded."
            )
            return
        out_dir = Path(self.ed_out.text().strip() or self._out_dir).expanduser()
        out_dir.mkdir(parents=True, exist_ok=True)
        self._out_dir = str(out_dir)
        for row in self._rows:
            row.setdefault("id", uuid.uuid4().hex[:12])
        for row in rows:
            row["status"] = "pending"
            row["message"] = ""
        self._mode = "running"
        self.progress.setValue(0)
        skipped_note = f" · skipping {skipped} already downloaded" if skipped else ""
        self.log(f"Downloading {len(rows)} recording(s) → {out_dir}{skipped_note}")
        self._refresh_table()
        self.persist()
        self._dispatch()

    def toggle_pause(self) -> None:
        """Pause the queue (partial files stay) or continue where it stopped."""
        if self._mode == "running":
            self._mode = "paused"
            self._pause_active()
            self.log("Paused — press Resume to continue; the downloaded parts are kept")
        elif self._mode == "paused":
            self._mode = "running"
            self.log("Resuming…")
            self._dispatch()
        self._refresh_table()
        self.persist()
        self._update_buttons()

    def _pause_active(self) -> None:
        jobs = list(self._jobs.items())
        for _row_id, job in jobs:
            for signal in (job.event, job.log, job.finished):
                with contextlib.suppress(RuntimeError, TypeError):
                    signal.disconnect()
            job.stop()
        # the child must really be gone before the same row can start again:
        # two processes writing the same partial file would corrupt it
        for _row_id, job in jobs:
            if not job.proc.waitForFinished(4000):
                job.proc.kill()
                job.proc.waitForFinished(2000)
            job.deleteLater()
        for row_id, _job in jobs:
            row = self._row(row_id)
            if row and row.get("status") in {"opening", "downloading"}:
                row["status"] = "pending"
                row["message"] = "paused"
                row.pop("bytes", None)
                row.pop("total", None)
        self._jobs.clear()

    def _assign_save_names(self) -> None:
        """Reserve a unique file name for every row that has none yet.

        The reservation happens here (not inside the child process) because
        two parallel downloads cannot see each other's files: both would pick
        the same name, race on the same partial file and lose data.
        """
        out_dir = Path(self.ed_out.text().strip() or self._out_dir).expanduser()
        taken: set[str] = set()
        for row in self._rows:
            if row.get("save_as"):
                taken.add(str(row["save_as"]).lower())
        for row in self._rows:
            if row.get("save_as") or row.get("status") == "done":
                continue
            base = safe_filename(row.get("name") or "recording")
            candidate, number = base, 2
            while candidate.lower() in taken or any(
                (out_dir / f"{candidate}{extension}").exists()
                for extension in (".mp4", ".m4a", ".vtt")
            ):
                candidate = f"{base} ({number})"
                number += 1
            row["save_as"] = candidate
            taken.add(candidate.lower())

    def _dispatch(self) -> None:
        """Keep as many downloads busy as the “Parallel downloads” option allows."""
        if self._mode != "running":
            return
        self._assign_save_names()
        limit = max(1, int(self.cmb_parallel.currentText() or 2))
        while len(self._jobs) < limit:
            row = next((r for r in self._rows if r.get("status") == "pending"), None)
            if row is None:
                break
            self._start_row(row)
        if not self._jobs and not any(r.get("status") == "pending" for r in self._rows):
            self._mode = "idle"
            self.persist()
            self._refresh_table()
        self._refresh_stats()
        self._update_buttons()

    def _start_row(self, row: dict[str, str]) -> None:
        row_id = row["id"]
        row["status"] = "opening"
        row["message"] = ""
        self.persist()
        self._refresh_table()

        out_dir = Path(self.ed_out.text().strip() or self._out_dir).expanduser()
        out_dir.mkdir(parents=True, exist_ok=True)
        extra: list[str] = ["--connections", self.cmb_connections.currentText()]
        if self.chk_audio.isChecked():
            extra.append("--audio")
        if self.chk_transcript.isChecked():
            extra.append("--transcript")
        if not self.chk_video.isChecked():
            extra.append("--no-video")

        job = BatchProcess()
        job.row_id = row_id
        job.event.connect(lambda payload, rid=row_id: self._on_event(rid, payload))
        job.log.connect(self.log)
        job.finished.connect(lambda code, rid=row_id: self._on_finished(rid, code))
        self._jobs[row_id] = job
        meeting = {
            "name": row.get("save_as") or safe_filename(row["name"]),
            "url": row["url"],
            "passcode": row.get("passcode") or self.ed_passcode.text().strip(),
        }
        job.start([meeting], {"parallel": 1}, out_dir=out_dir, command="download", extra_args=extra)

    def _update_buttons(self) -> None:
        running = self._mode == "running"
        paused = self._mode == "paused"
        self.btn_start.setEnabled(not running and not paused)
        self.btn_pause.setEnabled(running or paused)
        self.btn_pause.setText("Resume" if paused else "Pause")
        self.btn_organize.setEnabled(not running)
        self._set_status("downloading…" if running else "paused" if paused else "idle")

    def _set_status(self, text: str) -> None:
        self.status_label.setText(text)
        self.status_changed.emit(text)

    def _on_event(self, row_id: str, payload: dict) -> None:
        kind = payload.get("type")
        if kind == "progress":
            item = self._row(row_id)
            if item is None:
                return
            status = str(payload.get("status", ""))
            old_status = item.get("status")
            item["status"] = status
            done_bytes = int(payload.get("bytes", 0))
            total_bytes = int(payload.get("total", 0) or 0)
            if total_bytes and done_bytes > total_bytes:
                done_bytes = total_bytes
            item["bytes"] = str(done_bytes)
            if total_bytes:
                item["total"] = str(total_bytes)
            else:
                total_bytes = int(item.get("total") or 0)
            size = self._format_bytes(done_bytes)
            real = self._format_bytes(total_bytes) if total_bytes else ""
            detail = str(payload.get("message", ""))
            files = [Path(path).name for path in payload.get("files") or []]
            percent = self._row_percent(item)
            if status == "downloading":
                if real:
                    item["message"] = f"{size} / {real} · {percent}% · downloading…"
                else:
                    item["message"] = f"downloading… {size}"
            elif status == "done" and files:
                shown = real or size
                item["message"] = f"{shown} · saved: " + ", ".join(files)
            elif real:
                item["message"] = f"{size} / {real} — {detail}" if detail else f"{size} / {real}"
            else:
                item["message"] = f"{size} — {detail}" if detail else size
            if old_status != status:
                self.persist()
            self._refresh_table()
            self._refresh_stats()
        elif kind == "done":
            self.log(
                f"Finished: {payload.get('downloaded', 0)} downloaded, "
                f"{payload.get('failed', 0)} failed"
            )
        elif kind == "error":
            self.log(f"Error: {payload.get('message')}")

    def _on_finished(self, row_id: str, code: int) -> None:
        job = self._jobs.pop(row_id, None)
        if job is not None:
            job.deleteLater()
        row = self._row(row_id)
        if row is not None and row.get("status") in {"opening", "downloading"}:
            row["status"] = "failed"
            row["message"] = "the download stopped unexpectedly — press Download to retry"
        if code not in (0, 1):
            self.log(f"The download process exited with code {code}")
        self.persist()
        self._refresh_table()
        if self._mode == "running":
            self._dispatch()
        else:
            self._refresh_stats()
            self._update_buttons()

    def _refresh_stats(self) -> None:
        total = max(1, len(self._rows))
        done = sum(
            1
            for r in self._rows
            if r.get("status")
            in {"done", "partial", "failed", "timeout", "waiting", "needs-passcode"}
        )
        self.progress.setValue(int(done / total * 100))

    @staticmethod
    def _format_bytes(size: int) -> str:
        if size <= 0:
            return "—"
        value = float(size)
        for unit in ("B", "KB", "MB", "GB"):
            if value < 1024 or unit == "GB":
                return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
            value /= 1024
        return f"{value:.1f} GB"

    def organize_files(self) -> None:
        folder = Path(self.ed_out.text().strip() or self._out_dir).expanduser()
        self._out_dir = str(folder)
        if not folder.is_dir():
            self.log(f"Cannot organize — the folder does not exist: {folder}")
            return
        try:
            report = organize_by_date(
                folder, base_name=self.ed_organize_name.text().strip()
            )
        except OSError as exc:
            self.log(f"Could not organize {folder}: {exc}")
            return
        changed = False
        for old, new in report.renamed:
            for row in self._rows:
                message = row.get("message") or ""
                if old in message:
                    row["message"] = message.replace(old, new)
                    changed = True
        if changed:
            self.persist()
            self._refresh_table()
        parts = []
        if report.renamed:
            parts.append(f"renamed {len(report.renamed)}")
        if report.already_dated:
            parts.append(f"{len(report.already_dated)} already dated")
        if report.no_date:
            parts.append(f"{len(report.no_date)} without a readable date")
        if report.collisions:
            parts.append(f"{len(report.collisions)} skipped (name already exists)")
        if report.errors:
            parts.append(f"{len(report.errors)} failed")
        summary = ", ".join(parts) or "no video files found"
        self.log(f"Organized {folder}: {summary}")
        for old, new in report.renamed:
            self.log(f"  {old} → {new}")
        self.persist()

    def log(self, message: str) -> None:
        stamp = time.strftime("%H:%M:%S")
        self.log_view.appendPlainText(f"{stamp}  {message}")
        bar = self.log_view.verticalScrollBar()
        bar.setValue(bar.maximum())

    def browse_out(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "Save the recordings in", self.ed_out.text())
        if path:
            self.ed_out.setText(path)
            self._out_dir = path
            self.persist()

    def open_folder(self) -> None:
        out = Path(self.ed_out.text().strip() or self._out_dir)
        out.mkdir(parents=True, exist_ok=True)
        _open_path(out)


def _open_path(path: Path) -> None:
    """Open a folder in the desktop file manager (Linux, macOS, Windows)."""
    if sys.platform == "win32":
        os.startfile(str(path))  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path)])


# --------------------------------------------------------------------------------------
# entry point
# --------------------------------------------------------------------------------------
def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    QApplication.setApplicationName(APP_NAME)
    QApplication.setOrganizationName(APP_NAME)
    QApplication.setApplicationVersion(APP_VERSION)
    app = QApplication(argv)
    app.setFont(QFont("Noto Sans, DejaVu Sans, Ubuntu, Segoe UI, sans-serif", 10))
    app.setPalette(dark_palette())
    app.setStyleSheet(STYLESHEET)
    icon = app_icon()
    if not icon.isNull():
        app.setWindowIcon(icon)
    window = MainWindow()
    if not icon.isNull():
        window.setWindowIcon(icon)
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
