"""Report generation: CSV, JSON and a self-contained HTML summary."""

from __future__ import annotations

import csv
import json
from datetime import datetime
from html import escape
from pathlib import Path

from .models import MeetingResult, Status

COLUMNS = [
    "name",
    "url",
    "meeting_id",
    "status",
    "message",
    "attempts",
    "duration_seconds",
    "join_url",
    "screenshot",
]


def _row(res: MeetingResult) -> dict[str, object]:
    return {
        "name": res.meeting.display_name(),
        "url": res.meeting.url,
        "meeting_id": res.meeting.meeting_id,
        "status": res.status.value,
        "message": res.message,
        "attempts": res.attempts,
        "duration_seconds": round(res.duration, 1),
        "join_url": res.join_url,
        "screenshot": res.screenshot,
    }


def write_csv(results: list[MeetingResult], path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=COLUMNS)
        writer.writeheader()
        for res in results:
            writer.writerow(_row(res))
    return path


def write_json(results: list[MeetingResult], path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "total": len(results),
        "joined": sum(1 for r in results if r.status is Status.JOINED),
        "waiting": sum(1 for r in results if r.status is Status.WAITING),
        "failed": sum(1 for r in results if r.status in {Status.FAILED, Status.TIMEOUT}),
        "results": [_row(r) for r in results],
    }
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


_HTML_TEMPLATE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>zoom-joiner report — {stamp}</title>
<style>
  :root {{ color-scheme: light dark; }}
  body {{ font: 15px/1.5 -apple-system, "Segoe UI", Roboto, Ubuntu, sans-serif; margin: 0; padding: 32px;
         background: #0f1115; color: #e6e6e6; }}
  h1 {{ font-size: 22px; margin: 0 0 4px; }}
  .meta {{ color: #8b93a1; margin-bottom: 24px; font-size: 13px; }}
  .cards {{ display: flex; gap: 12px; margin-bottom: 24px; flex-wrap: wrap; }}
  .card {{ background: #171a21; border: 1px solid #242833; border-radius: 10px; padding: 14px 18px; min-width: 120px; }}
  .card b {{ display: block; font-size: 24px; }}
  .card span {{ color: #8b93a1; font-size: 12px; text-transform: uppercase; letter-spacing: .06em; }}
  table {{ width: 100%; border-collapse: collapse; background: #171a21; border-radius: 10px; overflow: hidden; }}
  th, td {{ text-align: left; padding: 11px 14px; border-bottom: 1px solid #242833; font-size: 14px; }}
  th {{ background: #1c2028; color: #8b93a1; font-weight: 600; text-transform: uppercase; font-size: 11px;
        letter-spacing: .07em; }}
  tr:last-child td {{ border-bottom: none; }}
  .pill {{ display: inline-block; padding: 2px 10px; border-radius: 999px; font-size: 12px; font-weight: 600; }}
  .joined {{ background: #10331f; color: #55d68b; }}
  .waiting {{ background: #33290f; color: #e3b341; }}
  .failed, .timeout {{ background: #3a1618; color: #f2647a; }}
  .pending, .skipped {{ background: #22262e; color: #8b93a1; }}
  a {{ color: #6ea8fe; text-decoration: none; }}
  .msg {{ color: #b9c0cc; }}
</style>
</head>
<body>
  <h1>zoom-joiner report</h1>
  <div class="meta">generated {stamp} · {total} meeting(s)</div>
  <div class="cards">
    <div class="card"><b style="color:#55d68b">{joined}</b><span>joined</span></div>
    <div class="card"><b style="color:#e3b341">{waiting}</b><span>waiting</span></div>
    <div class="card"><b style="color:#f2647a">{failed}</b><span>failed</span></div>
    <div class="card"><b>{total}</b><span>total</span></div>
  </div>
  <table>
    <thead><tr><th>Meeting</th><th>ID</th><th>Status</th><th>Details</th><th>Time</th><th>Try</th></tr></thead>
    <tbody>
{rows}
    </tbody>
  </table>
</body>
</html>
"""


def write_html(results: list[MeetingResult], path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for res in results:
        status = res.status.value
        msg = escape(res.message or "")
        if res.screenshot:
            shot = Path(res.screenshot)
            msg += f' <a href="{escape(shot.name)}">screenshot</a>'
        rows.append(
            "      <tr>"
            f"<td>{escape(res.meeting.display_name())}</td>"
            f"<td>{escape(res.meeting.meeting_id or '—')}</td>"
            f'<td><span class="pill {status}">{status}</span></td>'
            f'<td class="msg">{msg}</td>'
            f"<td>{res.duration:.0f}s</td>"
            f"<td>{res.attempts}</td>"
            "</tr>"
        )
    html = _HTML_TEMPLATE.format(
        stamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        total=len(results),
        joined=sum(1 for r in results if r.status is Status.JOINED),
        waiting=sum(1 for r in results if r.status is Status.WAITING),
        failed=sum(1 for r in results if r.status in {Status.FAILED, Status.TIMEOUT}),
        rows="\n".join(rows),
    )
    path.write_text(html, encoding="utf-8")
    return path


def write_all(results: list[MeetingResult], directory: str | Path) -> dict[str, Path]:
    base = Path(directory)
    base.mkdir(parents=True, exist_ok=True)
    return {
        "csv": write_csv(results, base / "results.csv"),
        "json": write_json(results, base / "results.json"),
        "html": write_html(results, base / "report.html"),
    }


def results_to_dicts(results: list[MeetingResult]) -> list[dict[str, object]]:
    return [_row(r) for r in results]


def results_to_jsonable(results: list[MeetingResult]) -> str:
    return json.dumps(results_to_dicts(results), indent=2, ensure_ascii=False, default=str)
