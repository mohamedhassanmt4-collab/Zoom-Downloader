"""Command line interface for zoom-joiner."""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import shutil
import sys
import threading
from datetime import datetime
from pathlib import Path

from rich.console import Console
from rich.logging import RichHandler
from rich.table import Table

from . import __version__
from .backends import BackendContext, build_backend
from .config import EXAMPLE_YAML, Job, Settings, load_config
from .meeting import extract_meeting_id, is_valid
from .models import Meeting, Status
from .orchestrator import Orchestrator, make_results
from .report import write_all
from .ui import Dashboard, print_banner

console = Console()
err_console = Console(stderr=True)

EXIT_OK = 0
EXIT_PARTIAL = 1
EXIT_ERROR = 2


# --------------------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------------------
def _setup_logging(verbose: bool, log_file: Path | None) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    handlers: list[logging.Handler] = [RichHandler(console=err_console, rich_tracebacks=True)]
    if log_file:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s"))
        handlers.append(fh)
    logging.basicConfig(level=level, handlers=handlers, force=True)


def _settings_from_args(args: argparse.Namespace) -> Settings:
    s = Settings()
    s.backend = args.backend or s.backend
    s.parallel = args.parallel if args.parallel else s.parallel
    s.passkey = args.passkey or ""
    s.name = args.name or s.name
    s.headful = args.headful
    s.keep_open = args.keep_open
    s.timeout = args.timeout if args.timeout is not None else s.timeout
    s.retries = args.retries if args.retries is not None else s.retries
    s.screenshot_on_failure = not args.no_screenshot
    s.join_audio = args.join_audio or s.join_audio
    return s


def _job_from_args(args: argparse.Namespace) -> Job:
    settings = _settings_from_args(args)
    meetings: list[Meeting] = []
    warnings: list[str] = []

    if args.url:
        for i, url in enumerate(args.url, start=1):
            meetings.append(
                Meeting(
                    name=f"Meeting {i}",
                    url=url,
                    passcode=settings.passkey,
                    meeting_id=extract_meeting_id(url),
                )
            )
    elif args.file:
        job = load_config(args.file)
        settings = job.settings
        meetings = job.meetings
        warnings = job.warnings
        # CLI flags override file values when explicitly provided
        if args.passkey:
            settings.passkey = args.passkey
        if args.parallel is not None:
            settings.parallel = args.parallel
        if args.backend:
            settings.backend = args.backend
        if args.name:
            settings.name = args.name
        if args.timeout is not None:
            settings.timeout = args.timeout
        if args.retries is not None:
            settings.retries = args.retries
        settings.headful = settings.headful or args.headful
        settings.keep_open = settings.keep_open or args.keep_open
    else:
        raise SystemExit("provide a config file with -f/--file or links with --url")

    # global passkey fallback
    if settings.passkey:
        for m in meetings:
            if not m.passcode:
                m.passcode = settings.passkey

    return Job(
        settings=settings,
        meetings=meetings,
        source=Path(args.file) if args.file else None,
        warnings=warnings,
    )


def _validate_meetings(meetings: list[Meeting]) -> tuple[list[Meeting], list[str]]:
    good: list[Meeting] = []
    problems: list[str] = []
    seen: dict[str, Meeting] = {}
    for m in meetings:
        if not m.url:
            problems.append(f"'{m.name}' has no URL")
            continue
        if not is_valid(m.url):
            problems.append(f"'{m.name}': no meeting id found in '{m.url}'")
            continue
        key = extract_meeting_id(m.url)
        if key in seen:
            problems.append(f"'{m.name}' duplicates meeting id {key} (also '{seen[key].name}')")
            continue
        seen[key] = m
        m.meeting_id = key
        good.append(m)
    return good, problems


# --------------------------------------------------------------------------------------
# commands
# --------------------------------------------------------------------------------------
def cmd_init(args: argparse.Namespace) -> int:
    target = Path(args.path).expanduser()
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and not args.force:
        err_console.print(f"[bold red]✘[/] {target} already exists (use --force to overwrite)")
        return EXIT_ERROR
    target.write_text(EXAMPLE_YAML, encoding="utf-8")
    console.print(f"[bold green]✔[/] wrote example configuration → [bold]{target}[/]")
    console.print("  edit it, then run:  zoom-joiner run -f " + str(target))
    return EXIT_OK


def cmd_validate(args: argparse.Namespace) -> int:
    job = _job_from_args(args)
    good, problems = _validate_meetings(job.meetings)
    table = Table(title="Validation", show_lines=False)
    table.add_column("#", justify="right", width=4)
    table.add_column("Meeting")
    table.add_column("ID")
    table.add_column("Passcode", style="dim")
    table.add_column("Status")
    for i, m in enumerate(good, start=1):
        table.add_row(
            str(i),
            m.display_name(),
            m.meeting_id,
            "set" if m.passcode else "missing",
            "[green]ready[/]",
        )
    console.print(table)
    for w in job.warnings:
        err_console.print(f"[yellow]![/] {w}")
    for p in problems:
        err_console.print(f"[bold red]✘[/] {p}")
    console.print(f"\n[bold]{len(good)}[/] valid, [bold red]{len(problems)}[/] problem(s)")
    return EXIT_OK if not problems else EXIT_PARTIAL


def cmd_run(args: argparse.Namespace) -> int:
    job = _job_from_args(args)
    good, problems = _validate_meetings(job.meetings)
    for p in problems:
        err_console.print(f"[bold red]✘[/] {p}")
    if not good:
        err_console.print("[bold red]nothing to join[/]")
        return EXIT_ERROR

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    out_dir = Path(args.out).expanduser() if args.out else Path("reports") / stamp
    out_dir.mkdir(parents=True, exist_ok=True)

    _setup_logging(args.verbose, out_dir / "zoom-joiner.log")

    if not args.quiet:
        print_banner(console)
        console.print(
            f"[bold]{len(good)}[/] meeting(s) · backend [cyan]{job.settings.backend}[/] · "
            f"parallel [cyan]{job.settings.parallel}[/] · report [cyan]{out_dir}[/]\n"
        )

    if args.dry_run:
        for m in good:
            console.print(
                f"[cyan]{m.display_name()}[/]  {m.meeting_id}  passcode={'yes' if m.passcode else 'no'}"
            )
        console.print("\n[bold yellow]dry run[/] – nothing was opened")
        return EXIT_OK

    results = make_results(good)

    stream = bool(getattr(args, "stream", False))
    dashboard = Dashboard(console)
    dashboard.set_results(results)

    cancel_event = threading.Event()
    ctx = BackendContext(
        settings=job.settings,
        report_dir=str(out_dir),
        headless=not job.settings.headful,
        cancelled=cancel_event.is_set,
    )
    backend = build_backend(job.settings.backend, ctx)

    def emit(payload: dict) -> None:
        sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
        sys.stdout.flush()

    async def _main() -> None:
        async def poller() -> None:
            previous: list[str] = []
            while True:
                snapshot = [f"{r.status.value}:{r.message}:{r.attempts}" for r in results]
                if snapshot != previous:
                    previous = list(snapshot)
                    for idx, res in enumerate(results):
                        emit(
                            {
                                "type": "progress",
                                "index": idx,
                                "name": res.meeting.display_name(),
                                "status": res.status.value,
                                "message": res.message,
                                "attempts": res.attempts,
                            }
                        )
                await asyncio.sleep(0.4)

        watcher = asyncio.create_task(poller())
        orch = Orchestrator(
            backend,
            job.settings,
            results,
            on_update=dashboard.refresh,
            cancel_event=cancel_event,
        )
        if not args.quiet and not stream:
            dashboard.start()
        try:
            await orch.run()
        finally:
            watcher.cancel()
            if not args.quiet and not stream:
                dashboard.stop()

    if stream:
        emit({"type": "start", "total": len(good), "report_dir": str(out_dir)})
    try:
        asyncio.run(_main())
    except RuntimeError as exc:
        if stream:
            emit({"type": "error", "message": str(exc)})
        else:
            err_console.print(f"[bold red]✘[/] {exc}")
        return EXIT_ERROR
    except KeyboardInterrupt:
        err_console.print("\n[yellow]interrupted[/]")
        return EXIT_ERROR

    files = write_all(results, out_dir)
    joined = sum(1 for r in results if r.status is Status.JOINED)
    waiting = sum(1 for r in results if r.status is Status.WAITING)
    failed = sum(1 for r in results if r.status in {Status.FAILED, Status.TIMEOUT})

    if stream:
        emit(
            {
                "type": "done",
                "joined": joined,
                "waiting": waiting,
                "failed": failed,
                "report": {k: str(v) for k, v in files.items()},
                "results": [
                    {
                        "name": r.meeting.display_name(),
                        "url": r.meeting.url,
                        "status": r.status.value,
                        "message": r.message,
                        "attempts": r.attempts,
                        "duration": round(r.duration, 1),
                    }
                    for r in results
                ],
            }
        )
        return EXIT_OK if failed == 0 else EXIT_PARTIAL

    console.print()
    console.print(
        f"[bold green]✔[/] joined {joined}   [bold yellow]⏳[/] waiting {waiting}   "
        f"[bold red]✘[/] failed {failed}"
    )
    console.print(f"report: [bold cyan]{files['html']}[/]")
    return EXIT_OK if failed == 0 else EXIT_PARTIAL


def cmd_doctor(args: argparse.Namespace) -> int:
    table = Table(title="Environment check")
    table.add_column("Component")
    table.add_column("Status")
    table.add_column("Details")
    ok = True

    def add(name: str, good: bool, detail: str) -> None:
        nonlocal ok
        ok = ok and good
        table.add_row(name, "[green]OK[/]" if good else "[red]MISSING[/]", detail)

    add("python", sys.version_info >= (3, 10), sys.version.split()[0])

    try:
        import playwright  # noqa: F401

        add("playwright", True, "installed")
    except ImportError:
        add("playwright", False, "pip install playwright && playwright install chromium")

    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as p:
            path = p.chromium.executable_path
        exists = bool(path) and Path(path).exists()
        add("chromium", exists, path or "run: playwright install chromium")
    except Exception as exc:  # noqa: BLE001
        add("chromium", False, str(exc)[:60])

    for binary in ("google-chrome", "chromium", "xdotool", "wmctrl", "zoom"):
        found = shutil.which(binary) or (
            Path("/opt/zoom/zoom").exists() if binary == "zoom" else False
        )
        add(binary, bool(found), "installed" if found else "not found (optional)")

    console.print(table)
    console.print()
    console.print(
        "[bold green]all good[/]" if ok else "[bold yellow]some components are missing[/]"
    )
    return EXIT_OK if ok else EXIT_PARTIAL


def unique_output_names(requests, out_dir: Path) -> list[str]:
    """Give every request a distinct file base name.

    Two recordings with the same name must never overwrite each other in the
    same folder: the second one becomes ``name (2)``, ``name (3)``…  A partial
    download is allowed to keep its name so it can resume; a *finished* file
    with that name always forces a new one.
    """
    from .names import safe_filename

    used: set[str] = set()
    chosen: list[str] = []
    for request in requests:
        if not (request.name or "").strip():
            # no name given: the downloader falls back to the page title/token
            chosen.append("")
            continue
        raw = safe_filename(request.name)
        base, counter = raw, 2
        while base.lower() in used or any(
            (out_dir / f"{base}{extension}").exists()
            for extension in (".mp4", ".m4a", ".vtt")
        ):
            base = f"{raw} ({counter})"
            counter += 1
        used.add(base.lower())
        request.name = base
        chosen.append(base)
    return chosen


def resolve_parallel(flag: int | None, settings: object | None = None) -> int:
    """Precedence: an explicit --parallel flag, then the file defaults, then 2."""
    from_file = int(getattr(settings, "parallel", 0) or 0) if settings else 0
    return flag or from_file or 2


def cmd_download(args: argparse.Namespace) -> int:
    """Download finished Zoom recordings from share links."""
    from .downloader import DownloadRequest, RecordingDownloader
    from .webui import parse_links

    raw_urls: list[str] = list(args.url or [])
    name_by_url: dict[str, str] = {}
    passcode_by_url: dict[str, str] = {}
    settings_parallel: int | None = None
    if args.file:
        path = Path(args.file).expanduser()
        if path.suffix.lower() in {".yaml", ".yml", ".json"}:
            from .config import load_config

            job = load_config(path)
            entries = job.meetings
            settings_parallel = job.settings
        else:
            entries = parse_links(
                path.read_text(encoding="utf-8"), args.passcode or "", "Recording"
            )
        raw_urls = []
        for meeting in entries:
            raw_urls.append(meeting.url)
            name_by_url[meeting.url] = meeting.name
            passcode_by_url[meeting.url] = meeting.passcode

    if not raw_urls:
        err_console.print("[bold red]✘[/] provide links with -f/--file or --url")
        return EXIT_ERROR

    # an explicit --parallel flag wins, then the file defaults, then 2
    parallel = resolve_parallel(args.parallel, settings_parallel)

    out_dir = (
        Path(args.out).expanduser() if args.out else Path.home() / "Downloads" / "zoom-recordings"
    )
    out_dir.mkdir(parents=True, exist_ok=True)

    requests = [
        DownloadRequest(
            url=url,
            name=name_by_url.get(url, ""),
            passcode=passcode_by_url.get(url) or args.passcode or "",
            out_dir=str(out_dir),
            video=not args.no_video,
            audio=args.audio,
            transcript=args.transcript,
            timeout=args.timeout or 600.0,
            connections=args.connections or 8,
            retries=args.retries if args.retries is not None else 2,
        )
        for url in raw_urls
    ]

    unique_output_names(requests, out_dir)

    stream = bool(getattr(args, "stream", False))

    def emit(payload: dict) -> None:
        sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
        sys.stdout.flush()

    if not stream:
        console.print(
            f"[bold]{len(requests)}[/] recording(s) → [cyan]{out_dir}[/] · "
            f"parallel [cyan]{parallel}[/]"
        )
        console.print()

    async def _main() -> None:
        downloader = RecordingDownloader(headless=not args.headful, parallel=parallel)
        await downloader.start()
        results = []
        try:
            sem = asyncio.Semaphore(parallel)

            async def one(index: int, request: DownloadRequest) -> None:
                async with sem:
                    live: dict[str, object] = {
                        "status": "downloading",
                        "message": "",
                        "bytes": 0,
                        "total": 0,
                    }

                    def on_progress(done: int) -> None:
                        live["bytes"] = done

                    def on_total(total: int) -> None:
                        live["total"] = total

                    async def watcher() -> None:
                        while True:
                            if stream:
                                emit(
                                    {
                                        "type": "progress",
                                        "index": index,
                                        "name": request.name or request.url,
                                        "status": live["status"],
                                        "message": live["message"],
                                        "bytes": live["bytes"],
                                        "total": live["total"],
                                        "files": [],
                                    }
                                )
                            await asyncio.sleep(0.5)

                    task = asyncio.create_task(watcher())
                    try:
                        result = await downloader.download(
                        request, on_progress=on_progress, on_total=on_total
                    )
                    finally:
                        task.cancel()
                    live["status"] = result.status
                    live["message"] = result.message
                    results.append(result)
                    if stream:
                        emit(
                            {
                                "type": "progress",
                                "index": index,
                                "name": request.name or request.url,
                                "status": result.status,
                                "message": result.message,
                                "bytes": result.total_bytes,
                                "total": result.expected_bytes,
                                "files": result.files,
                            }
                        )
                    else:
                        icon = "[green]✔[/]" if result.ok else "[bold red]✘[/]"
                        size = result.total_bytes / (1024 * 1024)
                        console.print(
                            f"{icon} {(request.name or request.url)[:60]} — "
                            f"[bold]{result.status}[/] {result.message} "
                            f"({size:.1f} MB)"
                        )

            await asyncio.gather(*(one(i, r) for i, r in enumerate(requests)))
        finally:
            await downloader.stop()
        if stream:
            done = sum(1 for r in results if r.ok)
            emit(
                {
                    "type": "done",
                    "total": len(results),
                    "downloaded": done,
                    "failed": len(results) - done,
                    "out_dir": str(out_dir),
                    "results": [
                        {
                            "name": r.request.name or r.request.url,
                            "url": r.request.url,
                            "status": r.status,
                            "message": r.message,
                            "files": r.files,
                            "bytes": r.total_bytes,
                            "total": r.expected_bytes,
                        }
                        for r in results
                    ],
                }
            )
        else:
            done = sum(1 for r in results if r.ok)
            console.print()
            console.print(
                f"[bold green]✔[/] {done} downloaded   [bold red]✘[/] {len(results) - done} failed"
            )
            console.print(f"saved in: [bold cyan]{out_dir}[/]")

    try:
        asyncio.run(_main())
    except RuntimeError as exc:
        if stream:
            emit({"type": "error", "message": str(exc)})
        else:
            err_console.print(f"[bold red]✘[/] {exc}")
        return EXIT_ERROR
    except KeyboardInterrupt:
        err_console.print("\n[yellow]interrupted[/]")
        return EXIT_ERROR
    return EXIT_OK


def cmd_app(args: argparse.Namespace) -> int:
    try:
        from .app import main as app_main
    except ImportError as exc:
        err_console.print(
            f"[bold red]✘[/] the desktop application needs PySide6: pip install PySide6-Essentials ({exc})"
        )
        return EXIT_ERROR
    return app_main([])


def cmd_gui(args: argparse.Namespace) -> int:
    from .webui import serve

    try:
        serve(host=args.host, port=args.port, open_browser=not args.no_open)
    except OSError as exc:
        err_console.print(f"[bold red]✘[/] could not start the dashboard: {exc}")
        return EXIT_ERROR
    return EXIT_OK


def cmd_report(args: argparse.Namespace) -> int:
    out_dir = Path(args.directory).expanduser()
    if not out_dir.exists():
        err_console.print(f"[bold red]✘[/] {out_dir} does not exist")
        return EXIT_ERROR
    print_banner(console)
    console.print(f"report: [bold cyan]{out_dir / 'report.html'}[/]")
    if args.open:
        import webbrowser

        webbrowser.open((out_dir / "report.html").resolve().as_uri())
    return EXIT_OK


# --------------------------------------------------------------------------------------
# parser
# --------------------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="zoom-joiner",
        description="Join many Zoom meetings in one go, with passcodes, live progress and reports.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "examples:\n"
            "  zoom-joiner init -f meetings.yaml\n"
            "  zoom-joiner run -f meetings.yaml --parallel 4 --passkey 123456\n"
            "  zoom-joiner run --url https://zoom.us/j/12345678901 --url https://zoom.us/j/10987654321\n"
            "  zoom-joiner validate -f meetings.csv\n"
            "  zoom-joiner doctor\n"
        ),
    )
    parser.add_argument("--version", action="version", version=f"zoom-joiner {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    p_init = sub.add_parser("init", help="write an example configuration file")
    p_init.add_argument(
        "-f", "--path", default="meetings.yaml", help="target file (default: meetings.yaml)"
    )
    p_init.add_argument("--force", action="store_true", help="overwrite an existing file")
    p_init.set_defaults(func=cmd_init)

    def add_run_args(p: argparse.ArgumentParser) -> None:
        p.add_argument("-f", "--file", help="configuration file (.yaml/.json/.csv/.txt)")
        p.add_argument("--url", action="append", help="a meeting link (repeatable)")
        p.add_argument("--backend", choices=["web", "desktop"], help="join engine")
        p.add_argument("--parallel", type=int, help="how many meetings to join simultaneously")
        p.add_argument(
            "--passkey",
            "--passcode",
            dest="passkey",
            help="global passcode applied to meetings that have none",
        )
        p.add_argument("--name", help="display name used when joining")
        p.add_argument("--headful", action="store_true", help="show the browser window")
        p.add_argument(
            "--keep-open", action="store_true", help="do not close the meeting after joining"
        )
        p.add_argument("--timeout", type=float, help="seconds allowed per meeting")
        p.add_argument("--retries", type=int, help="extra attempts per meeting")
        p.add_argument("--join-audio", choices=["auto", "computer", "none"])
        p.add_argument(
            "--no-screenshot", action="store_true", help="do not capture failure screenshots"
        )
        p.add_argument("--out", help="report output directory")
        p.add_argument("--dry-run", action="store_true", help="only validate, do not open anything")
        p.add_argument(
            "--stream",
            action="store_true",
            help="emit JSON lines (used by the desktop application)",
        )
        p.add_argument("-q", "--quiet", action="store_true", help="no banner / no live table")
        p.add_argument("-v", "--verbose", action="store_true", help="debug logging")

    p_run = sub.add_parser("run", help="join the meetings")
    add_run_args(p_run)
    p_run.set_defaults(func=cmd_run)

    p_val = sub.add_parser("validate", help="check a configuration without joining")
    add_run_args(p_val)
    p_val.set_defaults(func=cmd_validate)

    p_doc = sub.add_parser("doctor", help="check the local environment")
    p_doc.set_defaults(func=cmd_doctor)

    p_gui = sub.add_parser("gui", help="open the local web dashboard")
    p_gui.add_argument("--host", default="127.0.0.1", help="bind address (default: 127.0.0.1)")
    p_gui.add_argument("--port", type=int, default=8765, help="port (default: 8765)")
    p_gui.add_argument("--no-open", action="store_true", help="do not open the browser")
    p_gui.set_defaults(func=cmd_gui)

    p_app = sub.add_parser("app", help="open the native desktop application")
    p_app.set_defaults(func=cmd_app)

    p_dl = sub.add_parser("download", help="download finished Zoom recordings")
    p_dl.add_argument("-f", "--file", help="file with one recording link per line")
    p_dl.add_argument("--url", action="append", help="a recording share link (repeatable)")
    p_dl.add_argument("--passcode", "--passkey", dest="passcode", help="recording passcode")
    p_dl.add_argument("--out", help="output directory (default: ~/Downloads/zoom-recordings)")
    p_dl.add_argument("--parallel", type=int, default=None, help="parallel downloads")
    p_dl.add_argument(
        "--connections",
        type=int,
        default=8,
        help="parallel connections per file (faster, same quality)",
    )
    p_dl.add_argument("--timeout", type=float, help="seconds allowed per recording")
    p_dl.add_argument("--audio", action="store_true", help="also download the audio-only file")
    p_dl.add_argument("--transcript", action="store_true", help="also download the transcript")
    p_dl.add_argument("--no-video", action="store_true", help="skip the video file")
    p_dl.add_argument(
        "--retries",
        type=int,
        default=None,
        help="automatic retries per recording when the page misbehaves (default 2)",
    )
    p_dl.add_argument("--headful", action="store_true", help="show the browser window")
    p_dl.add_argument("--stream", action="store_true", help="emit JSON lines (used by the app)")
    p_dl.set_defaults(func=cmd_download)

    p_rep = sub.add_parser("report", help="open the report of a previous run")
    p_rep.add_argument("directory", help="report directory")
    p_rep.add_argument("--open", action="store_true", help="open the HTML report in a browser")
    p_rep.set_defaults(func=cmd_report)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except SystemExit:
        raise
    except FileNotFoundError as exc:
        err_console.print(f"[bold red]✘[/] {exc}")
        return EXIT_ERROR
    except ValueError as exc:
        err_console.print(f"[bold red]✘[/] {exc}")
        return EXIT_ERROR
    except KeyboardInterrupt:
        err_console.print("\n[yellow]interrupted[/]")
        return EXIT_ERROR


if __name__ == "__main__":
    sys.exit(main())
