"""zoom-joiner – join many Zoom meetings in one go on Linux."""

__version__ = "1.5.2"

__all__ = ["__version__"]
