"""Persistent job queue.

The queue is stored as JSON so that an interrupted batch (crash, closed
window, reboot) can be resumed later: every state change is written
atomically, and the next launch of the app offers to continue where the
previous run stopped.
"""

from __future__ import annotations

import json
import os
import tempfile
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .models import Status


def default_app_dir(os_name: str | None = None) -> Path:
    """Per-user data directory: XDG on Linux, %LOCALAPPDATA% on Windows."""
    if (os_name or os.name) == "nt":
        base = os.environ.get("LOCALAPPDATA")
        root = Path(base) if base else Path.home() / "AppData" / "Local"
        return root / "ZoomDownloader"
    return Path.home() / ".local/share/zoom-joiner"


APP_DIR = Path(os.environ.get("ZOOM_JOINER_HOME") or default_app_dir())
QUEUE_FILE = APP_DIR / "queue.json"
SETTINGS_FILE = APP_DIR / "settings.json"
RECORDINGS_FILE = APP_DIR / "recordings.json"

#: Statuses that mean "this meeting still needs work".
RESUMABLE = {
    Status.PENDING,
    Status.LAUNCHING,
    Status.AUTH,
    Status.JOINING,
    Status.FAILED,
    Status.TIMEOUT,
}


@dataclass
class QueueItem:
    name: str
    url: str
    passcode: str = ""
    otp: str = ""
    status: str = Status.PENDING.value
    message: str = ""
    attempts: int = 0
    meeting_id: str = ""
    wait_for_host: bool = True
    keep_open: bool = False

    @property
    def is_done(self) -> bool:
        return self.status in {Status.JOINED.value, Status.WAITING.value}


@dataclass
class QueueState:
    items: list[QueueItem] = field(default_factory=list)
    options: dict[str, Any] = field(default_factory=dict)
    updated_at: float = field(default_factory=time.time)
    report_dir: str = ""

    @property
    def resumable(self) -> list[QueueItem]:
        return [i for i in self.items if i.status in {s.value for s in RESUMABLE}]


def _atomic_write(path: Path, payload: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp-", suffix=".json")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):  # pragma: no cover
            os.unlink(tmp)


def save_queue(state: QueueState, path: Path | None = None) -> None:
    path = path or QUEUE_FILE
    state.updated_at = time.time()
    data = {
        "updated_at": state.updated_at,
        "options": state.options,
        "report_dir": state.report_dir,
        "items": [asdict(i) for i in state.items],
    }
    _atomic_write(path, json.dumps(data, indent=2, ensure_ascii=False))


def load_queue(path: Path | None = None) -> QueueState:
    path = path or QUEUE_FILE
    if not path.exists():
        return QueueState()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return QueueState()
    items = [
        QueueItem(**{k: v for k, v in raw.items() if k in QueueItem.__dataclass_fields__})
        for raw in data.get("items", [])
    ]
    return QueueState(
        items=items,
        options=data.get("options", {}),
        updated_at=data.get("updated_at", 0.0),
        report_dir=data.get("report_dir", ""),
    )


def save_settings(options: dict[str, Any], path: Path | None = None) -> None:
    path = path or SETTINGS_FILE
    _atomic_write(path, json.dumps(options, indent=2, ensure_ascii=False))


def save_downloads(
    rows: list[dict[str, Any]],
    out_dir: str,
    default_passcode: str = "",
    path: Path | None = None,
) -> None:
    """Persist the recording list of the desktop app so an interrupted
    download (closed window, reboot) can be resumed later."""
    path = path or RECORDINGS_FILE
    data = {
        "updated_at": time.time(),
        "out_dir": out_dir,
        "default_passcode": default_passcode,
        "recordings": rows,
    }
    _atomic_write(path, json.dumps(data, indent=2, ensure_ascii=False))


def load_downloads(path: Path | None = None) -> tuple[list[dict[str, str]], str, str]:
    path = path or RECORDINGS_FILE
    if not path.exists():
        return [], "", ""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return [], "", ""
    rows = [dict(raw) for raw in data.get("recordings", []) if isinstance(raw, dict)]
    for row in rows:
        row.setdefault("name", "")
        row.setdefault("url", "")
        row.setdefault("passcode", "")
        row.setdefault("status", Status.PENDING.value)
    default_passcode = str(data.get("default_passcode") or "")
    if data.get("out_dir"):
        return rows, str(data["out_dir"]), default_passcode
    return rows, "", default_passcode


def load_settings(path: Path | None = None) -> dict[str, Any]:
    path = path or SETTINGS_FILE
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}
