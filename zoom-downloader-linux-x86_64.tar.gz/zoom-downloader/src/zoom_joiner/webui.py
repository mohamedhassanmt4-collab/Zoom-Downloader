"""Local web dashboard (zero extra dependencies) for running batch joins.

Starts an HTTP server on 127.0.0.1 that serves a small single-page UI where
you can paste meeting links, set a passkey, run the batch and watch the live
status of every meeting.
"""

from __future__ import annotations

import asyncio
import json
import threading
import time
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from .backends import BackendContext, build_backend
from .config import Settings
from .meeting import extract_meeting_id
from .models import Meeting, MeetingResult, Status
from .orchestrator import Orchestrator, make_results
from .report import write_all

ASSETS_DIR = Path(__file__).resolve().parent / "assets"


@dataclass
class BatchState:
    """Mutable state shared between the HTTP handlers and the worker thread."""

    running: bool = False
    started_at: float = 0.0
    finished_at: float = 0.0
    backend: str = "web"
    passkey: str = ""
    parallel: int = 3
    name: str = "Attendee"
    wait_for_host: bool = True
    results: list[dict[str, Any]] = field(default_factory=list)
    logs: list[str] = field(default_factory=list)
    report_dir: str = ""
    error: str = ""
    lock: threading.Lock = field(default_factory=threading.Lock)
    _stop_event: threading.Event = field(default_factory=threading.Event)

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            return {
                "running": self.running,
                "elapsed": round(time.time() - self.started_at, 1) if self.started_at else 0,
                "backend": self.backend,
                "parallel": self.parallel,
                "name": self.name,
                "results": list(self.results),
                "logs": self.logs[-80:],
                "report_dir": self.report_dir,
                "error": self.error,
            }


def parse_links(raw: str, passkey: str, name: str = "Meeting") -> list[Meeting]:
    """Parse pasted lines; ``name`` is the label used for lines without one."""
    """Parse pasted text into meetings.

    Accepted per line::

        <url>
        <url> <passcode>
        <url> <passcode> <name>

    Lines starting with ``#`` are ignored.
    """
    meetings: list[Meeting] = []  # noqa: F841
    for lineno, line in enumerate(raw.splitlines(), start=1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        url = parts[0]
        passcode = parts[1] if len(parts) > 1 and not parts[1].startswith("http") else passkey
        label = " ".join(parts[2:]) if len(parts) > 2 else f"{name} {lineno}"
        meetings.append(
            Meeting(
                name=label,
                url=url,
                passcode=passcode or passkey,
                meeting_id=extract_meeting_id(url),
                wait_for_host=True,
            )
        )
    return meetings


class BatchRunner:
    """Runs one batch at a time in a background thread."""

    def __init__(self, state: BatchState) -> None:
        self.state = state
        self._thread: threading.Thread | None = None

    # -- helpers -----------------------------------------------------------------
    def log(self, message: str) -> None:
        with self.state.lock:
            self.state.logs.append(f"{time.strftime('%H:%M:%S')}  {message}")

    def _to_row(self, result: MeetingResult) -> dict[str, Any]:
        return {
            "name": result.meeting.display_name(),
            "meeting_id": result.meeting.meeting_id,
            "status": result.status.value,
            "message": result.message,
            "attempts": result.attempts,
            "duration": round(result.duration, 1),
            "screenshot": result.screenshot,
        }

    # -- public API --------------------------------------------------------------
    def start(self, payload: dict[str, Any]) -> tuple[bool, str]:
        if self.state.running:
            return False, "a batch is already running"

        raw = str(payload.get("links") or "")
        if not raw.strip():
            return False, "paste at least one meeting link"

        passkey = str(payload.get("passkey") or "").strip()
        meetings = parse_links(raw, passkey, str(payload.get("name") or "Attendee"))
        if not meetings:
            return False, "no valid meeting links found"

        settings = Settings(
            backend=str(payload.get("backend") or "web"),
            parallel=max(1, int(payload.get("parallel") or 3)),
            passkey=passkey,
            name=str(payload.get("name") or "Attendee"),
            headful=bool(payload.get("headful")),
            timeout=float(payload.get("timeout") or 90),
            retries=int(payload.get("retries") or 1),
            keep_open=bool(payload.get("keep_open")),
        )

        stamp = time.strftime("%Y%m%d-%H%M%S")
        out_dir = Path("reports") / stamp
        out_dir.mkdir(parents=True, exist_ok=True)

        with self.state.lock:
            self.state.running = True
            self.state.started_at = time.time()
            self.state.finished_at = 0.0
            self.state.error = ""
            self.state.logs = []
            self.state.results = [
                {
                    "name": m.display_name(),
                    "meeting_id": m.meeting_id,
                    "status": Status.PENDING.value,
                    "message": "",
                    "attempts": 0,
                    "duration": 0,
                    "screenshot": "",
                }
                for m in meetings
            ]
            self.state.report_dir = str(out_dir)

        self.log(f"starting {len(meetings)} meeting(s) via the '{settings.backend}' backend")
        self._thread = threading.Thread(
            target=self._run, args=(meetings, settings, out_dir), daemon=True
        )
        self._thread.start()
        return True, f"running {len(meetings)} meeting(s)"

    def stop(self) -> tuple[bool, str]:
        if not self.state.running:
            return False, "nothing is running"
        self.state._stop_event.set()
        self.log("stop requested – the current meetings will be closed")
        return True, "stopping"

    # -- worker ------------------------------------------------------------------
    def _run(self, meetings: list[Meeting], settings: Settings, out_dir: Path) -> None:
        results = make_results(meetings)

        async def _main() -> None:
            ctx = BackendContext(
                settings=settings,
                report_dir=str(out_dir),
                headless=not settings.headful,
                cancelled=self.state._stop_event.is_set,
            )
            backend = build_backend(settings.backend, ctx)

            def sync_state() -> None:
                with self.state.lock:
                    for idx, result in enumerate(results):
                        if idx < len(self.state.results):
                            self.state.results[idx] = self._to_row(result)

            async def poller() -> None:
                while True:
                    sync_state()
                    await asyncio.sleep(0.5)

            watcher = asyncio.create_task(poller())
            orch = Orchestrator(
                backend,
                settings,
                results,
                on_update=lambda _r: sync_state(),
                cancel_event=self.state._stop_event,
            )
            try:
                await orch.run()
            finally:
                watcher.cancel()
                sync_state()

        try:
            asyncio.run(_main())
            files = write_all(results, out_dir)
            joined = sum(1 for r in results if r.status is Status.JOINED)
            waiting = sum(1 for r in results if r.status is Status.WAITING)
            failed = len(results) - joined - waiting
            self.log(f"done: {joined} joined, {waiting} waiting, {failed} failed")
            self.log(f"report: {files['html']}")
        except Exception as exc:  # noqa: BLE001
            with self.state.lock:
                self.state.error = str(exc)
            self.log(f"error: {exc}")
        finally:
            with self.state.lock:
                self.state.running = False
                self.state.finished_at = time.time()


# --------------------------------------------------------------------------------------
# HTTP layer
# --------------------------------------------------------------------------------------
PAGE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>zoom-joiner · control panel</title>
<link rel="icon" type="image/png" href="/icon.png">
<link rel="apple-touch-icon" href="/icon.png">
<style>
  :root {
    --bg: #0d1017; --panel: #151a23; --panel2: #1b2029; --line: #262d3a;
    --txt: #e7ecf3; --muted: #8d97a8; --accent: #3b82f6; --ok: #34d399;
    --warn: #fbbf24; --err: #f87171;
  }
  * { box-sizing: border-box; }
  body { margin: 0; font: 15px/1.55 -apple-system, "Segoe UI", Roboto, Ubuntu, sans-serif;
         background: var(--bg); color: var(--txt); }
  header { padding: 18px 28px; border-bottom: 1px solid var(--line); display: flex;
           align-items: center; gap: 14px; background: linear-gradient(180deg,#151a23,#0d1017); }
  header h1 { font-size: 18px; margin: 0; letter-spacing: .2px; }
  header .dot { width: 10px; height: 10px; border-radius: 50%; background: var(--muted); }
  header .dot.on { background: var(--ok); box-shadow: 0 0 12px var(--ok); }
  header .dot.run { background: var(--warn); box-shadow: 0 0 12px var(--warn); animation: pulse 1.1s infinite; }
  @keyframes pulse { 50% { opacity: .35; } }
  header .spacer { flex: 1; }
  main { display: grid; grid-template-columns: 420px 1fr; gap: 22px; padding: 22px 28px; align-items: start; }
  @media (max-width: 980px) { main { grid-template-columns: 1fr; } }
  .card { background: var(--panel); border: 1px solid var(--line); border-radius: 14px; padding: 18px; }
  .card h2 { margin: 0 0 14px; font-size: 13px; text-transform: uppercase; letter-spacing: .09em; color: var(--muted); }
  label { display: block; font-size: 12px; color: var(--muted); margin: 12px 0 6px; }
  textarea, input[type=text], input[type=number], select {
    width: 100%; background: var(--panel2); border: 1px solid var(--line); color: var(--txt);
    border-radius: 9px; padding: 10px 12px; font: inherit; outline: none; }
  textarea { min-height: 190px; resize: vertical; font-family: ui-monospace, "SF Mono", Menlo, monospace;
             font-size: 13px; }
  textarea:focus, input:focus, select:focus { border-color: var(--accent); }
  .row { display: flex; gap: 10px; }
  .row > * { flex: 1; }
  .checks { display: flex; gap: 18px; margin-top: 14px; font-size: 13px; color: var(--muted); }
  .checks label { display: flex; align-items: center; gap: 6px; margin: 0; }
  button { border: 0; border-radius: 9px; padding: 11px 18px; font: inherit; font-weight: 600;
           cursor: pointer; background: var(--accent); color: #fff; }
  button.ghost { background: var(--panel2); color: var(--txt); border: 1px solid var(--line); }
  button:disabled { opacity: .45; cursor: not-allowed; }
  .actions { display: flex; gap: 10px; margin-top: 18px; }
  table { width: 100%; border-collapse: collapse; }
  th, td { text-align: left; padding: 10px 12px; font-size: 14px; border-bottom: 1px solid var(--line); }
  th { font-size: 11px; text-transform: uppercase; letter-spacing: .08em; color: var(--muted); }
  tr:last-child td { border-bottom: none; }
  .pill { display: inline-block; padding: 3px 11px; border-radius: 999px; font-size: 12px; font-weight: 600; }
  .joined { background: rgba(52,211,153,.14); color: var(--ok); }
  .waiting { background: rgba(251,191,36,.14); color: var(--warn); }
  .failed, .timeout { background: rgba(248,113,113,.14); color: var(--err); }
  .pending, .launching, .joining, .auth, .skipped { background: var(--panel2); color: var(--muted); }
  .stats { display: flex; gap: 12px; margin-bottom: 16px; }
  .stat { flex: 1; background: var(--panel2); border: 1px solid var(--line); border-radius: 11px; padding: 12px 14px; }
  .stat b { display: block; font-size: 22px; }
  .stat span { font-size: 11px; text-transform: uppercase; letter-spacing: .08em; color: var(--muted); }
  pre.log { background: #0a0d12; border: 1px solid var(--line); border-radius: 10px; padding: 12px 14px;
            max-height: 220px; overflow: auto; font-size: 12.5px; color: #9fb0c8; margin: 0; }
  .muted { color: var(--muted); font-size: 12.5px; }
  a { color: var(--accent); }
</style>
</head>
<body>
<header>
  <span class="dot" id="dot"></span>
  <h1>zoom-joiner</h1>
  <span class="muted" id="state">idle</span>
  <span class="spacer"></span>
  <span class="muted" id="clock"></span>
</header>
<main>
  <section class="card">
    <h2>New batch</h2>
    <label for="links">Meeting links — one per line</label>
    <textarea id="links" spellcheck="false" placeholder="https://zoom.us/j/12345678901 123456 Daily Standup&#10;https://zoom.us/j/98765432101 654321 Client Review"></textarea>
    <div class="row">
      <div>
        <label for="passkey">Passkey (fallback)</label>
        <input type="text" id="passkey" placeholder="123456">
      </div>
      <div>
        <label for="pname">Display name</label>
        <input type="text" id="pname" value="Attendee">
      </div>
    </div>
    <div class="row">
      <div>
        <label for="parallel">Parallel</label>
        <input type="number" id="parallel" value="3" min="1" max="10">
      </div>
      <div>
        <label for="backend">Backend</label>
        <select id="backend"><option value="web">web (chromium)</option><option value="desktop">desktop (zoom client)</option></select>
      </div>
    </div>
    <div class="checks">
      <label><input type="checkbox" id="headful"> visible browser</label>
      <label><input type="checkbox" id="keepopen"> keep meeting open</label>
    </div>
    <div class="actions">
      <button id="start">Start batch</button>
      <button class="ghost" id="stop">Stop</button>
    </div>
    <p class="muted" id="msg" style="margin-bottom:0"></p>
  </section>

  <section>
    <div class="card" style="margin-bottom:18px">
      <h2>Live status</h2>
      <div class="stats">
        <div class="stat"><b id="s-joined" style="color:var(--ok)">0</b><span>joined</span></div>
        <div class="stat"><b id="s-waiting" style="color:var(--warn)">0</b><span>waiting</span></div>
        <div class="stat"><b id="s-failed" style="color:var(--err)">0</b><span>failed</span></div>
        <div class="stat"><b id="s-total">0</b><span>total</span></div>
      </div>
      <table>
        <thead><tr><th>Meeting</th><th>ID</th><th>Status</th><th>Details</th><th>Time</th><th>Try</th></tr></thead>
        <tbody id="rows"></tbody>
      </table>
    </div>
    <div class="card">
      <h2>Log</h2>
      <pre class="log" id="log"></pre>
    </div>
  </section>
</main>
<script>
const $ = (id) => document.getElementById(id);
const esc = (s) => (s ?? "").toString().replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));

async function start() {
  const payload = {
    links: $("links").value,
    passkey: $("passkey").value,
    name: $("pname").value,
    parallel: $("parallel").value,
    backend: $("backend").value,
    headful: $("headful").checked,
    keep_open: $("keepopen").checked,
  };
  const r = await fetch("/api/start", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(payload)});
  const data = await r.json();
  $("msg").textContent = data.message || "";
}

async function stop() {
  const r = await fetch("/api/stop", {method: "POST"});
  const data = await r.json();
  $("msg").textContent = data.message || "";
}

async function poll() {
  const s = await (await fetch("/api/state")).json();
  $("dot").className = "dot" + (s.running ? " run" : (s.results.length ? " on" : ""));
  $("state").textContent = s.running ? `running · ${s.elapsed}s` : (s.results.length ? "idle" : "idle");
  $("clock").textContent = s.report_dir ? s.report_dir : "";
  let joined = 0, waiting = 0, failed = 0;
  const rows = s.results.map(r => {
    if (r.status === "joined") joined++;
    else if (r.status === "waiting") waiting++;
    else if (r.status === "failed" || r.status === "timeout") failed++;
    const shot = r.screenshot ? ` <a href="${esc(r.screenshot)}" target="_blank">shot</a>` : "";
    return `<tr><td>${esc(r.name)}</td><td class="muted">${esc(r.meeting_id || "—")}</td>` +
           `<td><span class="pill ${esc(r.status)}">${esc(r.status)}</span></td>` +
           `<td class="muted">${esc(r.message)}${shot}</td><td>${r.duration ? r.duration + "s" : "…"}</td>` +
           `<td>${r.attempts || ""}</td></tr>`;
  }).join("");
  $("rows").innerHTML = rows || `<tr><td colspan="6" class="muted">no meetings yet</td></tr>`;
  $("s-joined").textContent = joined;
  $("s-waiting").textContent = waiting;
  $("s-failed").textContent = failed;
  $("s-total").textContent = s.results.length;
  $("log").textContent = s.logs.join("\n");
}

$("start").onclick = start;
$("stop").onclick = stop;
poll(); setInterval(poll, 700);
</script>
</body>
</html>
"""


class _Handler(BaseHTTPRequestHandler):
    runner: BatchRunner
    state: BatchState

    def _send(self, code: int, body: bytes, ctype: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload: dict[str, Any], code: int = 200) -> None:
        self._send(code, json.dumps(payload).encode("utf-8"), "application/json; charset=utf-8")

    def do_GET(self) -> None:  # noqa: N802
        if self.path.startswith("/api/state"):
            self._json(self.state.snapshot())
        elif self.path in {"/", "/index.html"}:
            self._send(200, PAGE.encode("utf-8"), "text/html; charset=utf-8")
        elif self.path in {"/icon.png", "/favicon.ico"}:
            icon = ASSETS_DIR / "icons" / "icon-64.png"
            if icon.exists():
                self._send(200, icon.read_bytes(), "image/png")
            else:
                self._json({"error": "icon not found"}, 404)
        else:
            self._json({"error": "not found"}, 404)

    def do_POST(self) -> None:  # noqa: N802
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            payload = json.loads(raw or b"{}")
        except json.JSONDecodeError:
            self._json({"ok": False, "message": "invalid JSON"}, 400)
            return
        if self.path == "/api/start":
            ok, message = self.runner.start(payload)
            self._json({"ok": ok, "message": message})
        elif self.path == "/api/stop":
            ok, message = self.runner.stop()
            self._json({"ok": ok, "message": message})
        else:
            self._json({"error": "not found"}, 404)

    def log_message(self, *args: object) -> None:
        return


def serve(host: str = "127.0.0.1", port: int = 8765, open_browser: bool = True) -> None:
    """Run the dashboard until interrupted."""
    state = BatchState()
    runner = BatchRunner(state)

    handler = type("Handler", (_Handler,), {"runner": runner, "state": state})
    httpd = ThreadingHTTPServer((host, port), handler)
    url = f"http://{host}:{port}/"
    print(f"zoom-joiner dashboard → {url}   (ctrl-c to stop)")
    if open_browser:
        try:
            import webbrowser

            threading.Timer(0.8, lambda: webbrowser.open(url)).start()
        except Exception:  # noqa: BLE001
            pass
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nbye")
    finally:
        httpd.server_close()
