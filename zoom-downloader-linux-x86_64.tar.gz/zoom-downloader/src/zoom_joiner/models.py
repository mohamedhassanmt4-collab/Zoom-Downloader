"""Core domain models for zoom-joiner."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from datetime import datetime


class Status(str, enum.Enum):
    """Lifecycle of a single meeting join attempt."""

    PENDING = "pending"
    LAUNCHING = "launching"
    AUTH = "auth"
    JOINING = "joining"
    JOINED = "joined"
    WAITING = "waiting"  # inside the meeting, host has not started it yet
    FAILED = "failed"
    SKIPPED = "skipped"
    TIMEOUT = "timeout"

    @property
    def is_terminal(self) -> bool:
        return self in {
            Status.JOINED,
            Status.WAITING,
            Status.FAILED,
            Status.SKIPPED,
            Status.TIMEOUT,
        }

    @property
    def is_success(self) -> bool:
        return self in {Status.JOINED, Status.WAITING}


@dataclass(slots=True)
class Meeting:
    """A single meeting to join."""

    name: str
    url: str
    meeting_id: str = ""
    passcode: str = ""
    otp: str = ""
    wait_for_host: bool = True
    keep_open: bool = False
    join_audio: str = "auto"  # auto | computer | none
    browser_profile: str = ""
    notes: str = ""
    tags: list[str] = field(default_factory=list)

    def display_name(self) -> str:
        return self.name or self.meeting_id or self.url


@dataclass(slots=True)
class MeetingResult:
    """Outcome of one meeting attempt."""

    meeting: Meeting
    status: Status = Status.PENDING
    message: str = ""
    started_at: datetime | None = None
    finished_at: datetime | None = None
    attempts: int = 0
    screenshot: str = ""
    join_url: str = ""

    @property
    def duration(self) -> float:
        if not self.started_at or not self.finished_at:
            return 0.0
        return (self.finished_at - self.started_at).total_seconds()

    @property
    def ok(self) -> bool:
        return self.status.is_success
