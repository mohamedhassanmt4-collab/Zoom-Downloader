"""Fast, resumable file downloader (standard library only).

Zoom serves the recordings from its CDN with HTTP range support, so the same
bytes can be fetched with several parallel connections.  The file that lands
on disk is byte-for-byte identical to the one the browser downloads — only
the transport is faster (and it is written directly to its final name, so
there is no extra copy).

The implementation degrades gracefully:

* ranged + parallel  -> fastest
* single stream      -> when the server refuses ranges
* browser download   -> last-resort fallback (handled by the caller)
"""

from __future__ import annotations

import contextlib
import math
import os
import threading
import time
import urllib.error
import urllib.request
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ProgressHook = Callable[[int], None]

DEFAULT_CONNECTIONS = 8
CHUNK_TIMEOUT = 120

#: files smaller than this are downloaded with a single connection
PARALLEL_MIN_SIZE = 12 * 1024 * 1024
#: if a single connection already reaches this speed (bytes/s) we keep it simple
PARALLEL_SPEED_THRESHOLD = 4 * 1024 * 1024
SAMPLE_BYTES = 2 * 1024 * 1024


def _probe(url: str, headers: dict[str, str]) -> tuple[int, bool] | None:
    """Return ``(total_size, supports_ranges)`` or ``None`` when unreachable."""
    request = urllib.request.Request(url, headers={**headers, "Range": "bytes=0-0"})
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            content_range = response.headers.get("Content-Range", "")
            accept = (response.headers.get("Accept-Ranges") or "").lower()
            if "/" in content_range:
                total = content_range.rsplit("/", 1)[-1].strip()
                if total.isdigit():
                    return int(total), "bytes" in accept or True
            length = response.headers.get("Content-Length")
            if length and length.isdigit():
                return int(length), False
    except (urllib.error.URLError, OSError, ValueError):
        return None
    return None


def _sample_speed(url: str, headers: dict[str, str], total: int) -> float:
    """Measure how fast a single connection is right now (bytes/second)."""
    end = min(SAMPLE_BYTES, total) - 1
    if end < 0:
        return 0.0
    request = urllib.request.Request(url, headers={**headers, "Range": f"bytes=0-{end}"})
    start = time.monotonic()
    read = 0
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            while True:
                chunk = response.read(256 * 1024)
                if not chunk:
                    break
                read += len(chunk)
                if read >= SAMPLE_BYTES:
                    break
    except (urllib.error.URLError, OSError):
        return 0.0
    elapsed = max(0.001, time.monotonic() - start)
    return read / elapsed


def _download_range(
    url: str,
    headers: dict[str, str],
    start: int,
    end: int,
    part_path: Path,
    on_chunk: Callable[[int], None] | None = None,
) -> int:
    """Download ``[start, end]`` into *part_path*, continuing a partial part.

    Returns the bytes written in this session."""
    part_path.parent.mkdir(parents=True, exist_ok=True)
    expected = end - start + 1
    offset = part_path.stat().st_size if part_path.exists() else 0
    offset = min(offset, expected)
    request_headers = {**headers, "Range": f"bytes={start + offset}-{end}"}
    written = 0
    with (
        urllib.request.urlopen(urllib.request.Request(url, headers=request_headers),
                               timeout=CHUNK_TIMEOUT) as response,
        part_path.open("ab") as fh,
    ):
        while True:
            chunk = response.read(256 * 1024)
            if not chunk:
                break
            fh.write(chunk)
            written += len(chunk)
            if on_chunk:
                on_chunk(offset + written)
    if offset + written != expected:
        raise OSError(f"incomplete chunk {start}-{end}: {offset + written}/{expected} bytes")
    return written


def download(
    url: str,
    target: Path,
    headers: dict[str, str] | None = None,
    connections: int = DEFAULT_CONNECTIONS,
    progress: ProgressHook | None = None,
    on_total: ProgressHook | None = None,
) -> Path | None:
    """Download *url* to *target* as fast as the server allows.

    Returns the target path, or ``None`` when the download could not be
    completed (the caller then falls back to the browser download).
    """
    headers = dict(headers or {})
    headers.setdefault("User-Agent", "Mozilla/5.0 (X11; Linux x86_64) zoom-joiner")
    headers.pop("Range", None)
    headers.pop("range", None)

    info = _probe(url, headers)
    if info is None:
        return None
    total, ranged = info
    if total <= 0:
        return None
    if on_total:
        on_total(total)

    target.parent.mkdir(parents=True, exist_ok=True)
    if not ranged:
        return _download_single(url, target, headers, total, progress)

    # Adaptive strategy: parallel connections only pay off when the link is
    # slow (latency bound).  A quick sample tells us which case we are in.
    if total >= PARALLEL_MIN_SIZE and connections > 1:
        speed = _sample_speed(url, headers, total)
        if speed >= PARALLEL_SPEED_THRESHOLD:
            # the single stream is already fast enough — keep it simple
            return _download_single(url, target, headers, total, progress, resume=True)
    else:
        return _download_single(url, target, headers, total, progress, resume=True)

    part_dir = target.with_suffix(target.suffix + ".parts")
    part_dir.mkdir(parents=True, exist_ok=True)
    connections = max(1, min(connections, 16))
    size = math.ceil(total / connections)
    ranges = []
    for index in range(connections):
        start = index * size
        end = min(start + size, total) - 1
        if start > end:
            break
        ranges.append((index, start, end))

    errors: list[BaseException] = []

    # the starting point: bytes that are already on disk from previous sessions
    def _disk_size(index: int, expected: int) -> int:
        part_path = part_dir / f"part-{index:03d}"
        with contextlib.suppress(OSError):
            return min(part_path.stat().st_size, expected)
        return 0

    state = {"done": sum(_disk_size(i, e - s + 1) for i, s, e in ranges)}
    lock = threading.Lock()

    def report(delta: int) -> None:
        if not progress:
            return
        with lock:
            state["done"] += max(0, delta)
            progress(state["done"])

    def fetch(item: tuple[int, int, int]) -> int:
        index, start, end = item
        part_path = part_dir / f"part-{index:03d}"
        expected = end - start + 1
        initial = _disk_size(index, expected)
        if initial >= expected:
            return expected  # already downloaded (resume)
        def hook(n: int) -> None:
            report(n - initial)
        return _download_range(url, headers, start, end, part_path, hook)

    with ThreadPoolExecutor(max_workers=connections) as pool:
        futures = {pool.submit(fetch, item): item for item in ranges}
        for future in futures:
            try:
                future.result()
            except Exception as exc:  # noqa: BLE001
                errors.append(exc)
                continue

    if errors:
        # keep the parts on disk so a retry can resume
        return None

    with target.open("wb") as out:
        for index, _start, _end in ranges:
            part_path = part_dir / f"part-{index:03d}"
            with part_path.open("rb") as fh:
                while True:
                    chunk = fh.read(1024 * 1024)
                    if not chunk:
                        break
                    out.write(chunk)

    with contextlib.suppress(OSError):
        for index, _start, _end in ranges:
            (part_dir / f"part-{index:03d}").unlink(missing_ok=True)
    with contextlib.suppress(OSError):
        part_dir.rmdir()
    return target


def _download_single(
    url: str,
    target: Path,
    headers: dict[str, str],
    total: int,
    progress: ProgressHook | None,
    resume: bool = False,
) -> Path | None:
    """Single-connection download; a previous partial piece is continued."""
    part_dir = target.with_suffix(target.suffix + ".parts")
    part_path = part_dir / "part-000"
    offset = 0
    if resume:
        with contextlib.suppress(OSError):
            offset = part_path.stat().st_size
            if offset > total:
                offset = 0
    request_headers = dict(headers)
    if offset:
        request_headers["Range"] = f"bytes={offset}-{total - 1}"
    request = urllib.request.Request(url, headers=request_headers)
    written = 0
    try:
        if resume:
            part_dir.mkdir(parents=True, exist_ok=True)
            stream = part_path.open("ab")
        else:
            stream = target.open("wb")
        with (
            urllib.request.urlopen(request, timeout=CHUNK_TIMEOUT) as response,
            stream as fh,
        ):
            while True:
                chunk = response.read(512 * 1024)
                if not chunk:
                    break
                fh.write(chunk)
                written += len(chunk)
                if progress:
                    progress(offset + written)
    except (urllib.error.URLError, OSError):
        return None
    if total and written + offset < total:
        return None
    if resume:
        # assemble from the part and clean it up
        with target.open("wb") as out, part_path.open("rb") as fh:
            while True:
                chunk = fh.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
        with contextlib.suppress(OSError):
            part_path.unlink(missing_ok=True)
            part_dir.rmdir()
    return target


def human_size(size: int) -> str:
    value = float(size)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} GB"


def free_space(path: Path) -> int:
    try:
        usage = os.statvfs(path if path.exists() else path.parent)
        return usage.f_bavail * usage.f_frsize
    except (OSError, AttributeError):
        return 0
