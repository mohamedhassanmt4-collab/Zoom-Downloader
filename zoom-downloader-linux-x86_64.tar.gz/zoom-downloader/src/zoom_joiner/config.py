"""Configuration loading: YAML / JSON / CSV / plain-text meeting lists."""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .models import Meeting

_TRUE = {"1", "true", "yes", "y", "on"}


def _as_bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in _TRUE


def _as_str(value: Any, default: str = "") -> str:
    if value is None:
        return default
    return str(value).strip()


@dataclass(slots=True)
class Settings:
    """Global run settings (CLI flags override these)."""

    backend: str = "web"
    parallel: int = 3
    passkey: str = ""
    name: str = "Attendee"
    headful: bool = False
    keep_open: bool = False
    timeout: float = 90.0
    retries: int = 1
    user_data_dir: str = ""
    screenshot_on_failure: bool = True
    browser_args: list[str] = field(default_factory=list)
    join_audio: str = "auto"


@dataclass(slots=True)
class Job:
    """A parsed configuration file: settings + meetings."""

    settings: Settings
    meetings: list[Meeting]
    source: Path | None = None
    warnings: list[str] = field(default_factory=list)


def _meeting_from_mapping(raw: dict[str, Any], defaults: Settings) -> Meeting:
    raw = {str(k).strip().lower(): v for k, v in raw.items()}
    url = _as_str(raw.get("url") or raw.get("link") or raw.get("meeting") or raw.get("id"))
    name = _as_str(raw.get("name") or raw.get("title")) or "Meeting"
    passcode = _as_str(raw.get("passcode") or raw.get("password") or raw.get("pwd"))
    if not passcode:
        passcode = defaults.passkey
    return Meeting(
        name=name,
        url=url,
        passcode=passcode,
        otp=_as_str(raw.get("otp") or raw.get("passkey") or raw.get("2fa")),
        wait_for_host=_as_bool(raw.get("wait_for_host"), defaults.keep_open),
        keep_open=_as_bool(raw.get("keep_open"), defaults.keep_open),
        join_audio=_as_str(raw.get("join_audio") or defaults.join_audio) or "auto",
        browser_profile=_as_str(raw.get("profile") or raw.get("browser_profile")),
        notes=_as_str(raw.get("notes")),
        tags=[str(t).strip() for t in (raw.get("tags") or []) if str(t).strip()],
    )


def _settings_from_mapping(raw: dict[str, Any]) -> Settings:
    raw = {str(k).strip().lower(): v for k, v in raw.items()}
    settings = Settings()
    if "backend" in raw:
        settings.backend = _as_str(raw["backend"], "web").lower()
    if "parallel" in raw:
        settings.parallel = max(1, int(raw["parallel"]))
    if "passkey" in raw:
        settings.passkey = _as_str(raw["passkey"])
    if "name" in raw:
        settings.name = _as_str(raw["name"], "Attendee")
    if "headful" in raw:
        settings.headful = _as_bool(raw["headful"])
    if "keep_open" in raw:
        settings.keep_open = _as_bool(raw["keep_open"])
    if "timeout" in raw:
        settings.timeout = float(raw["timeout"])
    if "retries" in raw:
        settings.retries = max(0, int(raw["retries"]))
    if "user_data_dir" in raw:
        settings.user_data_dir = _as_str(raw["user_data_dir"])
    if "screenshot_on_failure" in raw:
        settings.screenshot_on_failure = _as_bool(raw["screenshot_on_failure"], True)
    if "join_audio" in raw:
        settings.join_audio = _as_str(raw["join_audio"], "auto")
    if "browser_args" in raw:
        args = raw["browser_args"] or []
        settings.browser_args = [str(a) for a in args]
    return settings


def _load_yaml(path: Path) -> tuple[Settings, list[Meeting], list[str]]:
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    warnings: list[str] = []
    if isinstance(data, list):
        defaults = Settings()
        meetings = [
            _meeting_from_mapping(item, defaults) for item in data if isinstance(item, dict)
        ]
        return defaults, meetings, warnings
    if not isinstance(data, dict):
        raise ValueError(f"{path}: unsupported YAML structure")

    defaults = _settings_from_mapping(data.get("defaults") or {})
    raw_meetings = data.get("meetings") or data.get("items") or []
    meetings: list[Meeting] = []
    for item in raw_meetings:
        if isinstance(item, str):
            meetings.append(_meeting_from_mapping({"url": item}, defaults))
        elif isinstance(item, dict):
            meetings.append(_meeting_from_mapping(item, defaults))
        else:
            warnings.append(f"ignored malformed meeting entry: {item!r}")
    return defaults, meetings, warnings


def _load_json(path: Path) -> tuple[Settings, list[Meeting], list[str]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data, list):
        defaults = Settings()
        return (
            defaults,
            [_meeting_from_mapping(i, defaults) for i in data if isinstance(i, dict)],
            [],
        )
    defaults = _settings_from_mapping(data.get("defaults") or {})
    return (
        defaults,
        [_meeting_from_mapping(i, defaults) for i in (data.get("meetings") or [])],
        [],
    )


def _load_csv(path: Path) -> tuple[Settings, list[Meeting], list[str]]:
    defaults = Settings()
    meetings: list[Meeting] = []
    with path.open(encoding="utf-8-sig", newline="") as fh:
        for row in csv.DictReader(fh):
            cleaned = {k.strip().lower(): v for k, v in row.items() if k}
            if not any((v or "").strip() for v in cleaned.values()):
                continue
            meetings.append(_meeting_from_mapping(cleaned, defaults))
    return defaults, meetings, []


def _load_txt(path: Path) -> tuple[Settings, list[Meeting], list[str]]:
    """One meeting per line: ``<url> [passcode] [name]`` (name may contain spaces)."""
    defaults = Settings()
    meetings: list[Meeting] = []
    for lineno, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        url = parts[0]
        passcode = parts[1] if len(parts) > 1 and not parts[1].startswith("http") else ""
        name = " ".join(parts[2:]) if len(parts) > 2 else ""
        entry = {"url": url, "passcode": passcode, "name": name or f"Meeting {lineno}"}
        meetings.append(_meeting_from_mapping(entry, defaults))
    return defaults, meetings, []


def load_config(path: str | Path) -> Job:
    """Load a configuration file of any supported format."""
    path = Path(path).expanduser()
    if not path.exists():
        raise FileNotFoundError(f"configuration file not found: {path}")
    suffix = path.suffix.lower()
    if suffix in {".yaml", ".yml"}:
        settings, meetings, warnings = _load_yaml(path)
    elif suffix == ".json":
        settings, meetings, warnings = _load_json(path)
    elif suffix == ".csv":
        settings, meetings, warnings = _load_csv(path)
    elif suffix in {".txt", ".lst"}:
        settings, meetings, warnings = _load_txt(path)
    else:
        raise ValueError(f"unsupported config format: {path.suffix} (use .yaml/.json/.csv/.txt)")
    return Job(settings=settings, meetings=meetings, source=path, warnings=warnings)


EXAMPLE_YAML = """\
# zoom-joiner configuration
defaults:
  backend: web          # web (Chromium via Playwright) | desktop (native Zoom client)
  parallel: 3           # how many meetings to join at the same time
  passkey: ""           # global fallback passcode used when a meeting has none
  name: "Mohamed"       # display name shown to the host
  headful: false        # true = show the browser window (useful for debugging)
  timeout: 90           # seconds allowed per meeting
  retries: 1            # extra attempts per meeting
  keep_open: false      # keep the meeting window open after joining
  join_audio: auto      # auto | computer | none

meetings:
  - name: "Daily Standup"
    url: "https://zoom.us/j/12345678901"
    passcode: "123456"
  - name: "Client Review"
    url: "https://zoom.us/j/98765432101?pwd=abc"
  - name: "Interview"
    url: "https://zoom.us/j/55566677788"
    passcode: "000111"
    notes: "with the panel, join 5 min early"
"""
