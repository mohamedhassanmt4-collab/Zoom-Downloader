"""Download Zoom recordings (cloud recordings shared by link).

Two ways a recording can be fetched:

* **share link + passcode** – the usual case:
  ``https://us06web.zoom.us/rec/share/<token>?pwd=<passcode>``.
  The passcode is entered in the browser, then the recording is downloaded
  through the official *Download* button (video / audio / transcript).

* **direct media url** – if the page exposes the media file directly it is
  streamed with plain HTTP.

Everything is driven with Playwright, exactly like the joiner, so no Zoom
account is required — only the share link and its passcode.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import re
import socket
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import parse_qs, urljoin, urlparse

from playwright.async_api import Error as PlaywrightError
from playwright.async_api import Page, async_playwright
from playwright.async_api import TimeoutError as PlaywrightTimeout

from .fastdl import download as fast_download
from .fastdl import human_size
from .names import safe_filename

log = logging.getLogger("zoom_joiner.download")

PASSCODE_FIELDS = (
    "input[type='password']",
    "input[name='passcode']",
    "input[id*='passcode' i]",
    "input[placeholder*='passcode' i]",
    "input[placeholder*='code' i]",
)

ACCESS_BUTTONS = (
    "button.passcode-submit",
    "button:has-text('Confirm')",
    "button:has-text('Access')",
    "button:has-text('Submit')",
    "button:has-text('View')",
    "button:has-text('Open')",
    "form button[type='submit']",
)

#: the Zoom player streams the recording from the CDN — we capture that
#: request (url + headers) instead of clicking the download button.
MEDIA_SUFFIXES = (".mp4", ".m4a", ".mov", ".webm")
TRANSCRIPT_MARKERS = ("/transcript",)

DOWNLOAD_BUTTONS = (
    "button:has-text('Download')",
    "a:has-text('Download')",
    "[aria-label*='Download' i]",
)

MENU_ITEMS = {
    "video": ("Video", "MP4", "Video recording"),
    "audio": ("Audio", "Audio only", "Audio recording", "M4A"),
    "transcript": ("Transcript", "VTT", "Subtitles"),
}

SIGNED_IN_TEXTS = (
    "sign in to download",
    "sign in to view",
    "you need to sign in",
    "login required",
    "this recording is only available to the host",
)

FAILURE_TEXTS = (
    "invalid passcode",
    "passcode is incorrect",
    "incorrect passcode",
    "recording not found",
    "recording has been deleted",
    "you do not have permission",
    "sharing has been disabled",
    "file not found",
    "expired",
)

WAITING_TEXTS = (
    "the recording is being processed",
    "processing the recording",
    "recording is not ready",
    "the host has not started the recording",
)

VIDEO_URL_RE = re.compile(r"https?://[^\s\"'<>]+\.(?:mp4|m4a|mov|webm|vtt)", re.I)


@dataclass(slots=True)
class DownloadRequest:
    """One recording to fetch."""

    url: str
    name: str = ""
    passcode: str = ""
    out_dir: str = "."
    video: bool = True
    audio: bool = False
    transcript: bool = False
    timeout: float = 600.0
    connections: int = 8
    retries: int = 2

    @property
    def passcode_from_url(self) -> str:
        try:
            parsed = urlparse(self.url)
        except ValueError:
            return ""
        values = parse_qs(parsed.query).get("pwd", [])
        return values[0] if values else ""


@dataclass(slots=True)
class DownloadResult:
    """Outcome of one recording download."""

    request: DownloadRequest
    status: str = "pending"
    message: str = ""
    files: list[str] = field(default_factory=list)
    total_bytes: int = 0
    expected_bytes: int = 0
    title: str = ""

    @property
    def ok(self) -> bool:
        return self.status in {"done", "partial"}


def _safe_name(text: str, fallback: str = "recording") -> str:
    return safe_filename(text, fallback)


def _size_on_disk(paths: list[str]) -> int:
    """The only trustworthy size: what actually landed on disk."""
    total = 0
    for name in paths:
        with contextlib.suppress(OSError):
            total += Path(name).stat().st_size
    return total


_MONTHS = {
    "jan": 1, "january": 1, "feb": 2, "february": 2, "mar": 3, "march": 3,
    "apr": 4, "april": 4, "may": 5, "jun": 6, "june": 6, "jul": 7, "july": 7,
    "aug": 8, "august": 8, "sep": 9, "sept": 9, "september": 9,
    "oct": 10, "october": 10, "nov": 11, "november": 11, "dec": 12, "december": 12,
}


def parse_recording_date(text: str) -> str:
    """Return the recording date as ``YYYY-MM-DD`` (Zoom shows e.g. "May 1, 2025 07:19 PM Cairo")."""
    cleaned = " ".join((text or "").split())
    if not cleaned:
        return ""
    iso = re.search(r"(\d{4})-(\d{2})-(\d{2})(?!\d)", cleaned)
    if iso:
        year, month, day = (int(part) for part in iso.groups())
    else:
        match = re.search(r"\b([A-Za-z]{3,9})\.?\s+(\d{1,2}),?\s+(\d{4})\b", cleaned)
        if not match:
            match = re.search(r"\b(\d{1,2})\s+([A-Za-z]{3,9})\.?,?\s+(\d{4})\b", cleaned)
            if match:
                day, month_name, year = match.groups()
            else:
                return ""
        else:
            month_name, day, year = match.groups()
        month = _MONTHS.get(month_name.lower().rstrip("."), 0)
        day = int(day)
        year = int(year)
        if not month:
            return ""
    try:
        return f"{year:04d}-{month:02d}-{day:02d}"
    except (TypeError, ValueError):
        return ""


async def _recording_date(page: Page) -> str:
    for selector in (".start-time-str", "time", "[class*='start-time' i]"):
        with contextlib.suppress(PlaywrightError):
            element = await page.query_selector(selector)
            if element is None:
                continue
            raw = (await element.inner_text()).strip()
            date = parse_recording_date(raw)
            if date:
                return date
    return ""


NETWORK_ERRORS = {
    "ERR_NAME_NOT_RESOLVED": (
        "cannot resolve the Zoom address (DNS) — check the internet connection "
        "and press Download again"
    ),
    "ERR_INTERNET_DISCONNECTED": "no internet connection — check the network and retry",
    "ERR_NETWORK_CHANGED": "the network changed during the download — retry",
    "ERR_CONNECTION_REFUSED": "Zoom refused the connection — check a proxy/VPN and retry",
    "ERR_CONNECTION_RESET": "the connection to Zoom was reset — retry",
    "ERR_CONNECTION_TIMED_OUT": "the connection to Zoom timed out — check the network and retry",
    "ERR_TIMED_OUT": "the connection to Zoom timed out — check the network and retry",
    "ERR_CERT_": "Zoom's certificate could not be verified — a proxy/VPN may be "
    "intercepting the connection",
    "ERR_PROXY_CONNECTION_FAILED": "the proxy refused the connection — check the proxy settings",
}


def humanize_playwright_error(raw: str) -> str:
    """Turn a Playwright/net error into something a human can act on."""
    for marker, message in NETWORK_ERRORS.items():
        if marker in raw:
            return message
    if "Timeout" in raw and "goto" in raw:
        return (
            "the recording page took too long to load (slow network or Zoom is busy) — "
            "pressing Download again usually works"
        )
    detail = raw.strip().splitlines()[0] if raw.strip() else "unknown error"
    return f"browser error: {detail[:240]}"


def system_dns_ips(host: str) -> list[str]:
    """Resolve with the OS resolver (Chromium's own resolver can fail on VPNs)."""
    try:
        infos = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
    except OSError:
        return []
    return sorted({info[4][0] for info in infos if info[0] == socket.AF_INET})


def host_resolver_rules(mapping: dict[str, str]) -> str:
    return ", ".join(f"MAP {host} {ip}" for host, ip in mapping.items())


GENERIC_TITLES = {
    "recordings player page",
    "zoom",
    "zoom recording",
    "zoom cloud recording",
    "recording",
    "recordings",
}


def meaningful_title(text: str) -> str:
    """Page headings that are just Zoom chrome are not a recording name."""
    cleaned = " ".join(text.split())
    if not cleaned or cleaned.lower() in GENERIC_TITLES:
        return ""
    return cleaned


def _extension_for(kind: str) -> str:
    return {"video": "mp4", "audio": "m4a", "transcript": "vtt"}.get(kind, "mp4")


def _token_from_url(url: str) -> str:
    try:
        path = urlparse(url).path.rstrip("/")
    except ValueError:
        return "recording"
    token = path.rsplit("/", 1)[-1]
    return _safe_name(token, "recording")[:40]


class RecordingDownloader:
    """Downloads Zoom recordings through a headless browser."""

    def __init__(self, headless: bool = True, parallel: int = 2) -> None:
        self.headless = headless
        self.parallel = max(1, parallel)
        self._playwright = None
        self._browser = None
        self._host_map: dict[str, str] = {}
        self._sem = asyncio.Semaphore(self.parallel)

    # -- lifecycle ---------------------------------------------------------------
    async def start(self) -> None:
        self._playwright = await async_playwright().start()
        await self._launch()

    async def _launch(self) -> None:
        args = [
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--disable-blink-features=AutomationControlled",
            "--autoplay-policy=no-user-gesture-required",
        ]
        if self._host_map:
            args.append(f"--host-resolver-rules={host_resolver_rules(self._host_map)}")
        self._browser = await self._playwright.chromium.launch(headless=self.headless, args=args)

    async def _relaunch_with_host_map(self) -> None:
        """Chromium's resolver failed but the OS one works — pin the address."""
        if self._browser:
            with contextlib.suppress(Exception):
                await self._browser.close()
        await self._launch()
        log.info("browser relaunched with host map: %s", self._host_map)

    async def stop(self) -> None:
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()

    # -- helpers -----------------------------------------------------------------
    @staticmethod
    async def _first_visible(page: Page, selectors: tuple[str, ...]) -> str | None:
        for sel in selectors:
            try:
                loc = page.locator(sel).first
                if await loc.count() and await loc.is_visible():
                    return sel
            except PlaywrightError:
                continue
        return None

    @staticmethod
    async def _click_first(page: Page, selectors: tuple[str, ...], timeout: float = 5.0) -> bool:
        for sel in selectors:
            try:
                loc = page.locator(sel).first
                if not await loc.count():
                    continue
                await loc.wait_for(state="visible", timeout=int(timeout * 1000))
                await loc.click(timeout=int(timeout * 1000))
                return True
            except (PlaywrightError, PlaywrightTimeout):
                continue
        return False

    @staticmethod
    async def _fill_first(
        page: Page, selectors: tuple[str, ...], value: str, timeout: float = 3.0
    ) -> bool:
        for sel in selectors:
            try:
                loc = page.locator(sel).first
                if not await loc.count():
                    continue
                await loc.wait_for(state="visible", timeout=int(timeout * 1000))
                await loc.fill(value)
                return True
            except (PlaywrightError, PlaywrightTimeout):
                continue
        return False

    @staticmethod
    async def _body_text(page: Page) -> str:
        try:
            return (await page.inner_text("body")).lower()
        except PlaywrightError:
            return ""

    @staticmethod
    async def _has_media(page: Page) -> bool:
        for sel in ("video source[src]", "video[src]", "source[src]", "audio[src]"):
            try:
                loc = page.locator(sel).first
                if await loc.count() and await loc.get_attribute("src"):
                    return True
            except PlaywrightError:
                continue
        return False

    @staticmethod
    def _is_download_request(url: str) -> bool:
        lowered = url.lower()
        if lowered.startswith(("blob:", "data:")):
            return False
        return any(
            marker in lowered
            for marker in (
                "/rec/download",
                "/recshare/download",
                "downloadrecording",
                ".mp4",
                ".m4a",
                ".vtt",
                "download=",
            )
        )

    async def _capture_download_url(
        self, page: Page, kinds: list[str]
    ) -> tuple[str, dict[str, str]] | None:
        """Click the download control and grab the signed url of the file.

        The request is aborted so the browser never downloads the file — we
        fetch it ourselves with several parallel connections instead.
        """
        captured: dict[str, str] = {}

        async def handler(route) -> None:  # noqa: ANN001
            request = route.request
            if self._is_download_request(request.url):
                captured.setdefault("url", request.url)
                captured.setdefault("headers", json.dumps(dict(request.headers)))
                await route.abort()
            else:
                await route.continue_()

        await page.route("**/*", handler)
        try:
            for _kind, labels in kinds:
                for label in labels:
                    if await self._click_first(page, (f"text={label}",), timeout=1.5):
                        break
                else:
                    if not await self._click_first(page, DOWNLOAD_BUTTONS, timeout=2.0):
                        continue
                deadline = asyncio.get_event_loop().time() + 15.0
                while asyncio.get_event_loop().time() < deadline:
                    if captured.get("url"):
                        break
                    await asyncio.sleep(0.3)
                if captured.get("url"):
                    break
        finally:
            await page.unroute("**/*", handler)

        if not captured.get("url"):
            return None
        try:
            headers = json.loads(captured.get("headers", "{}"))
        except json.JSONDecodeError:
            headers = {}
        return captured["url"], headers

    async def _passcode_prompt(self, page: Page) -> bool:
        return await self._first_visible(page, PASSCODE_FIELDS) is not None

    async def _submit_passcode(self, page: Page, passcode: str, timeout: float = 30.0) -> bool:
        """Wait for the passcode form, type the code and submit it."""
        deadline = asyncio.get_event_loop().time() + timeout
        while asyncio.get_event_loop().time() < deadline:
            if await self._fill_first(page, PASSCODE_FIELDS, passcode, timeout=1.0):
                if await self._click_first(page, ACCESS_BUTTONS, timeout=2.0):
                    return True
                # some pages submit the form with the Enter key
                try:
                    await page.keyboard.press("Enter")
                    return True
                except PlaywrightError:
                    pass
            await asyncio.sleep(0.5)
        return False

    async def _page_title(self, page: Page) -> str:
        for sel in ("h1", "h2", ".recording-title", "title"):
            try:
                loc = page.locator(sel).first
                if await loc.count():
                    text = meaningful_title(await loc.inner_text())
                    if text:
                        return text
            except PlaywrightError:
                continue
        return ""

    # -- main flow ---------------------------------------------------------------
    async def download(
        self,
        request: DownloadRequest,
        on_progress: Callable[[int], None] | None = None,
        on_total: Callable[[int], None] | None = None,
    ) -> DownloadResult:
        result = DownloadResult(request=request)
        expected: dict[str, int] = {}
        out_dir = Path(request.out_dir).expanduser()
        out_dir.mkdir(parents=True, exist_ok=True)

        async with self._sem:
            if self._browser is None:
                await self.start()
            attempts = max(1, request.retries + 1)
            for attempt in range(1, attempts + 1):
                context = await self._browser.new_context(
                    accept_downloads=True, viewport={"width": 1366, "height": 900}
                )
                page = await context.new_page()
                retry_now = False
                try:
                    await self._run(
                        page, request, result, out_dir, expected, on_progress, on_total
                    )
                except PlaywrightTimeout as exc:
                    result.status = "failed"
                    result.message = humanize_playwright_error(f"Timeout {exc}")
                except PlaywrightError as exc:
                    raw = str(exc)
                    result.status = "failed"
                    result.message = humanize_playwright_error(raw)
                    if "ERR_NAME_NOT_RESOLVED" in raw:
                        # Chromium's resolver failed — if the OS can resolve the
                        # name, map it directly and retry at once (VPN/split-DNS)
                        host = urlparse(request.url).hostname or ""
                        ips = system_dns_ips(host)
                        if ips:
                            self._host_map[host] = ips[0]
                            await self._relaunch_with_host_map()
                            result.message = (
                                f"Chromium could not resolve {host}, but the system could — "
                                "continuing with the system address"
                            )
                            retry_now = True
                        else:
                            result.status = "network"
                            result.message = (
                                f"cannot resolve {host} (DNS) — the internet connection "
                                "looks offline; check it and press Download again"
                            )
                finally:
                    # the browser may have been relaunched for the DNS bypass
                    with contextlib.suppress(Exception):
                        await context.close()
                if result.status in {"network", "needs-passcode"}:
                    break
                if attempt >= attempts:
                    break
                if result.status in {"done", "partial", "waiting"}:
                    break
                # a fresh page and a small backoff: Zoom occasionally refuses
                # rapid parallel access — a second look usually succeeds
                result.status = "opening"
                result.files = []
                result.total_bytes = 0
                delay = 2 * attempt
                log.warning(
                    "attempt %d/%d failed (%s)%s",
                    attempt,
                    attempts,
                    result.message[:70],
                    "" if retry_now else f" — retrying in {delay}s",
                )
                if not retry_now:
                    await asyncio.sleep(delay)
        return result

    def _progress_hook(
        self,
        result: DownloadResult,
        expected: dict[str, int],
        target: Path,
        on_progress: Callable[[int], None] | None,
    ) -> Callable[[int], None]:
        def hook(done: int) -> None:
            limit = expected.get(str(target), 0)
            if limit and done > limit:
                done = limit
            result.total_bytes = done
            if on_progress:
                on_progress(done)

        return hook

    async def _run(
        self,
        page: Page,
        request: DownloadRequest,
        result: DownloadResult,
        out_dir: Path,
        expected: dict[str, int],
        on_progress: Callable[[int], None] | None,
        on_total: Callable[[int], None] | None,
    ) -> None:
        result.status = "opening"

        # 1) watch the network: the player asks the CDN for the recording file.
        #    We keep the url + the headers (session cookie) and abort the
        #    request so the browser does not download a 300 MB file we are
        #    going to fetch ourselves with parallel connections.
        captured: dict[str, tuple[str, dict[str, str]]] = {}

        async def handler(route) -> None:  # noqa: ANN001
            url = route.request.url
            low = url.lower()
            kind = ""
            if any(low.endswith(suffix) or f"{suffix}?" in low for suffix in MEDIA_SUFFIXES):
                kind = "audio" if ".m4a" in low else "video"
            elif any(marker in low for marker in TRANSCRIPT_MARKERS):
                kind = "transcript"
            if kind:
                log.debug("captured a %s request: %s", kind, url[:120])
                captured.setdefault(kind, (url, {k: v for k, v in route.request.headers.items()}))
                if kind in {"video", "audio"}:
                    await route.abort()
                    return
            await route.continue_()

        await page.route("**/*", handler)

        try:
            await page.goto(request.url, wait_until="domcontentloaded", timeout=60000)

            # 2) passcode gate — fail fast with a clear instruction instead of
            #    waiting for a recording that cannot appear without the code
            passcode = request.passcode or request.passcode_from_url
            gate = await self._passcode_prompt(page)
            if gate and not passcode:
                result.status = "needs-passcode"
                result.message = (
                    "this recording asks for a passcode — type it in the Passcode column "
                    "(or the Default passcode box) and press Download again"
                )
                return
            if passcode:
                submitted = await self._submit_passcode(page, passcode)
                log.debug("passcode submitted: %s", submitted)

            # 3) wait for the recording file (or a clear error)
            deadline = asyncio.get_event_loop().time() + min(request.timeout, 180.0)
            has_button = False
            wanted = (["video"] if request.video else []) + (["audio"] if request.audio else [])
            checked_gate = gate
            while asyncio.get_event_loop().time() < deadline:
                if not passcode and not checked_gate:
                    # the passcode form is rendered by React a few seconds
                    # after the page loads — keep an eye out for it
                    checked_gate = await self._passcode_prompt(page)
                    if checked_gate:
                        result.status = "needs-passcode"
                        result.message = (
                            "this recording asks for a passcode — type it in the Passcode "
                            "column (or the Default passcode box) and press Download again"
                        )
                        return
                text = await self._body_text(page)
                if any(t in text for t in FAILURE_TEXTS):
                    result.status = "failed"
                    result.message = self._snippet(text, FAILURE_TEXTS)
                    if "passcode" in result.message.lower():
                        result.message = (
                            "the passcode seems incorrect — check it and press Download again"
                        )
                    return
                if any(t in text for t in SIGNED_IN_TEXTS):
                    result.status = "failed"
                    result.message = (
                        "Zoom asks for an account sign-in before downloading this recording — "
                        "open the link in your browser once and sign in, then retry"
                    )
                    return
                if any(t in text for t in WAITING_TEXTS):
                    result.status = "waiting"
                    result.message = "the recording is still being processed by Zoom"
                    return
                if any(kind in captured for kind in wanted or ["video"]):
                    break
                if not has_button and await self._first_visible(page, DOWNLOAD_BUTTONS):
                    has_button = True
                await asyncio.sleep(0.5)
            else:
                if not captured:
                    result.status = "failed"
                    result.message = (
                        "no download button found on the recording page"
                        if not has_button
                        else "the recording page did not expose the file"
                    )
                    return

            result.title = await self._page_title(page)
            base = _safe_name(
                request.name or result.title or _token_from_url(request.url),
                _token_from_url(request.url),
            )
            recording_date = await _recording_date(page)
            if recording_date:
                base = _safe_name(f"{base} {recording_date}", _token_from_url(request.url))

            # 4) fetch straight from the CDN with parallel connections —
            #    the video, and the audio too when it was requested; a
            #    recording can also be audio-only (phone / no camera)
            fetches = [
                ("video", captured["video"]) if request.video and "video" in captured else None,
                ("audio", captured["audio"]) if request.audio and "audio" in captured else None,
            ]
            if request.video and "video" not in captured and "audio" in captured:
                # audio-only recording (phone / no camera): the m4a IS the file
                fetches.append(("audio", captured["audio"]))
            for fetch in [f for f in fetches if f]:
                kind, (url, headers) = fetch
                target = out_dir / f"{base}.{_extension_for(kind)}"
                result.status = "downloading"
                result.message = f"downloading the {kind}…"
                path = await asyncio.to_thread(
                    self._fast_fetch,
                    url,
                    target,
                    headers,
                    request.connections,
                    result,
                    expected,
                    on_progress,
                    on_total,
                )
                if not path:
                    continue
                if not self._looks_like_media(path):
                    # validation failed → drop the file; the retry loop runs a
                    # fresh attempt and .parts lets it resume the pieces
                    path.unlink(missing_ok=True)
                    result.status = "failed"
                    result.message = (
                        "the downloaded file did not pass validation — retrying from scratch"
                    )
                    return
                result.files.append(str(path))

            # 5) the transcript: a small file, straight from the API
            if request.transcript and "transcript" in captured:
                url, headers = captured["transcript"]
                target = out_dir / f"{base}.vtt"
                path = await asyncio.to_thread(self._fetch_small, url, target, headers)
                if path:
                    result.files.append(str(path))
                    with contextlib.suppress(OSError):
                        result.total_bytes += path.stat().st_size

            audio_only = request.video and "video" not in captured and any(
                f.endswith(".m4a") for f in result.files
            )
            complete = (
                (
                    not request.video
                    or any(f.endswith(".mp4") for f in result.files)
                    or audio_only
                )
                and (not request.audio or any(f.endswith(".m4a") for f in result.files))
                and (not request.transcript or any(f.endswith(".vtt") for f in result.files))
            )
            if complete:
                result.status = "done"
                result.total_bytes = _size_on_disk(result.files)
                result.message = f"downloaded {human_size(result.total_bytes)}"
                return

            # 6) fallback: the download menu of the player (only for what is missing)
            wanted: list[tuple[str, tuple[str, ...]]] = []
            if request.audio and not any(f.endswith(".m4a") for f in result.files):
                wanted.append(("audio", MENU_ITEMS["audio"]))
            if request.video and not any(f.endswith(".mp4") for f in result.files):
                wanted.append(("video", MENU_ITEMS["video"]))
            if request.transcript and not any(f.endswith(".vtt") for f in result.files):
                wanted.append(("transcript", MENU_ITEMS["transcript"]))

            for kind, labels in wanted:
                path = await self._download_one(page, base, kind, labels, out_dir, result)
                if path:
                    result.files.append(str(path))
                    with contextlib.suppress(OSError):
                        result.total_bytes += path.stat().st_size

            if not result.files:
                result.status = "failed"
                result.message = "the recording could not be downloaded"
            else:
                result.status = "done"
                result.total_bytes = _size_on_disk(result.files)
                result.message = f"downloaded {len(result.files)} file(s)"
        finally:
            await page.unroute("**/*", handler)

    def _total_hook(
        self,
        target: Path,
        result: DownloadResult,
        expected: dict[str, int],
        on_total: Callable[[int], None] | None,
    ) -> Callable[[int], None]:
        def report(total: int) -> None:
            expected[str(target)] = total
            result.expected_bytes = sum(expected.values())
            if on_total:
                on_total(result.expected_bytes)

        return report

    def _fast_fetch(
        self,
        url: str,
        target: Path,
        headers: dict[str, str],
        connections: int,
        result: DownloadResult,
        expected: dict[str, int],
        on_progress: Callable[[int], None] | None = None,
        on_total: Callable[[int], None] | None = None,
    ) -> Path | None:
        return fast_download(
            url,
            target,
            headers,
            connections,
            self._progress_hook(result, expected, target, on_progress),
            on_total=self._total_hook(target, result, expected, on_total),
        )

    @staticmethod
    def _looks_like_media(path: Path) -> bool:
        """Cheap sanity check of the downloaded file (mp4/m4a have an ftyp box)."""
        try:
            if path.stat().st_size < 1024:
                return False
            with path.open("rb") as fh:
                head = fh.read(64)
        except OSError:
            return False
        if path.suffix == ".vtt":
            return head.lstrip().startswith(b"WEBVTT")
        text = head[:256].decode("ascii", "replace").lower()
        looks_html = any(t in text for t in ("<html", "<!doctype", "<?xml"))
        return not looks_html

    def _fetch_small(self, url: str, target: Path, headers: dict[str, str]) -> Path | None:
        """Fetch a small file (the transcript) and convert it to a real .vtt."""
        import urllib.request

        request = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                body = response.read()
        except Exception:  # noqa: BLE001
            return None
        target.parent.mkdir(parents=True, exist_ok=True)
        text = body.decode("utf-8", "replace")
        if text.lstrip().startswith("{"):
            text = self._json_to_vtt(text)
        target.write_text(text, encoding="utf-8")
        return target

    @staticmethod
    def _json_to_vtt(payload: str) -> str:
        """Zoom returns the transcript as JSON — turn it into a standard VTT file."""
        try:
            data = json.loads(payload)
        except json.JSONDecodeError:
            return payload
        entries = (
            data.get("result", {}).get("dataList")
            or data.get("dataList")
            or data.get("transcript", [])
        )
        if not isinstance(entries, list):
            return payload
        lines = ["WEBVTT", ""]
        for index, item in enumerate(entries, start=1):
            if not isinstance(item, dict):
                continue
            start = str(item.get("startTime") or item.get("start") or "00:00:00.000")
            end = str(item.get("endTime") or item.get("end") or start)
            text = str(item.get("text") or item.get("content") or "").strip()
            if not text:
                continue
            lines.append(f"{index}")
            lines.append(f"{start} --> {end}")
            lines.append(text)
            lines.append("")
        return "\n".join(lines)

    async def _download_one(
        self,
        page: Page,
        base: str,
        kind: str,
        labels: tuple[str, ...],
        out_dir: Path,
        result: DownloadResult,
    ) -> Path | None:
        target = out_dir / f"{base}.{_extension_for(kind)}"
        try:
            async with page.expect_download(timeout=120000) as info:
                # open the type menu when the page offers one
                for label in labels:
                    if await self._click_first(page, (f"text={label}",), timeout=2.0):
                        break
                else:
                    if not await self._click_first(page, DOWNLOAD_BUTTONS, timeout=3.0):
                        return None
            download = await info.value
            await download.save_as(str(target))
            return target
        except (PlaywrightError, PlaywrightTimeout):
            return None

    async def _download_media(self, page: Page, base: str, out_dir: Path) -> Path | None:
        """Last resort: grab a direct media url exposed by the page."""
        url = None
        try:
            for sel in ("video source", "video", "source"):
                loc = page.locator(sel).first
                if not await loc.count():
                    continue
                url = await loc.get_attribute("src")
                if url:
                    break
        except PlaywrightError:
            pass
        if not url:
            try:
                html = await page.content()
                match = VIDEO_URL_RE.search(html)
                url = match.group(0) if match else None
            except PlaywrightError:
                url = None
        if not url:
            return None
        if url.startswith("/"):
            url = urljoin(page.url, url)
        try:
            response = await page.request.get(url, timeout=300000)
            if not response.ok:
                return None
            body = await response.body()
            extension = Path(urlparse(url).path).suffix or ".mp4"
            target = out_dir / f"{base}{extension}"
            target.write_bytes(body)
            return target
        except PlaywrightError:
            return None

    @staticmethod
    def _snippet(text: str, markers: tuple[str, ...]) -> str:
        for marker in markers:
            if marker in text:
                idx = text.find(marker)
                return text[max(0, idx - 40) : idx + len(marker) + 30].strip()
        return "the download was rejected by Zoom"
