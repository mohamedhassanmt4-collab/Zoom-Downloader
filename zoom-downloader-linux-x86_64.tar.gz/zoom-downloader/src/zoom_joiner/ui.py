"""Terminal dashboard (rich) showing live join progress."""

from __future__ import annotations

from rich.console import Console, Group
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .models import MeetingResult, Status

STATUS_STYLE = {
    Status.PENDING: "dim",
    Status.LAUNCHING: "cyan",
    Status.AUTH: "yellow",
    Status.JOINING: "cyan",
    Status.JOINED: "bold green",
    Status.WAITING: "bold yellow",
    Status.FAILED: "bold red",
    Status.SKIPPED: "dim",
    Status.TIMEOUT: "bold red",
}

STATUS_ICON = {
    Status.PENDING: "·",
    Status.LAUNCHING: "»",
    Status.AUTH: "🔑",
    Status.JOINING: "»",
    Status.JOINED: "✔",
    Status.WAITING: "⏳",
    Status.FAILED: "✘",
    Status.SKIPPED: "–",
    Status.TIMEOUT: "⏱",
}

BANNER = r"""
  ███████╗ ██████╗  ██████╗ ███╗   ███╗
  ██╔════╝██╔═══██╗██╔═══██╗████╗ ████║
  ███████╗██║   ██║██║   ██║██╔████╔██║
  ╚════██║██║   ██║██║   ██║██║╚██╔╝██║
  ███████║╚██████╔╝╚██████╔╝██║ ╚═╝ ██║
  ╚══════╝ ╚═════╝  ╚═════╝ ╚═╝     ╚═╝
  batch meeting joiner  •  linux
"""


class Dashboard:
    """Renders a live table of every meeting and its current state."""

    def __init__(self, console: Console) -> None:
        self.console = console
        self.results: list[MeetingResult] = []
        self._live = None

    def set_results(self, results: list[MeetingResult]) -> None:
        self.results = results

    # -- rendering ---------------------------------------------------------------
    def _table(self) -> Table:
        table = Table(expand=True, box=None, pad_edge=False, show_edge=False)
        table.add_column("#", justify="right", style="dim", width=4)
        table.add_column("Meeting", overflow="ellipsis", max_width=34)
        table.add_column("ID", style="dim", overflow="ellipsis", max_width=20)
        table.add_column("Status", width=11)
        table.add_column("Details", overflow="ellipsis")
        table.add_column("Time", justify="right", style="dim", width=7)
        table.add_column("Try", justify="right", style="dim", width=4)

        for idx, res in enumerate(self.results, start=1):
            status = res.status
            label = Text(f"{STATUS_ICON.get(status, '?')} {status.value}")
            label.stylize(STATUS_STYLE.get(status, ""))
            table.add_row(
                str(idx),
                res.meeting.display_name(),
                res.meeting.meeting_id or "—",
                label,
                res.message or "",
                f"{res.duration:.0f}s" if res.finished_at else "…",
                str(res.attempts or ""),
            )
        return table

    def _summary(self) -> Panel:
        ok = sum(1 for r in self.results if r.status is Status.JOINED)
        waiting = sum(1 for r in self.results if r.status is Status.WAITING)
        failed = sum(1 for r in self.results if r.status in {Status.FAILED, Status.TIMEOUT})
        pending = len(self.results) - ok - waiting - failed
        body = Text()
        body.append("joined  ", style="dim")
        body.append(f"{ok}", style="bold green")
        body.append("   waiting ", style="dim")
        body.append(f"{waiting}", style="bold yellow")
        body.append("   failed ", style="dim")
        body.append(f"{failed}", style="bold red")
        body.append("   pending ", style="dim")
        body.append(f"{pending}", style="bold cyan")
        return Panel(body, title="Summary", border_style="cyan", expand=True)

    def render(self) -> Group:
        return Group(self._table(), self._summary())

    # -- lifecycle ---------------------------------------------------------------
    def start(self) -> None:
        from rich.live import Live

        self._live = Live(
            self.render(), console=self.console, refresh_per_second=6, transient=False
        )
        self._live.start()

    def refresh(self, _result=None) -> None:
        if self._live:
            self._live.update(self.render())

    def stop(self) -> None:
        if self._live:
            self._live.update(self.render())
            self._live.stop()
            self._live = None


def print_banner(console: Console) -> None:
    console.print(BANNER, style="bold cyan", justify="center")
    console.print()
