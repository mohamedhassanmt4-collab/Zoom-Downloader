"""Desktop backend: drives the native Zoom client through xdotool (Linux/X11).

This backend is useful when a meeting requires the desktop client (for example
hardware acceleration, or a 2FA flow handled by the client itself). It is
considered experimental: UI automation of the native client depends on the
window titles, which change between Zoom releases.
"""

from __future__ import annotations

import asyncio
import logging
import shutil
import subprocess
import time
from pathlib import Path

from ..meeting import extract_meeting_id
from ..models import Meeting, MeetingResult, Status
from .base import BackendContext, JoinBackend

log = logging.getLogger("zoom_joiner.desktop")

ZOOM_BINARIES = ("zoom", "/usr/bin/zoom", "/opt/zoom/zoom", "/usr/local/bin/zoom")

IN_MEETING_TITLES = ("zoom meeting",)
WAITING_TITLES = ("waiting for the host",)
PROMPT_TITLES = ("zoom",)


class DesktopBackend(JoinBackend):
    """Joins meetings using the installed Zoom desktop client."""

    name = "desktop"

    def __init__(self, ctx: BackendContext) -> None:
        super().__init__(ctx)
        self._proc: subprocess.Popen | None = None
        self._zoom_path: str | None = None

    async def start(self) -> None:
        if not shutil.which("xdotool"):
            raise RuntimeError("the desktop backend needs 'xdotool' (sudo apt install xdotool)")
        self._zoom_path = next(
            (b for b in ZOOM_BINARIES if Path(b).is_file() or shutil.which(b)), None
        )
        if not self._zoom_path:
            raise RuntimeError(
                "the Zoom desktop client was not found (install it or use --backend web)"
            )

    async def stop(self) -> None:
        if self._proc and self._proc.poll() is None:
            self._proc.terminate()

    # -- helpers -----------------------------------------------------------------
    @staticmethod
    def _xdotool(*args: str) -> subprocess.CompletedProcess | None:
        try:
            return subprocess.run(
                ["xdotool", *args], capture_output=True, text=True, timeout=10, check=False
            )
        except (OSError, subprocess.TimeoutExpired):
            return None

    def _windows(self) -> list[str]:
        res = self._xdotool("search", "--name", "Zoom")
        if not res or not res.stdout.strip():
            return []
        titles: list[str] = []
        for wid in res.stdout.split():
            name = self._xdotool("getwindowname", wid)
            if name and name.stdout.strip():
                titles.append(name.stdout.strip())
        return titles

    def _type(self, text: str) -> None:
        self._xdotool("type", "--clearmodifiers", "--delay", "40", text)

    # -- main flow ---------------------------------------------------------------
    async def join(self, meeting: Meeting, result: MeetingResult) -> None:
        meeting_id = extract_meeting_id(meeting.url)
        result.meeting.meeting_id = meeting_id
        if not meeting_id:
            result.status = Status.FAILED
            result.message = "could not extract a meeting id from the URL"
            return

        result.status = Status.LAUNCHING
        target = (
            meeting.url if meeting.url.startswith("http") else f"https://zoom.us/j/{meeting_id}"
        )
        if meeting.passcode and "pwd=" not in target:
            target = f"{target}?pwd={meeting.passcode}"

        try:
            self._proc = subprocess.Popen(
                [self._zoom_path, f"--url={target}"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except OSError as exc:
            result.status = Status.FAILED
            result.message = f"could not launch Zoom: {exc}"
            return

        deadline = time.time() + self.settings.timeout
        typed_passcode = False
        while time.time() < deadline:
            await asyncio.sleep(1.0)
            titles = self._windows()
            lowered = " | ".join(titles).lower()

            if any(t in lowered for t in IN_MEETING_TITLES):
                result.status = Status.JOINED
                result.message = "joined the meeting (desktop client)"
                return

            if any(t in lowered for t in WAITING_TITLES):
                result.status = Status.WAITING
                result.message = "in the waiting room (desktop client)"
                if not meeting.wait_for_host:
                    return
                continue

            # Passcode / name prompt inside the client
            if meeting.passcode and not typed_passcode and "zoom" in lowered:
                focused = self._xdotool("search", "--name", "Zoom")
                if focused and focused.stdout.strip():
                    wid = focused.stdout.split()[0]
                    self._xdotool("windowactivate", "--sync", wid)
                    await asyncio.sleep(0.4)
                    self._type(meeting.passcode)
                    self._xdotool("key", "Return")
                    typed_passcode = True
                    result.status = Status.AUTH
                    result.message = "passcode submitted"

        result.status = Status.TIMEOUT
        result.message = f"timed out after {self.settings.timeout:.0f}s"
