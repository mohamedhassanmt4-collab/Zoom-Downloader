"""Backend interface for joining a single meeting."""

from __future__ import annotations

import abc
from collections.abc import Callable
from dataclasses import dataclass

from ..config import Settings
from ..models import Meeting, MeetingResult


@dataclass(slots=True)
class BackendContext:
    """Shared resources handed to a backend instance."""

    settings: Settings
    report_dir: str = ""
    headless: bool = True
    cancelled: Callable[[], bool] | None = None

    def is_cancelled(self) -> bool:
        return bool(self.cancelled and self.cancelled())


class JoinBackend(abc.ABC):
    """Strategy that knows how to put the user inside a Zoom meeting."""

    name: str = "base"

    def __init__(self, ctx: BackendContext) -> None:
        self.ctx = ctx
        self.settings = ctx.settings

    @abc.abstractmethod
    async def start(self) -> None:
        """Acquire resources (browser, client process…)."""

    @abc.abstractmethod
    async def stop(self) -> None:
        """Release resources."""

    @abc.abstractmethod
    async def join(self, meeting: Meeting, result: MeetingResult) -> None:
        """Attempt to join *meeting*; mutate *result* with the outcome."""

    def describe(self) -> str:
        return self.name
