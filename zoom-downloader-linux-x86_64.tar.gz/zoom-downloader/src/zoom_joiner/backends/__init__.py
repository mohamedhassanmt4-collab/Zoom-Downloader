"""Backend registry."""

from __future__ import annotations

from .base import BackendContext, JoinBackend

__all__ = ["BackendContext", "JoinBackend", "build_backend"]


def build_backend(name: str, ctx: BackendContext) -> JoinBackend:
    key = (name or "web").strip().lower()
    if key == "web":
        from .web import WebBackend

        return WebBackend(ctx)
    if key == "desktop":
        from .desktop import DesktopBackend

        return DesktopBackend(ctx)
    raise ValueError(f"unknown backend '{name}' (expected 'web' or 'desktop')")
