"""Web backend: joins Zoom meetings through the official web client (Chromium/Playwright)."""

from __future__ import annotations

import asyncio
import logging
import re
from pathlib import Path

from playwright.async_api import Error as PlaywrightError
from playwright.async_api import Page, async_playwright
from playwright.async_api import TimeoutError as PlaywrightTimeout

from ..meeting import canonical_join_url, extract_meeting_id, extract_query_value
from ..models import Meeting, MeetingResult, Status
from .base import BackendContext, JoinBackend

log = logging.getLogger("zoom_joiner.web")

# --------------------------------------------------------------------------------------
# Selectors / signatures used to drive the Zoom web client.
# The Zoom web UI is rewritten regularly, so every step accepts a list of
# alternatives and falls back to text matching.
# --------------------------------------------------------------------------------------

JOIN_BUTTONS = (
    "prejoin-join-button",
    "button.preview-join-button",
    "#joinBtn",
    "button#submitBtn",
    ".btn-accept",
    "button:has-text('Join Meeting')",
    "button:has-text('Join')",
    "a:has-text('Join Meeting')",
)

LAUNCH_BUTTONS = (
    "button:has-text('Continue on the Web')",
    "button:has-text('Launch Meeting')",
    "a:has-text('Launch Meeting')",
    "button:has-text('Join on the web')",
)

NAME_FIELDS = (
    "#inputname",
    "input#input-for-name",
    "input[name='name']",
    "input[id*='name' i]",
    "input[placeholder*='name' i]",
)

PASSCODE_FIELDS = (
    "#inputpasscode",
    "input[name='passcode']",
    "input[id*='passcode' i]",
    "input[placeholder*='passcode' i]",
    "input[placeholder*='passcode' i]",
    "input[type='password']",
)

OTP_FIELDS = (
    "input[name='passcode']",
    "input#passcode",
    "input[inputmode='numeric'][autocomplete='one-time-code']",
    "input[placeholder*='code' i]",
)

AUDIO_BUTTONS = (
    "button:has-text('Join Audio')",
    "button:has-text('Join Audio by Computer')",
    "button:has-text('Computer Audio')",
    "button:has-text('Continue without audio')",
    "button:has-text('Leave Computer Audio')",
)

IN_MEETING_SELECTORS = (
    "#footer",
    ".footer-button__text",
    "[aria-label*='Mute' i]",
    "[aria-label*='Unmute' i]",
    "[aria-label*='Leave Meeting' i]",
    "[aria-label*='Stop Video' i]",
    "[aria-label*='Participants' i]",
    "[data-testid='footer']",
)

WAITING_TEXTS = (
    "waiting for the host",
    "please wait, the meeting host will start soon",
    "waiting for the host to start this meeting",
    "host has not started",
)

FAILURE_TEXTS = (
    "invalid passcode",
    "passcode is incorrect",
    "meeting id is not valid",
    "invalid meeting id",
    "does not exist",
    "has ended",
    "you have been removed",
    "sorry, you cannot join",
    "this meeting is not available",
    "incorrect passcode",
    "unable to join",
    "we couldn't find that meeting",
)

SIGNED_IN_TEXTS = ("sign in", "log in", "account", "email address")


class WebBackend(JoinBackend):
    """Joins meetings by driving a headless (or headful) Chromium instance."""

    name = "web"

    def __init__(self, ctx: BackendContext) -> None:
        super().__init__(ctx)
        self._playwright = None
        self._browser = None
        self._lock = asyncio.Lock()

    # -- lifecycle ---------------------------------------------------------------
    async def start(self) -> None:
        if self._browser is not None:
            return
        self._playwright = await async_playwright().start()
        args = [
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--disable-blink-features=AutomationControlled",
            "--autoplay-policy=no-user-gesture-required",
        ]
        args += list(self.settings.browser_args)
        launch = {"headless": not self.ctx.headless, "args": args}
        try:
            self._browser = await self._playwright.chromium.launch(**launch)
        except PlaywrightError:
            # Fall back to a locally installed Chrome/Chromium channel.
            for channel in ("chrome", "msedge"):
                try:
                    self._browser = await self._playwright.chromium.launch(
                        channel=channel, **launch
                    )
                    break
                except PlaywrightError:
                    continue
        if self._browser is None:
            raise RuntimeError(
                "no usable browser found. Run: playwright install chromium  (or install google-chrome)"
            )

    async def stop(self) -> None:
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()

    # -- helpers -----------------------------------------------------------------
    @staticmethod
    async def _first_visible(page: Page, selectors: tuple[str, ...]) -> str | None:
        for sel in selectors:
            try:
                loc = page.locator(sel).first
                if await loc.count() and await loc.is_visible():
                    return sel
            except PlaywrightError:
                continue
        return None

    @staticmethod
    async def _click_first(page: Page, selectors: tuple[str, ...], timeout: float = 4.0) -> bool:
        for sel in selectors:
            try:
                loc = page.locator(sel).first
                if not await loc.count():
                    continue
                await loc.wait_for(state="visible", timeout=int(timeout * 1000))
                if not await loc.is_visible():
                    continue
                await loc.click(timeout=int(timeout * 1000))
                log.debug("clicked %s", sel)
                return True
            except (PlaywrightError, PlaywrightTimeout):
                continue
        return False

    @staticmethod
    async def _fill_first(page: Page, selectors: tuple[str, ...], value: str) -> bool:
        for sel in selectors:
            try:
                loc = page.locator(sel).first
                if not await loc.count():
                    continue
                await loc.wait_for(state="visible", timeout=2500)
                if not await loc.is_visible():
                    continue
                await loc.fill("")
                await loc.fill(value)
                log.debug("filled %s", sel)
                return True
            except (PlaywrightError, PlaywrightTimeout):
                continue
        return False

    async def _body_text(self, page: Page) -> str:
        try:
            return (await page.inner_text("body")).lower()
        except PlaywrightError:
            return ""

    async def _in_meeting(self, page: Page) -> bool:
        return await self._first_visible(page, IN_MEETING_SELECTORS) is not None

    async def _shot(self, page: Page, result: MeetingResult, tag: str = "failure") -> None:
        if not self.settings.screenshot_on_failure or not self.ctx.report_dir:
            return
        try:
            out = Path(self.ctx.report_dir) / "screenshots"
            out.mkdir(parents=True, exist_ok=True)
            safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", result.meeting.display_name())[:60]
            path = out / f"{safe}_{tag}.png"
            await page.screenshot(path=str(path), full_page=True)
            result.screenshot = str(path)
        except (PlaywrightError, OSError):
            pass

    # -- main flow ---------------------------------------------------------------
    def _resolve_url(self, meeting: Meeting, meeting_id: str, pwd_param: str) -> str:
        """Build the URL to open.

        Zoom links are normalised to the guest-join endpoint. Any other host
        (a self-hosted proxy, a test server) is used verbatim.
        """
        url = meeting.url or ""
        if "zoom.us" not in url.lower():
            return url
        return canonical_join_url(meeting_id, self.settings.name, pwd_param)

    async def join(self, meeting: Meeting, result: MeetingResult) -> None:
        meeting_id = extract_meeting_id(meeting.url)
        result.meeting.meeting_id = meeting_id
        pwd_param = extract_query_value(meeting.url, "pwd")
        join_url = self._resolve_url(meeting, meeting_id, pwd_param)
        if not join_url:
            result.status = Status.FAILED
            result.message = "could not extract a meeting id from the URL"
            return
        result.join_url = join_url

        if self._browser is None:
            await self.start()

        context = await self._browser.new_context(
            viewport={"width": 1366, "height": 850},
            locale="en-US",
            permissions=["microphone", "camera"],
        )
        context.set_default_timeout(15000)
        page = await context.new_page()
        try:
            await page.goto(join_url, wait_until="domcontentloaded", timeout=45000)
            await self._run_join_flow(page, meeting, result)
        except PlaywrightTimeout:
            result.status = Status.TIMEOUT
            result.message = "timed out while loading the join page"
            await self._shot(page, result)
        except PlaywrightError as exc:
            result.status = Status.FAILED
            result.message = f"browser error: {exc}"
            await self._shot(page, result)
        finally:
            if meeting.keep_open or self.settings.keep_open:
                # Leave the tab open so the user can watch the meeting.
                page.on("close", lambda _: None)
                result.message = (result.message + " | left open").strip()
            else:
                await context.close()

    async def _run_join_flow(self, page: Page, meeting: Meeting, result: MeetingResult) -> None:
        result.status = Status.LAUNCHING
        deadline = asyncio.get_event_loop().time() + self.settings.timeout

        # 1) landing page -> "Launch Meeting" / "Continue on the web"
        await self._click_first(page, LAUNCH_BUTTONS, timeout=3.0)
        await asyncio.sleep(1.0)

        # 2) name + passcode form
        await self._fill_first(page, NAME_FIELDS, self.settings.name)
        if meeting.passcode:
            await self._fill_first(page, PASSCODE_FIELDS, meeting.passcode)
        await asyncio.sleep(0.4)

        # 3) submit
        if not await self._click_first(page, JOIN_BUTTONS, timeout=4.0):
            result.status = Status.FAILED
            result.message = "could not find the Join button"
            await self._shot(page, result)
            return

        result.status = Status.JOINING
        result.message = "join submitted"

        # 4) wait for the outcome, handling 2FA / passcode challenges on the way
        otp_sent = False
        saw_waiting = False
        while asyncio.get_event_loop().time() < deadline:
            if self.ctx.is_cancelled():
                result.status = Status.SKIPPED
                result.message = "stopped by the user"
                return
            await asyncio.sleep(0.7)
            text = await self._body_text(page)

            if any(t in text for t in FAILURE_TEXTS):
                result.status = Status.FAILED
                result.message = self._failure_reason(text)
                await self._shot(page, result)
                return

            if await self._in_meeting(page):
                if meeting.join_audio == "computer":
                    await self._click_first(page, AUDIO_BUTTONS, timeout=1.5)
                result.status = Status.JOINED
                result.message = "joined the meeting"
                if not meeting.keep_open:
                    await self._click_first(page, ("button:has-text('Leave')",), timeout=1.0)
                return

            if any(t in text for t in WAITING_TEXTS):
                saw_waiting = True
                if meeting.wait_for_host:
                    result.status = Status.WAITING
                    result.message = "in the waiting room (host has not started yet)"
                    continue
                result.status = Status.WAITING
                result.message = "waiting room"
                return

            # 2FA / passcode challenge
            challenge = await self._first_visible(page, OTP_FIELDS)
            if challenge and not otp_sent:
                code = meeting.otp or meeting.passcode
                if code and await self._fill_first(page, OTP_FIELDS, code):
                    otp_sent = True
                    result.status = Status.AUTH
                    await page.keyboard.press("Enter")
                    continue

        if saw_waiting:
            result.status = Status.WAITING
            result.message = "still in the waiting room when the timeout expired"
            return
        result.status = Status.TIMEOUT
        result.message = f"timed out after {self.settings.timeout:.0f}s"
        await self._shot(page, result)

    @staticmethod
    def _failure_reason(text: str) -> str:
        for candidate in FAILURE_TEXTS:
            if candidate in text:
                idx = text.find(candidate)
                return text[max(0, idx - 40) : idx + len(candidate) + 20].strip()
        return "join rejected by Zoom"
