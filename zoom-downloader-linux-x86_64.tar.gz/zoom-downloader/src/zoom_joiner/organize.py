"""Rename already-downloaded recordings so their file names carry the date.

The date comes from the MP4 metadata (the ``mvhd`` box), which is the same
value Zoom writes into the file when the cloud recording is produced.  This
works for files downloaded by older versions of the app (``Meeting 1.mp4``)
and for files whose name lost the date (``Recording 1 (7).mp4``).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .names import safe_filename

_MP4_EPOCH = datetime(1904, 1, 1, tzinfo=timezone.utc)
_DATE_AT_END = re.compile(r"(\d{4})-(\d{2})-(\d{2})$")
_VIDEO_SUFFIXES = {".mp4", ".m4a"}


@dataclass(slots=True)
class OrganizeReport:
    """What happened while organizing one folder."""

    folder: str
    renamed: list[tuple[str, str]] = field(default_factory=list)
    already_dated: list[str] = field(default_factory=list)
    no_date: list[str] = field(default_factory=list)
    collisions: list[tuple[str, str]] = field(default_factory=list)
    errors: list[tuple[str, str]] = field(default_factory=list)


def _boxes(fh, start: int, end: int):
    """Yield ``(offset, type, header_size, size)`` for the boxes in a range."""
    pos = start
    while pos + 8 <= end:
        fh.seek(pos)
        head = fh.read(16)
        if len(head) < 8:
            return
        size = int.from_bytes(head[:4], "big")
        kind = head[4:8]
        header = 8
        if size == 1:
            if len(head) < 16:
                return
            size = int.from_bytes(head[8:16], "big")
            header = 16
        elif size == 0:
            size = end - pos
        if size < header:
            return
        yield pos, kind, header, size
        pos += size


def _valid_date(raw: int) -> str:
    if raw <= 0:
        return ""
    try:
        moment = _MP4_EPOCH + timedelta(seconds=raw)
    except (OverflowError, OSError):
        return ""
    if not 1990 <= moment.year <= 2100:
        return ""
    return moment.strftime("%Y-%m-%d")


def mp4_creation_date(path: Path) -> str:
    """Return the recording date (``YYYY-MM-DD``) stored in an MP4/M4A file."""
    try:
        size = path.stat().st_size
        with path.open("rb") as fh:
            for pos, kind, header, box_size in _boxes(fh, 0, size):
                if kind != b"moov":
                    continue
                for cpos, ckind, cheader, _csize in _boxes(fh, pos + header, pos + box_size):
                    if ckind != b"mvhd":
                        continue
                    fh.seek(cpos + cheader)
                    head = fh.read(16)
                    if len(head) < 8:
                        continue
                    version = head[0]
                    if version == 1:
                        if len(head) < 12:
                            continue
                        raw = int.from_bytes(head[4:12], "big")
                    else:
                        raw = int.from_bytes(head[4:8], "big")
                    date = _valid_date(raw)
                    if date:
                        return date
    except OSError:
        return ""
    return ""


def has_date_suffix(path: Path) -> bool:
    """True when the file name already ends with ``YYYY-MM-DD``."""
    return _DATE_AT_END.search(path.stem) is not None


def _date_from_name(path: Path) -> str:
    match = _DATE_AT_END.search(path.stem)
    return "-".join(match.groups()) if match else ""


def _matches_scheme(stem: str, wanted: str) -> bool:
    """True when *stem* is already ``wanted`` or ``wanted (2)``/``(3)``…"""
    return re.fullmatch(re.escape(wanted) + r"( \(\d+\))?", stem) is not None


def organize_by_date(folder: Path, base_name: str = "") -> OrganizeReport:
    """Add the recording date to video names, optionally unifying them.

    Without *base_name* the date is appended to names that lack one.  With a
    base name every file becomes ``<base> <date>.<ext>`` (numbered ``(2)``,
    ``(3)``… when several recordings share a date).  Existing files are never
    overwritten, and a second run leaves the names alone.
    """
    folder = Path(folder).expanduser()
    report = OrganizeReport(folder=str(folder))
    if not folder.is_dir():
        raise NotADirectoryError(str(folder))

    base = safe_filename(base_name) if (base_name or "").strip() else ""
    pending: list[tuple[Path, str]] = []

    for path in sorted(folder.iterdir()):
        if not path.is_file() or path.suffix.lower() not in _VIDEO_SUFFIXES:
            continue
        if not base:
            if has_date_suffix(path):
                report.already_dated.append(path.name)
                continue
            date = mp4_creation_date(path)
            if not date:
                report.no_date.append(path.name)
                continue
            target = path.with_name(f"{path.stem} {date}{path.suffix}")
            if target.exists():
                report.collisions.append((path.name, target.name))
                continue
            try:
                path.rename(target)
            except OSError as exc:
                report.errors.append((path.name, str(exc)))
                continue
            report.renamed.append((path.name, target.name))
            continue

        date = mp4_creation_date(path) or _date_from_name(path)
        if not date:
            report.no_date.append(path.name)
            continue
        wanted = f"{base} {date}"
        if _matches_scheme(path.stem, wanted):
            report.already_dated.append(path.name)
            continue
        pending.append((path, wanted))

    if not pending:
        return report

    renaming = {path for path, _wanted in pending}
    taken = {
        item.name
        for item in folder.iterdir()
        if item.is_file() and item not in renaming
    }
    for path, wanted in sorted(pending, key=lambda item: (item[1], item[0].name)):
        number = 1
        while True:
            suffix = "" if number == 1 else f" ({number})"
            candidate = f"{wanted}{suffix}{path.suffix}"
            if candidate not in taken:
                break
            number += 1
        target = path.with_name(candidate)
        try:
            path.rename(target)
        except OSError as exc:
            report.errors.append((path.name, str(exc)))
            continue
        taken.add(candidate)
        report.renamed.append((path.name, target.name))

    return report
