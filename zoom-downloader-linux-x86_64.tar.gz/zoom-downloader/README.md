# Zoom Downloader

<div align="center">

<div align="center">

<img src="src/zoom_joiner/assets/icons/icon-256.png" width="96" alt="Zoom Downloader icon">

</div>

**Your Zoom cloud recordings — fast, simple, in parallel.**

برنامج لينكس لتحميل تسجيلات اجتماعات Zoom الجاهزة (لينك المشاركة + الباس كود) وتحصيل الحصاد بشكل احترافي — واجهة نافذة، تحميل متوازي سريع، استكمال تلقائي لو وقف، تفريغ نصي.

`Native desktop app (Qt)` · `Fast CDN download` · `Parallel` · `Auto resume` · `Transcript (VTT)` · `Web dashboard` · `CLI`

> ⚡ جديد في v1.5.2: شريط التقدم بقى دقيق (100% بتظهر بس لما الملف يتحفظ فعلًا)، وكارت تواصل للفيدباك والاقتراحات، وتنظيم الملفات بالتاريخ حتى بعد التحميل.

<sub>Developed by <b>Mohamed Hassan</b></sub>

</div>

---

## 🚀 التحميل والتثبيت (ملفين فقط — اختار نظامك)

من صفحة **Releases**: حمّل ملف واحد حسب نظام التشغيل — مش محتاج تحمّل حاجات كتير:

| النظام | الملف | التثبيت |
|---|---|---|
| 🐧 Linux | `zoom-downloader-linux-x86_64.tar.gz` | فك الضغط وشغّل `./setup.sh` |
| 🪟 Windows | `zoom-downloader-windows.zip` | فك الضغط وشغّل `setup.ps1` |

### لينكس

```bash
tar -xzf zoom-downloader-linux-x86_64.tar.gz
cd zoom-downloader
./setup.sh              # تثبيت للمستخدم الحالي  (~/.local)
# أو
sudo ./setup.sh --system   # تثبيت لكل المستخدمين (/opt + /usr/local/bin)
```

السكربت `setup.sh` بيقوم بكل حاجة:يتأكد من python، ينشئ بيئة افتراضية، ينصّب التطبيق،
ينزّل محرك Chromium، يعمل launchers (`zoom-joiner` و `zoom-joiner-gui`)،
ويضيف أيقونة **"Zoom Downloader"** في قائمة التطبيقات. ولإزالة كل شيء: `./setup.sh --uninstall`.

> ملاحظة: التثبيت يحتاج إنترنت مرة واحدة (لتحميل الحزم ومتصفح Chromium).

### ويندوز

فك ضغط `zoom-downloader-windows.zip` — افتح PowerShell في مجلد المشروع وشغّل:

```powershell
powershell -ExecutionPolicy Bypass -File .\setup.ps1
```

بينصّب **"Zoom Downloader"** للمستخدم الحالي ويضيف اختصار في قائمة ابدأ،
من غير ما تحتاج صلاحيات أدمن. للإزالة: `.\setup.ps1 -Uninstall`
(الطابور والإعدادات بتتحفظ).

### الاستخدام بعد التثبيت

افتح **"Zoom Downloader"** من قائمة التطبيقات (أو شغّل `zoom-joiner-gui` في الطرفية):

1. الصق لينكات التسجيلات، سطر لكل واحد:
   `https://zoom.us/rec/share/xxxx?pwd=123456 اسم التسجيل`
2. اضغط **Download all recordings** — الفيديو بيتجر من CDN زووم باتصالات متوازية.
3. لو قفلت البرنامج أو وقع النت، افتحه تاني واضغط نفس الزر — بيكمّل من ماقفش.

> الإصلاح الجماعي القديم (انضمام لاجتماعات Zoom لا حية) امسحوه من الواجهة — بقي في سطر الأوامر فقط `zoom-joiner run` لو احتجته أبدًا.

---

## المميزات

| الميزة | التفاصيل |
|---|---|
| **تطبيق نافذة أصلي** | واجهة Qt احترافية (داكنة) — مش متصفح |
| **تحميل من CDN مباشرة** | بتلتقط الرابط الموقّع بتاع الفيديو من player زووم + الـ cookies، وتحمّله بذاتها — مش محتاجة زر Download في الموقع |
| **استكمال تلقائي** | قائمة التسجيلات تُحفظ على القرص — لو قفلت البرنامج أو وقف الجهاز، تفتحه واضغط زر التحميل بيكمّل |
| **باس كود لكل تسجيل** | `passcode` لكل سطر + `Default passcode` عام كـ fallback |
| **قرار ذكي بالسرعة** | لو الشبكة بطيئة → اتصالات متوازية، لو سريعة → stream واحد (بي Heb اجل التأخير) |
| **تفريغ نصي** | Transcript بصيغة VTT جاهزة (بيحوّل الـ JSON بتاع زووم لـ WEBVTT) |
| **أيقونة احترافية** | أيقونة SVG + PNG لكل المقاسات (سطح المكتب + النافذة + favicon) |
| **ثلاث واجهات** | نافذة تطبيق · لوحة ويب محلية · سطر أوامر |

---

## المتطلبات

- Python 3.10+
- Chromium (عبر Playwright) أو Google Chrome مثبّت
- للوضع `desktop`: عميل Zoom الرسمي + `xdotool` + بيئة رسومية X11

```bash
# Debian / Ubuntu
sudo apt update
sudo apt install -y python3-venv xdotool
```

---

## التثبيت (3 خطوات)

```bash
cd ~/zoom-joiner
make install          # ينشئ venv ويثبّت الحزم ويثبّت Chromium
source .venv/bin/activate
zoom-joiner doctor   # فحص البيئة
```

أو يدويًا:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
playwright install chromium
```

---

## استخدام سريع

```bash
# 1) أنشئ ملف meetings.yaml
zoom-joiner init -f meetings.yaml

# 2) عدّل الملف ثم شغّل
zoom-joiner run -f meetings.yaml --parallel 3 --passkey 123456
```

أو من سطر واحد بدون ملف:

```bash
zoom-joiner run \
  --url "https://zoom.us/j/12345678901" \
  --url "https://zoom.us/j/10987654321" \
  --passkey 123456
```

---

## صيغة ملف الاجتماعات

### YAML (موصى به)

```yaml
defaults:
  backend: web          # web | desktop
  parallel: 3
  passkey: "123456"     # باس كود عام يُستخدم لكل سطر لا يملك باس كود خاص
  name: "Mohamed"       # الاسم الظاهر عند الدخول
  timeout: 90
  retries: 1
  keep_open: false
  join_audio: auto      # auto | computer | none

meetings:
  - name: "Daily Standup"
    url: "https://zoom.us/j/12345678901"
    passcode: "123456"
  - name: "Client Review"
    url: "https://zoom.us/j/98765432101?pwd=abc"
  - name: "Interview"
    url: "https://zoom.us/j/55566677788"
    notes: "مع اللجنة"
```

### CSV

```csv
name,url,passcode
Daily Standup,https://zoom.us/j/12345678901,123456
Client Review,https://zoom.us/j/98765432101,654321
```

### TXT (سطر لكل اجتماع: `رابط [باس كود] [اسم]`)

```
https://zoom.us/j/12345678901 123456 Daily Standup
https://zoom.us/j/98765432101 654321 Client Review
```

### JSON

```json
{ "defaults": { "parallel": 3, "passkey": "123456" },
  "meetings": [ { "name": "Standup", "url": "https://zoom.us/j/12345678901" } ] }
```

---

## الأوامر

| الأمر | الوظيفة |
|---|---|
| `zoom-joiner init -f file.yaml` | إنشاء ملف إعدادات نموذجي |
| `zoom-joiner validate -f file.yaml` | فحص الروابط والباس كود بدون فتح أي شيء |
| `zoom-joiner run -f file.yaml` | تنفيذ الانضمام الجماعي |
| `zoom-joiner run --url ... --passkey ...` | انضمام سريع من سطر الأوامر |
| `zoom-joiner doctor` | فحص البيئة (Playwright/Chromium/xdotool/Zoom) |
| `zoom-joiner app` | تشغيل التطبيق الأصلي (نافذة Qt) |
| `zoom-joiner gui` | تشغيل لوحة التحكم المحلية في المتصفح |
| `zoom-joiner report <dir> --open` | فتح تقرير نتيجة سابقة |

### خيارات `run` المهمة

| الخيار | الافتراضي | الوصف |
|---|---|---|
| `--parallel N` | 3 | عدد الاجتماعات المتزامنة |
| `--passkey` | — | باس كود عام fallback |
| `--backend web\|desktop` | web | محرّك الدخول |
| `--headful` | off | إظهار نافذة المتصفح (للتشخيص) |
| `--keep-open` | off | إبقاء نافذة الاجتماع مفتوحة بعد الدخول |
| `--timeout SEC` | 90 | مهلة كل اجتماع |
| `--retries N` | 1 | محاولات إضافية |
| `--join-audio computer\|none\|auto` | auto | التعامل مع نافذة الصوت |
| `--out DIR` | `reports/<timestamp>` | مجلد التقرير |
| `--dry-run` | off | تحقّق فقط بدون تشغيل |

---

## الحالات المكتشفة

| الحالة | المعنى |
|---|---|
| `joined` | دخل الاجتماع بنجاح (ظهر شريط التحكم) |
| `waiting` | في غرفة الانتظار — المضيف لم يبدأ بعد |
| `failed` | رفض Zoom: باس كود خاطئ / الرقم غير موجود / انتهى الاجتماع |
| `timeout` | انتهت المهلة قبل تأكيد الدخول |

---

## ⭳ تحميل تسجيلات ميتنج خلصت

في تاب تاني داخل نفس التطبيق: **Download recordings**.

1. الصق **لينك المشاركة** بتاع التسجيل (مثال: `https://us06web.zoom.us/rec/share/AbCdEf...`).
2. حط **باس كود التسجيل** (اللي مبعوت في رسالة الاستضافة، أو موجود في اللينك نفسه `?pwd=`).
3. اختر مجلد الحفظ (افتراضيًا `~/Downloads/zoom-recordings`).
4. اضغط **Download all recordings**.

الأداة بتعمل إيه بالظبط:

| الخطوة | التفاصيل |
|---|---|
| تفتح لينك المشاركة | في متصفح Chromium حقيقي (زي ما بتعمل بإيدك) |
| تكتب الباس كود | لو الباس كود في اللينك `?pwd=` بيتقرأ لوحده |
| تضغط زر Download | بتاخد الفيديو **mp4** من زووم نفسه |
| اختياري | كمان الصوت **m4a** و **Transcript (vtt)** |
| تحفظ باسم واضح | `<اسم الميتنج>.mp4` في مجلد الحفظ |

**لو التسجيل محمي** بيطلب تسجيل دخول (Zoom sometimes asks the account owner to sign in before
allowing a download) — الأداة بتقولك الرسالة بوضوح: افتح اللينك في متصفحك وسجّل دخول مرة واحدة
 وبعدها جرّب تاني.

### من سطر الأوامر

```bash
zoom-joiner download \
  --url "https://us06web.zoom.us/rec/share/AbCdEf..." --passcode 123456 \
  --out ~/Downloads/zoom-recordings --audio

# أو من ملف (سطر لكل تسجيل: url passcode name)
zoom-joiner download -f recordings.txt --parallel 3

# 16 اتصالات لكل ملف (أقصى سرعة)
zoom-joiner download -f recordings.txt --connections 16
```

---

## 🖥️ التطبيق (نافذة أصلية)

```bash
zoom-joiner-gui        # أو: zoom-joiner app
```

الواجهة مقسّمة لخطوات واضحة، وكل خطوة مكتوب فوقها إيه اللي تعمله:

| الجزء | الوظيفة |
|---|---|
| **الشريط العلوي** | `Join all meetings` · `Stop` · `Retry failed` · `Resume pending` + شريط التقدّم + حالة التطبيق |
| **1 · Paste your meeting links** | لصق اللينكات (سطر لكل واحد: `url passcode name`) + `Add to the list` + `Paste from clipboard` |
| **2 · Options** | الباس كود الافتراضي، الاسم الظاهر، محرك المتصفح، التوازي، المهلة، المحاولات التلقائية |
| **3 · Queue** | جدول بكل اجتماع وحالته اللحظية + عدّادات (joined/waiting/failed/pending) + تصدير CSV |
| **Activity log** | سجل لحظي لكل إجراء |
| **How to use** | زرار أعلى الشاشة بيشرح步骤 حسب التاب الحالي (دخول / تحميل) |

**حالات فارغة مفهومة:** لو الـ Queue فاضية بيظهر شرح مكتوب: *"The queue is empty — paste your
links on the left and press Add to the list"*. ومفيش تداخل ولا زرار فوق نص — كل الكارت
بمسافات ثابتة وشريط تمرير في العمود الشمال.

**الاستكمال التلقائي:** بعد كل تغيير في الحالة يتم حفظ الـ queue في
`~/.local/share/zoom-joiner/queue.json`. لو قفلت البرنامج أو اتقطع النت أو وقف
الجهاز، تفتح البرنامج فيجد بانر: *"N meeting(s) did not finish — continue them
now?"* ويكمل من عند آخر نقطة. كذلك `Auto retries` بيعيد المحاولة لوحده.

> التطبيق شغّال في **عملية منفصلة** (subprocess) — لو المتصفح وقع، النافذة
> بتفضل شغالة والـ queue بيفضل محفوظ.

---

## 🖥️ لوحة التحكم (Web GUI)

```bash
zoom-joiner gui              # يفتح http://127.0.0.1:8765 في المتصفح
zoom-joiner gui --port 9000 --no-open
```

لوحة تحكم محلية (تعمل على `127.0.0.1` فقط، بدون أي مكتبات خارجية) فيها:

- لصق الروابط والباس كود في مربع واحد وتشغيل الدفعة فورًا
- متابعة حالة كل اجتماع **لحظيًا** (joined / waiting / failed) مع الوقت وعدد المحاولات
- سجل تنفيذ مباشر + رابط التقرير بعد الانتهاء
- نفس إمكانيات الـ CLI (backend، التوازي، نافذة مرئية، إبقاء الاجتماع مفتوحًا)

لتثبيتها كأيقونة على الـ Desktop:

```bash
mkdir -p ~/.local/share/applications
cp deploy/zoom-joiner.desktop ~/.local/share/applications/
```

---

## البنية

```
zoom-joiner/
├── src/zoom_joiner/
│   ├── cli.py            # واجهة الأوامر
│   ├── app.py            # التطبيق الأصلي (Qt/PySide6)
│   ├── store.py          # حفظ الـ queue للاستكمال
│   ├── config.py         # قراءة YAML/JSON/CSV/TXT
│   ├── meeting.py        # تحليل وتوحيد روابط Zoom
│   ├── models.py         # Meeting / MeetingResult / Status
│   ├── orchestrator.py   # التوازي، المحاولات، الإ��غاء
│   ├── report.py         # CSV + JSON + HTML
│   ├── ui.py             # لوحة التحكم الطرفية (rich)
│   ├── webui.py          # لوحة التحكم في المتصفح (GUI)
│   └── backends/
│       ├── web.py        # Chromium/Playwright
│       └── desktop.py    # عميل Zoom الأصلي
├── setup.sh              # سكربت التثبيت (ابعته لأي حد)
├── tests/                # اختبارات وحدة
├── deploy/               # systemd unit + أيقونة
└── Makefile
```

---

## تشغيل كخدمة (اختياري)

```bash
sudo cp deploy/zoom-joiner.service /etc/systemd/system/
sudo systemctl enable --now zoom-joiner.service
journalctl -u zoom-joiner -f
```

---

## ملاحظات مهمّة

- تحتاج **رابطًا + باس كود صالحًا** للاجتماع؛ الأداة لا تتخطى حماية Zoom ولا تُخترق أي حساب.
- الموازاة العالية (أكثر من 5 نقاط) قد تُطلق **rate limiting** من Zoom — ابدأ بـ `--parallel 3`.
- الوضع `headful` مع `--keep-open` مفيد لتدخل بشري عند التحقق بخطوتين (2FA).
- استخدم `zoom-joiner validate` قبل أي تشغيل فعلي بملف كبير.

---

## التطوير

```bash
make install   # بيئة تطوير + Chromium
make test      # pytest
make lint      # ruff
make format    # ruff format
make bundle    # حزمة جاهزة لل distribيع: dist/zoom-joiner-<ver>-linux-x86_64.tar.gz
```

---

## الترخيص

MIT — انظر [LICENSE](LICENSE).
